// SPHEREx 102 Spectral Bands Data Specification
// NASA SPHEREx (Spectro-Photometer for the History of the Universe, Epoch of Reionization and Ices Explorer)
// 6 Detector Arrays x 17 Bands each = Exactly 102 Near-Infrared Spectral Bands (0.75 μm - 5.00 μm)

export interface SPHERExBand {
  band: number; // 1 to 102
  wavelength: number; // in microns (μm)
  array: 1 | 2 | 3 | 4 | 5 | 6;
  arrayName: string;
  arrayNameSi: string;
  scienceFeature: string;
  sinhalaScienceFeature: string;
  englishDesc: string;
  sinhalaDesc: string;
  color: string; // False color representation
  glowColor: string;
  planetXRadiance: number; // 0.15 (optical boundary) to 1.0 (thermal IR peak at ~4.8um)
  starShift: number; // Atmospheric / chromatic shift factor
  filterType: string;
}

// Generates the authentic 102 SPHEREx Spectral Bands
export function generate102Bands(): SPHERExBand[] {
  const bands: SPHERExBand[] = [];

  // 6 Arrays configuration
  const arrayConfigs = [
    {
      array: 1 as const,
      name: "Array 1 (0.75 - 1.11 μm)",
      nameSi: "කලාපය 1 (0.75 - 1.11 μm)",
      startW: 0.75,
      endW: 1.11,
      themeColorStart: [30, 64, 175], // Deep Blue
      themeColorEnd: [6, 182, 212], // Cyan
      glow: "rgba(6, 182, 212, 0.7)",
      science: "Stellar Photospheres & Near-IR Edge",
      scienceSi: "තරු ප්‍රභාගෝල සහ නියර්-IR කලාපය",
      desc: "Bright visible stars; cold distant planets are faint",
      descSi: "දීප්තිමත් දෘශ්‍ය තරු; ඈත සීතල ග්‍රහලෝක මෙහිදී ඉතා අඳුරුය",
      filterType: "LVF Bandpass 1"
    },
    {
      array: 2 as const,
      name: "Array 2 (1.11 - 1.64 μm)",
      nameSi: "කලාපය 2 (1.11 - 1.64 μm)",
      startW: 1.11,
      endW: 1.64,
      themeColorStart: [14, 165, 233], // Sky Blue
      themeColorEnd: [16, 185, 129], // Emerald
      glow: "rgba(16, 185, 129, 0.7)",
      science: "Water Ice (1.5 μm) & Brown Dwarf Stars",
      scienceSi: "ජල අයිස් (1.5 μm) සහ දුඹුරු වාමන තරු",
      desc: "Water ice fingerprints on comets and outer moons",
      descSi: "ධූමකේතු සහ බාහිර උපග්‍රහයන්ගේ ජල අයිස් සංයුතිය",
      filterType: "LVF Bandpass 2"
    },
    {
      array: 3 as const,
      name: "Array 3 (1.64 - 2.42 μm)",
      nameSi: "කලාපය 3 (1.64 - 2.42 μm)",
      startW: 1.64,
      endW: 2.42,
      themeColorStart: [34, 197, 94], // Green
      themeColorEnd: [132, 204, 22], // Lime
      glow: "rgba(132, 204, 22, 0.7)",
      science: "Carbon Monoxide (2.3 μm) & Molecular Clouds",
      scienceSi: "කාබන් මොනොක්සයිඩ් (2.3 μm) සහ අණුක වලාකුළු",
      desc: "Peeking through dark interstellar dust clouds",
      descSi: "අන්තර් තාරකා අඳුරු ධූලි වලාකුළු අතරින් විනිවිද දැකීම",
      filterType: "LVF Bandpass 3"
    },
    {
      array: 4 as const,
      name: "Array 4 (2.42 - 3.82 μm)",
      nameSi: "කලාපය 4 (2.42 - 3.82 μm)",
      startW: 2.42,
      endW: 3.82,
      themeColorStart: [234, 179, 8], // Yellow
      themeColorEnd: [249, 115, 22], // Orange
      glow: "rgba(249, 115, 22, 0.75)",
      science: "Interstellar Organic Dust & Hydrocarbon Ices (3.3 μm)",
      scienceSi: "කාබනික අණු සහ හයිඩ්‍රොකාබන් අයිස් (3.3 μm)",
      desc: "Organic prebiotic molecules in deep interstellar space",
      descSi: "ගැඹුරු අභ්‍යවකාශයේ ජීවයට මුල්වන කාබනික අණු",
      filterType: "LVF Bandpass 4"
    },
    {
      array: 5 as const,
      name: "Array 5 (3.82 - 4.42 μm)",
      nameSi: "කලාපය 5 (3.82 - 4.42 μm)",
      startW: 3.82,
      endW: 4.42,
      themeColorStart: [249, 115, 22], // Orange
      themeColorEnd: [239, 68, 68], // Red
      glow: "rgba(239, 68, 68, 0.8)",
      science: "Carbon Dioxide Dry Ice (4.27 μm) & Cosmic Dawn",
      scienceSi: "වියලි අයිස් / CO2 (4.27 μm) සහ විශ්වයේ ආරම්භය",
      desc: "Frozen CO2 ices and ancient light from cosmic dawn",
      descSi: "මිදුණු කාබන් ඩයොක්සයිඩ් සහ විශ්වයේ මුල් යුගයේ ආලෝකය",
      filterType: "LVF Bandpass 5"
    },
    {
      array: 6 as const,
      name: "Array 6 (4.42 - 5.00 μm)",
      nameSi: "කලාපය 6 (4.42 - 5.00 μm)",
      startW: 4.42,
      endW: 5.00,
      themeColorStart: [236, 72, 153], // Magenta Pink
      themeColorEnd: [225, 29, 72], // Crimson Rose
      glow: "rgba(244, 63, 94, 0.9)",
      science: "Planet X / Kuiper Belt Thermal Peak (~4.8 μm)",
      scienceSi: "ප්ලැනට් X තාප විකිරණ උපරිමය (~4.8 μm)",
      desc: "Planet X thermal emission peak (glows brightest here!)",
      descSi: "ප්ලැනට් X තාප විමෝචන උපරිමය (මෙහිදී වඩාත්ම දීප්තිමත් වේ!)",
      filterType: "LVF Bandpass 6"
    }
  ];

  let bandCount = 1;

  for (const arr of arrayConfigs) {
    const numBandsInArray = 17; // exactly 17 bands per array = 102 total
    for (let j = 0; j < numBandsInArray; j++) {
      const fraction = j / (numBandsInArray - 1);
      const wavelength = Number((arr.startW + fraction * (arr.endW - arr.startW)).toFixed(3));

      // Interpolate RGB color for false-color IR mapping
      const r = Math.round(arr.themeColorStart[0] + fraction * (arr.themeColorEnd[0] - arr.themeColorStart[0]));
      const g = Math.round(arr.themeColorStart[1] + fraction * (arr.themeColorEnd[1] - arr.themeColorStart[1]));
      const b = Math.round(arr.themeColorStart[2] + fraction * (arr.themeColorEnd[2] - arr.themeColorStart[2]));
      const colorHex = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;

      // Planet X thermal radiance model:
      // Planet X has temperature ~40-60 Kelvin, emitting almost zero in optical/NIR (0.75um),
      // and radiating predominantly in the deep infrared (4.5 - 5.0um)!
      const globalFraction = (bandCount - 1) / 101;
      // Exponential rise toward thermal mid-IR
      const planetXRadiance = Number((0.15 + 0.85 * Math.pow(globalFraction, 1.8)).toFixed(2));

      bands.push({
        band: bandCount,
        wavelength,
        array: arr.array,
        arrayName: arr.name,
        arrayNameSi: arr.nameSi,
        scienceFeature: `${arr.science} (λ=${wavelength}μm)`,
        sinhalaScienceFeature: `${arr.scienceSi} (λ=${wavelength}μm)`,
        englishDesc: arr.desc,
        sinhalaDesc: arr.descSi,
        color: colorHex,
        glowColor: arr.glow,
        planetXRadiance,
        starShift: Number((1.2 - 0.5 * globalFraction).toFixed(2)),
        filterType: `${arr.filterType} (#${bandCount})`
      });

      bandCount++;
    }
  }

  return bands;
}

export const SPHEREX_102_BANDS = generate102Bands();
