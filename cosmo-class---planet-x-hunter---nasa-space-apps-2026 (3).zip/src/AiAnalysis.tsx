import React, { useState } from 'react';
import { 
  Cpu, 
  Brain, 
  Binary, 
  Search, 
  UserCheck, 
  CheckCircle2, 
  Sparkles, 
  ShieldCheck, 
  Info,
  Eye,
  Sliders,
  Play,
  RotateCcw
} from 'lucide-react';
import { RAW_CANDIDATES } from './ExperimentLab';
import { Language } from './translations';

interface PipelineStep {
  number: number;
  title: string;
  titleSi: string;
  category: string;
  categorySi: string;
  role: 'AI Model' | 'Human Scientist' | 'Data Pipeline';
  icon: string;
  summary: string;
  summarySi: string;
  algorithm: string;
  input: string;
  output: string;
  keyMetric: string;
}

const PIPELINE_STEPS: PipelineStep[] = [
  {
    number: 1,
    title: "Astronomical Data Ingestion",
    titleSi: "තාරකා විද්‍යා දත්ත ලබාගැනීම",
    category: "Data Ingestion",
    categorySi: "දත්ත ලබාගැනීම",
    role: "Data Pipeline",
    icon: "📡",
    summary: "Continuous ingestion of calibrated all-sky survey data from the NASA SPHEREx mission across 102 near-infrared spectral bands (0.75 μm to 5.00 μm).",
    summarySi: "නාසා SPHEREx මෙහෙයුමෙන් ලැබෙන තරංග ආයාම 102 පුරාම වූ සර්වේ ඡායාරූප (Survey 1 සහ Survey 2) අඛණ්ඩව පද්ධතියට එක්රැස් කිරීම.",
    algorithm: "Caltech / IPAC Astrometric Pipeline & FITS Processing",
    input: "Raw survey frames from Survey 1 (March) and Survey 2 (Sept)",
    output: "Astrometrically registered sky tiles with calibrated flux",
    keyMetric: "1,248 sky tiles ingested • 102 narrow spectral channels"
  },
  {
    number: 2,
    title: "Data Preprocessing & Calibration",
    titleSi: "දත්ත පිරිසිදු කිරීම සහ ක්‍රමාංකනය",
    category: "Preprocessing",
    categorySi: "පෙර සැකසුම",
    role: "AI Model",
    icon: "⚙️",
    summary: "Removes instrument noise, cryocooler thermal jitter, and performs background star alignment so stationary stellar photospheres remain 100% constant.",
    summarySi: "දුරේක්ෂයේ සංවේදක දෝෂ (Sensor Noise) ඉවත් කර, ආලෝක වර්ෂ ගණනාවක් ඈතින් ඇති පසුබිම් තරු නිශ්චලව තබා ගනිමින් කක්ෂය පෙළගැස්වීම.",
    algorithm: "Point Spread Function (PSF) Photometry & Subtraction",
    input: "Multi-band sensor arrays 1 through 6",
    output: "Normalized residual difference frames with artifacts masked",
    keyMetric: "Background stellar noise suppressed by 88%"
  },
  {
    number: 3,
    title: "Pattern & Motion Detection",
    titleSi: "රටා සහ චලනයන් හඳුනාගැනීම",
    category: "Computer Vision",
    categorySi: "පරිගණක දෘෂ්ටිය",
    role: "AI Model",
    icon: "🔍",
    summary: "Neural network tracks pixel coordinate displacement between epochs. Flags objects showing the signature ~80px parallax motion vector of trans-Neptunian bodies.",
    summarySi: "මාර්තු සහ සැප්තැම්බර් ඡායාරූප අතර පික්සල 80 ක පමණ පැරලැක්ස් පැනීමක් (චලනයක්) පෙන්වන අභ්‍යවකාශ වස්තූන් කෘතිම බුද්ධිය මඟින් වෙන්කර හඳුනාගැනීම.",
    algorithm: "Optical Flow & Dual-Epoch Centroid Cross-Correlation",
    input: "March vs September sky coordinates",
    output: "Vector displacement candidates with computed proper motion",
    keyMetric: "Motion detection sensitivity: 0.1 to 5.0 arcsec/yr"
  },
  {
    number: 4,
    title: "Anomaly Analysis & False-Positive Pruning",
    titleSi: "අනවශ්‍ය සංඥා (False Positives) ඉවත් කිරීම",
    category: "Filtering",
    categorySi: "පෙරීම",
    role: "AI Model",
    icon: "🛡️",
    summary: "Filters out high-energy cosmic ray transients, telescope mirror diffraction spikes, and near-Earth satellites that move too rapidly to be bound outer planets.",
    summarySi: "විශ්ව කිරණ (Cosmic Rays), කෘතිම චන්ද්‍රිකා සහ සංවේදක දෝෂ මඟින් ඇතිවන ව්‍යාජ ලප 8 ක් ඉවත් කර නියම අපේක්ෂිතයන් 4 ක් පමණක් ඉතිරි කිරීම.",
    algorithm: "Multi-Band Spectral Gradient & Isolation Forest",
    input: "Raw candidate vectors & 102 spectral profiles",
    output: "Pruned candidates meeting Solar System orbital bounds",
    keyMetric: "Rejection rate: 8 out of 12 false triggers eliminated"
  },
  {
    number: 5,
    title: "Candidate Ranking & Feature Scoring",
    titleSi: "අපේක්ෂිතයන් ශ්‍රේණිගත කිරීම සහ විශ්වාසනීයත්ව ලකුණු",
    category: "Scoring (XAI)",
    categorySi: "ලකුණු ලබාදීම",
    role: "AI Model",
    icon: "📊",
    summary: "Computes Explainable AI (XAI) confidence scores evaluating thermal radiance in Array 6 (4.8 μm), SNR, and Keplerian orbital consistency.",
    summarySi: "Array 6 හි තාප විකිරණය සහ කෙප්ලර් කක්ෂීය ගණනය කිරීම් මත පදනම්ව වඩාත්ම ඉහළ සම්භාවිතාවක් ඇති අපේක්ෂිතයන්ට ලකුණු ලබාදීම.",
    algorithm: "Explainable Gradient Boosting & Radiative Transfer Model",
    input: "Filtered photometric detections",
    output: "Ranked list of high-priority Planet X and TNO candidates",
    keyMetric: "Top candidate confidence: 92% (SPX-PX-001)"
  },
  {
    number: 6,
    title: "Human Investigation & Scientist Decision",
    titleSi: "විද්‍යාඥයන්ගේ පරීක්ෂාව සහ අවසන් තීරණය",
    category: "Human-in-the-Loop",
    categorySi: "විද්‍යාඥ අධීක්ෂණය",
    role: "Human Scientist",
    icon: "👨‍🔬",
    summary: "Final research gatekeeper: astronomer reviews spectral curves, confirms physical plausibility, coordinates James Webb (JWST) ground verification, or archives non-detections.",
    summarySi: "අවසාන තීරණය තාරකා විද්‍යාඥයා සතු වේ. AI මඟින් ලබාදෙන අපේක්ෂිතයන් ජේම්ස් වෙබ් (JWST) දුරේක්ෂයෙන් තහවුරු කිරීමට හෝ වැඩිදුර පර්යේෂණ සඳහා යොමු කිරීම.",
    algorithm: "Astrophysical Peer-Review Protocol & Ephemeris Verification",
    input: "Top 4 scored candidate targets",
    output: "Official IAU discovery candidate submission or targeted follow-up",
    keyMetric: "100% human accountability for astronomical discoveries"
  }
];

interface AiAnalysisProps {
  onInspectSkyCandidate?: (bandIndex: number, ra: string, dec: string) => void;
  lang?: Language;
}

export function AiAnalysis({ onInspectSkyCandidate, lang = 'si' }: AiAnalysisProps) {
  const [selectedStep, setSelectedStep] = useState<number>(1);
  const [isSimulatingPipeline, setIsSimulatingPipeline] = useState<boolean>(false);
  const [simStep, setSimStep] = useState<number>(0);
  const [candidateDecisions, setCandidateDecisions] = useState<Record<string, 'verified' | 'followup' | 'rejected'>>({});

  const activeStep = PIPELINE_STEPS.find(s => s.number === selectedStep) || PIPELINE_STEPS[0];

  const runSimulation = () => {
    setIsSimulatingPipeline(true);
    setSimStep(1);
    setSelectedStep(1);

    const interval = setInterval(() => {
      setSimStep(prev => {
        if (prev >= 6) {
          clearInterval(interval);
          setIsSimulatingPipeline(false);
          return 6;
        }
        setSelectedStep(prev + 1);
        return prev + 1;
      });
    }, 900);
  };

  const handleDecision = (candId: string, decision: 'verified' | 'followup' | 'rejected') => {
    setCandidateDecisions(prev => ({
      ...prev,
      [candId]: decision
    }));
  };

  // Counts of human decisions
  const decisionCounts = {
    verified: Object.values(candidateDecisions).filter(d => d === 'verified').length,
    followup: Object.values(candidateDecisions).filter(d => d === 'followup').length,
    rejected: Object.values(candidateDecisions).filter(d => d === 'rejected').length,
  };

  return (
    <div className="relative w-full max-w-7xl mx-auto space-y-6 overflow-hidden py-3">
      
      {/* 3D GLOWING CELESTIAL SPHERES (UI + OBJECT) */}
      <div className="absolute -top-16 -left-16 w-80 h-80 rounded-full object-sphere-purple pointer-events-none -z-10 opacity-70 animate-pulse duration-1000" />
      <div className="absolute top-1/4 -right-24 w-96 h-96 rounded-full object-sphere-orange pointer-events-none -z-10 opacity-60" />
      <div className="absolute -bottom-24 left-1/3 w-80 h-80 rounded-full object-sphere-magenta pointer-events-none -z-10 opacity-60" />
      <div className="absolute bottom-16 right-16 w-44 h-44 rounded-full object-sphere-cyan pointer-events-none -z-10 opacity-50" />

      {/* HEADER SECTION - UI + OBJECT TRANSLUCENT GLASS PANEL */}
      <div className="uiobj-panel p-5 sm:p-7 flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl object-sphere-purple flex items-center justify-center font-bold text-white shadow-xl flex-shrink-0">
            <Brain className="w-7 h-7 text-white drop-shadow" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-wide">
                {lang === 'si'
                  ? "AI විශ්ලේෂණ පද්ධතිය සහ විද්‍යාඥ අධීක්ෂණ ආකෘතිය"
                  : "AI Analysis Pipeline & Human Investigation Architecture"}
              </h1>
              <span className="text-[11px] font-mono px-3 py-1 rounded-full bg-purple-100 text-purple-900 border border-purple-300 font-bold shadow-sm">
                Human-in-the-Loop
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed font-medium">
              {lang === 'si'
                ? "කෘතිම බුද්ධිය (AI) මඟින් අධිවේගී විශ්ලේෂණ සහය ලබාදෙන අතර • අවසන් තීරණය 100% ක්ම විද්‍යාඥයන් සතු වේ"
                : "AI serves as high-speed analytical assistant • Human scientists retain 100% final discovery authority"}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-shrink-0">
          <button
            onClick={runSimulation}
            disabled={isSimulatingPipeline}
            className={`px-5 py-2.5 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer flex-shrink-0 ${
              isSimulatingPipeline
                ? 'uiobj-btn-secondary opacity-80 cursor-wait'
                : 'uiobj-btn-primary'
            }`}
          >
            <Sparkles className="w-4 h-4 fill-white" />
            <span>
              {isSimulatingPipeline 
                ? (lang === 'si' ? `පියවර ${simStep}/6 ක් ක්‍රියාත්මකයි...` : `Simulating Step ${simStep} of 6...`)
                : (lang === 'si' ? "සම්පූර්ණ AI පද්ධතිය අත්හදා බලන්න" : "Simulate Full Pipeline")}
            </span>
          </button>
        </div>
      </div>

      {/* 6-STEP PIPELINE INTERACTIVE DIAGRAM */}
      <div className="uiobj-panel p-5 sm:p-6 space-y-5 relative z-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-sky-200/80 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-full object-sphere-purple flex items-center justify-center text-xs text-white">
              <Cpu className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-xs font-extrabold uppercase tracking-wider text-slate-800">
              {lang === 'si' 
                ? "AI විශ්ලේෂණ පියවර 6 (පියවරක් මත ක්ලික් කර විස්තර බලන්න)" 
                : "AI ANALYSIS PIPELINE (Click Any Step to Inspect)"}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-purple-900 bg-purple-100 px-3 py-1 rounded-full border border-purple-300 font-semibold shadow-sm">
              {lang === 'si' ? `තෝරාගත් පියවර: ${selectedStep} / 6` : `Step ${selectedStep} of 6 Selected`}
            </span>
            {isSimulatingPipeline && (
              <span className="text-[11px] font-mono text-emerald-900 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300 animate-pulse font-bold">
                SIM ACTIVE
              </span>
            )}
          </div>
        </div>

        {/* HORIZONTAL / STACKED PIPELINE FLOW WITH TACTILE 3D CARDS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5 relative">
          {PIPELINE_STEPS.map((step, idx) => {
            const isSelected = selectedStep === step.number;
            const isHumanStep = step.role === 'Human Scientist';
            const isPassedSim = simStep >= step.number;
            const stepTitle = lang === 'si' ? step.titleSi : step.title;
            const stepCat = lang === 'si' ? step.categorySi : step.category;

            return (
              <div key={step.number} className="relative flex flex-col">
                <button
                  onClick={() => setSelectedStep(step.number)}
                  className={`p-4 rounded-2xl text-left flex flex-col justify-between h-full transition-all cursor-pointer relative ${
                    isSelected
                      ? isHumanStep
                        ? 'uiobj-card bg-emerald-50 border-emerald-400 shadow-[0_4px_16px_rgba(16,185,129,0.3)] scale-[1.03]'
                        : 'uiobj-card bg-purple-50 border-purple-400 shadow-[0_4px_16px_rgba(168,85,247,0.3)] scale-[1.03]'
                      : isHumanStep
                        ? 'uiobj-card border-emerald-300/80 hover:border-emerald-500'
                        : 'uiobj-card hover:border-sky-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2.5">
                    <span className="text-2xl filter drop-shadow">{step.icon}</span>
                    <span 
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full font-mono ${
                        isHumanStep
                          ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                          : 'bg-sky-100 text-sky-900 border border-sky-300'
                      }`}
                    >
                      {lang === 'si' ? `පියවර ${step.number}` : `Step ${step.number}`}
                    </span>
                  </div>

                  <div className="flex-1">
                    <div className="font-extrabold text-xs text-slate-900 leading-tight">
                      {stepTitle}
                    </div>
                    <div className="text-[10px] text-slate-600 font-semibold mt-1">
                      {isHumanStep ? (lang === 'si' ? 'විද්‍යාඥයා' : step.role) : (lang === 'si' ? 'කෘතිම බුද්ධිය' : step.role)}
                    </div>
                  </div>

                  {isHumanStep ? (
                    <div className="mt-2.5 pt-2 border-t border-emerald-200 text-[10px] text-emerald-800 font-bold flex items-center gap-1">
                      <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{lang === 'si' ? "අවසාන තීරකයා" : "Decision Maker"}</span>
                    </div>
                  ) : (
                    <div className="mt-2.5 pt-2 border-t border-sky-200 text-[10px] text-purple-800 font-bold font-mono">
                      {stepCat}
                    </div>
                  )}

                  {isSimulatingPipeline && isPassedSim && (
                    <div className="absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                  )}
                </button>

                {/* Arrow connector between steps on desktop */}
                {idx < 5 && (
                  <div className="hidden lg:flex absolute -right-2.5 top-1/2 -translate-y-1/2 z-10 text-sky-400 pointer-events-none text-xs font-mono font-bold">
                    →
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* STEP DETAILS CARD IN UI + OBJECT INSET WELL */}
        <div className="p-4 sm:p-6 uiobj-inset mt-3 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-sky-200/80 pb-3.5">
            <div className="flex items-center gap-3.5">
              <span className="text-3xl filter drop-shadow">{activeStep.icon}</span>
              <div>
                <h3 className="font-black text-sm sm:text-base text-slate-900 flex items-center gap-2">
                  <span>{lang === 'si' ? `පියවර ${activeStep.number}: ${activeStep.titleSi}` : `Step ${activeStep.number}: ${activeStep.title}`}</span>
                </h3>
                <span className="text-xs text-purple-900 font-mono font-semibold">
                  {lang === 'si' ? "කාර්යය:" : "Role:"} <strong className="text-slate-900">{activeStep.role}</strong> ({lang === 'si' ? activeStep.categorySi : activeStep.category})
                </span>
              </div>
            </div>

            <div className="px-3.5 py-1.5 rounded-full bg-white/90 border border-sky-300 text-xs text-slate-800 font-mono shadow-sm self-start sm:self-auto font-semibold">
              {activeStep.keyMetric}
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
            {lang === 'si' ? activeStep.summarySi : activeStep.summary}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
            <div className="p-3.5 rounded-xl uiobj-card">
              <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Algorithm / Core Process:</span>
              <strong className="text-slate-900 font-mono text-xs">{activeStep.algorithm}</strong>
            </div>

            <div className="p-3.5 rounded-xl uiobj-card">
              <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Input Telemetry:</span>
              <span className="text-slate-700 text-xs font-medium">{activeStep.input}</span>
            </div>

            <div className="p-3.5 rounded-xl uiobj-card">
              <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Validated Output:</span>
              <span className="text-emerald-700 text-xs font-bold">{activeStep.output}</span>
            </div>
          </div>
        </div>
      </div>

      {/* TWO SUB-SECTIONS: EXPLAINABLE AI FEATURE BREAKDOWN & HUMAN INVESTIGATION CONSOLE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 relative z-10">
        
        {/* LEFT COLUMN: EXPLAINABLE AI (XAI) FEATURE IMPORTANCE (FLEX 5 COLS) */}
        <div className="lg:col-span-5 uiobj-panel p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-sky-200/80 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full object-sphere-purple flex items-center justify-center text-xs">
                <Binary className="w-3 h-3 text-white" />
              </div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Model Feature Importance (XAI)
              </h3>
            </div>
            <span className="text-[10px] text-slate-500 font-mono font-semibold">Explainable Weighting</span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed font-medium">
            How the AI evaluates raw triggers before presenting them to the human scientist:
          </p>

          <div className="space-y-4 text-xs">
            
            {/* Feature 1 */}
            <div className="p-3 rounded-xl uiobj-inset space-y-1.5">
              <div className="flex justify-between text-slate-800">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full object-sphere-purple" />
                  <span className="font-semibold">Parallax Motion Vector (March vs Sept):</span>
                </span>
                <strong className="text-purple-900 font-mono font-bold">34% Impact</strong>
              </div>
              <div className="w-full bg-sky-100/90 h-2.5 rounded-full overflow-hidden border border-sky-300/80 p-0.5 shadow-inner">
                <div className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full" style={{ width: '34%' }} />
              </div>
              <span className="text-[10px] text-slate-600 font-medium block">Calculates heliocentric baseline shift ~80px.</span>
            </div>

            {/* Feature 2 */}
            <div className="p-3 rounded-xl uiobj-inset space-y-1.5">
              <div className="flex justify-between text-slate-800">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full object-sphere-magenta" />
                  <span className="font-semibold">SPHEREx Array 6 (4.8μm) Thermal Excess:</span>
                </span>
                <strong className="text-pink-900 font-mono font-bold">28% Impact</strong>
              </div>
              <div className="w-full bg-sky-100/90 h-2.5 rounded-full overflow-hidden border border-sky-300/80 p-0.5 shadow-inner">
                <div className="h-full bg-gradient-to-r from-rose-500 to-pink-500 rounded-full" style={{ width: '28%' }} />
              </div>
              <span className="text-[10px] text-slate-600 font-medium block">Identifies 40K thermal blackbody peak of cold worlds.</span>
            </div>

            {/* Feature 3 */}
            <div className="p-3 rounded-xl uiobj-inset space-y-1.5">
              <div className="flex justify-between text-slate-800">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full object-sphere-cyan" />
                  <span className="font-semibold">Multi-Band Photometric Consistency:</span>
                </span>
                <strong className="text-sky-900 font-mono font-bold">22% Impact</strong>
              </div>
              <div className="w-full bg-sky-100/90 h-2.5 rounded-full overflow-hidden border border-sky-300/80 p-0.5 shadow-inner">
                <div className="h-full bg-gradient-to-r from-sky-400 to-cyan-500 rounded-full" style={{ width: '22%' }} />
              </div>
              <span className="text-[10px] text-slate-600 font-medium block">Ensures presence across contiguous spectral bands.</span>
            </div>

            {/* Feature 4 */}
            <div className="p-3 rounded-xl uiobj-inset space-y-1.5">
              <div className="flex justify-between text-slate-800">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full object-sphere-emerald" />
                  <span className="font-semibold">Keplerian Orbital Dynamics Feasibility:</span>
                </span>
                <strong className="text-emerald-900 font-mono font-bold">16% Impact</strong>
              </div>
              <div className="w-full bg-sky-100/90 h-2.5 rounded-full overflow-hidden border border-sky-300/80 p-0.5 shadow-inner">
                <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full" style={{ width: '16%' }} />
              </div>
              <span className="text-[10px] text-slate-600 font-medium block">Checks gravitational bound state with Sun ($T^2 = a^3$).</span>
            </div>

          </div>

          <div className="p-3.5 rounded-xl uiobj-inset text-[11px] text-slate-700 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-purple-600 flex-shrink-0 mt-0.5" />
            <p className="leading-snug">
              The model produces <em>zero black-box scores</em>; each recommendation exposes exact photometric derivations for human audit.
            </p>
          </div>
        </div>

        {/* RIGHT COLUMN: STEP 6 HUMAN INVESTIGATION WORKBENCH (FLEX 7 COLS) */}
        <div className="lg:col-span-7 uiobj-panel p-5 sm:p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-sky-200/80 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full object-sphere-emerald flex items-center justify-center text-xs">
                <UserCheck className="w-3 h-3 text-white" />
              </div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                Step 6: Human Investigation & Verification Console
              </h3>
            </div>

            <div className="flex items-center gap-2">
              {decisionCounts.verified > 0 && (
                <span className="text-[10px] bg-emerald-100 text-emerald-900 border border-emerald-300 px-2 py-0.5 rounded-full font-mono font-bold">
                  {decisionCounts.verified} Verified
                </span>
              )}
              {decisionCounts.followup > 0 && (
                <span className="text-[10px] bg-orange-100 text-orange-900 border border-orange-300 px-2 py-0.5 rounded-full font-mono font-bold">
                  {decisionCounts.followup} Follow-up
                </span>
              )}
              <span className="text-[10px] bg-emerald-100 text-emerald-900 border border-emerald-300 px-2.5 py-0.5 rounded-full font-mono font-bold">
                Scientist In Charge
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed font-medium">
            As the research astronomer, review the AI-assisted candidates below. Confirm physical validity or request secondary telescope time:
          </p>

          <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
            {RAW_CANDIDATES.slice(0, 4).map((cand) => {
              const currentDecision = candidateDecisions[cand.id] || 'pending';

              return (
                <div
                  key={cand.id}
                  className="p-4 rounded-2xl uiobj-card text-xs space-y-2.5"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full object-sphere-orange inline-block" />
                        <span className="text-sm font-extrabold">{cand.name}</span>
                        <span className="font-mono text-[10px] text-slate-500 font-semibold">({cand.id})</span>
                      </div>
                      <div className="text-[11px] text-slate-600 mt-1 font-medium">
                        {cand.category} • Dist: <strong className="text-slate-900">{cand.distanceAU.toFixed(1)} AU</strong> • Band #{cand.peakBand} ({cand.peakWavelength}μm)
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 font-mono text-[11px] bg-sky-100/80 px-3 py-1 rounded-full border border-sky-300 self-start sm:self-auto font-semibold">
                      <span className="text-slate-600">AI Confidence:</span>
                      <strong className="text-emerald-700 font-bold">{cand.snr}%</strong>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                    {cand.description}
                  </p>

                  {/* HUMAN ACTION BUTTONS */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2.5 border-t border-sky-200/80">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleDecision(cand.id, 'verified')}
                        className={`px-3 py-1 text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1.5 ${
                          currentDecision === 'verified'
                            ? 'uiobj-btn-emerald'
                            : 'uiobj-btn-secondary text-slate-700 hover:text-slate-950'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Verified Discovery ✓</span>
                      </button>

                      <button
                        onClick={() => handleDecision(cand.id, 'followup')}
                        className={`px-3 py-1 text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1.5 ${
                          currentDecision === 'followup'
                            ? 'uiobj-btn-primary'
                            : 'uiobj-btn-secondary text-slate-700 hover:text-slate-950'
                        }`}
                      >
                        <Search className="w-3.5 h-3.5" />
                        <span>Needs Follow-up 🔭</span>
                      </button>

                      <button
                        onClick={() => handleDecision(cand.id, 'rejected')}
                        className={`px-2.5 py-1 text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1 ${
                          currentDecision === 'rejected'
                            ? 'uiobj-btn-danger'
                            : 'uiobj-btn-secondary text-slate-600 hover:text-rose-700'
                        }`}
                      >
                        <span>Flag Noise</span>
                      </button>
                    </div>

                    {onInspectSkyCandidate && (
                      <button
                        onClick={() => onInspectSkyCandidate(cand.peakBand - 1, cand.ra, cand.dec)}
                        className="text-orange-600 hover:text-orange-800 font-bold text-[11px] flex items-center gap-1.5 cursor-pointer ml-auto"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect Band</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3.5 uiobj-inset text-xs text-emerald-900 flex items-center gap-2.5 border border-emerald-300 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span className="leading-snug">
              <strong>Scientific Protocol Enforced:</strong> Automated models cannot register celestial coordinates without human scientist sign-off.
            </span>
          </div>
        </div>

      </div>

    </div>
  );
}
