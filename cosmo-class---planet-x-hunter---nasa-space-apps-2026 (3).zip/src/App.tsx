import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Play, 
  Pause, 
  Trash2, 
  Download, 
  Volume2, 
  VolumeX, 
  Crosshair, 
  Sparkles,
  ChevronLeft,
  ChevronRight,
  FastForward,
  Eye,
  Info,
  HelpCircle,
  CheckCircle2,
  ExternalLink,
  Compass,
  Radio,
  FlaskConical,
  ArrowRight,
  Sliders,
  Brain,
  BookOpen,
  Database
} from 'lucide-react';
import { SPHEREX_102_BANDS, SPHERExBand } from './spherexBands';
import { ExperimentLab } from './ExperimentLab';
import { AiAnalysis } from './AiAnalysis';
import { EvidenceSources } from './EvidenceSources';
import { CosmoClassSuite } from './CosmoClassSuite';
import { Language, TRANSLATIONS } from './translations';

const NASA_API_KEY = "5LjjC66pBkXh2LmFdpxIRRSqhFSXFXyYXM4fft2V";
const FALLBACK_IMAGE = "https://apod.nasa.gov/apod/image/2503/SPHERExLaunch_SpaceX_1080.jpg";

const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;

interface Discovery {
  id: string;
  ra: string;
  dec: string;
  time: string;
}

// Generate 200 fixed stars so they remain 100% constant across surveys
function generateStars() {
  const list = [];
  let seed = 42;
  const rnd = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
  for (let i = 0; i < 200; i++) {
    list.push({
      x: rnd() * CANVAS_WIDTH,
      y: rnd() * CANVAS_HEIGHT,
      r: 0.8 + rnd() * 1.5,
    });
  }
  return list;
}

const FIXED_STARS = generateStars();

export default function App() {
  // Bilingual localization state: defaults to 'si' (Sinhala) for Sri Lankan users with instant English toggle
  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('cosmo_lang');
      if (saved === 'en' || saved === 'si') return saved;
    } catch (e) {
      // fallback
    }
    return 'si';
  });

  const toggleLang = (newLang: Language) => {
    setLang(newLang);
    try {
      localStorage.setItem('cosmo_lang', newLang);
    } catch (e) {
      console.warn("Storage save error", e);
    }
  };

  const t = TRANSLATIONS[lang];

  const [survey, setSurvey] = useState<1 | 2>(1);
  const [blinking, setBlinking] = useState<boolean>(true);
  const [blind, setBlind] = useState<boolean>(false);
  const [sliderVal, setSliderVal] = useState<number>(0);
  const [discoveries, setDiscoveries] = useState<Discovery[]>([]);
  const [bgImage, setBgImage] = useState<string>(FALLBACK_IMAGE);
  const [imageTitle, setImageTitle] = useState<string>("SPHEREx Launch");
  const [apiActive, setApiActive] = useState<boolean>(true);
  const [flashScreen, setFlashScreen] = useState<boolean>(false);
  const [showHelp, setShowHelp] = useState<boolean>(true);
  const [showSriLankaGuide, setShowSriLankaGuide] = useState<boolean>(true);
  const [currentView, setCurrentView] = useState<'survey' | 'experiment' | 'ai' | 'evidence'>('survey');

  // 102 SPHEREx Spectral Bands State (0 to 101 = Bands 1 to 102)
  const [bandIndex, setBandIndex] = useState<number>(0);
  const [autoScanBands, setAutoScanBands] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const lastBeepRef = useRef<number>(0);

  const currentBand: SPHERExBand = SPHEREX_102_BANDS[bandIndex] || SPHEREX_102_BANDS[0];
  const prevBandIndex = bandIndex === 0 ? 101 : bandIndex - 1;
  const nextBandIndex = bandIndex === 101 ? 0 : bandIndex + 1;
  const prevBandItem = SPHEREX_102_BANDS[prevBandIndex];
  const nextBandItem = SPHEREX_102_BANDS[nextBandIndex];

  // Initialize discoveries from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('cosmo');
      if (saved) {
        setDiscoveries(JSON.parse(saved));
      }
    } catch (e) {
      console.warn("Storage load error", e);
    }
  }, []);

  // Fetch real NASA APOD Image on mount
  useEffect(() => {
    let active = true;
    async function fetchImage() {
      try {
        const res = await fetch(`https://api.nasa.gov/planetary/apod?api_key=${NASA_API_KEY}`);
        if (!res.ok) throw new Error("APOD fetch failed");
        const data = await res.json();
        const url = data.hdurl || data.url;
        if (url && active) {
          setBgImage(url);
          if (data.title) setImageTitle(data.title);
          setApiActive(true);
        }
      } catch (err) {
        console.warn("Using SPHEREx default background image", err);
        if (active) {
          setBgImage(FALLBACK_IMAGE);
          setImageTitle("SPHEREx Launch");
          setApiActive(true);
        }
      }
    }
    fetchImage();
    return () => {
      active = false;
    };
  }, []);

  // Auto Blink interval toggling between Survey 1 and Survey 2 every 450ms
  useEffect(() => {
    if (!blinking) return;
    const timer = setInterval(() => {
      setSurvey((prev) => {
        const next = prev === 1 ? 2 : 1;
        setSliderVal(next === 1 ? 0 : 100);
        return next;
      });
    }, 450);

    return () => clearInterval(timer);
  }, [blinking]);

  // Sync survey state with slider
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBlinking(false);
    const val = Number(e.target.value);
    setSliderVal(val);
    setSurvey(val < 50 ? 1 : 2);
  };

  const initAudio = useCallback(() => {
    if (!audioCtxRef.current) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        audioCtxRef.current = new AudioCtx();
      }
    }
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  }, []);

  // Frequency tone feedback mapping 0.75 - 5.0 μm to acoustic scale
  const playFrequencyTone = useCallback((wavelength: number) => {
    try {
      initAudio();
      const ctx = audioCtxRef.current;
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      // Shorter optical wavelength = higher frequency; Deep IR = lower resonant tone
      const freq = 680 - ((wavelength - 0.75) / (5.0 - 0.75)) * 440;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.1);
    } catch (e) {
      console.warn("Tone error", e);
    }
  }, [initAudio]);

  const handlePrevBand = useCallback(() => {
    setBandIndex((prev) => {
      const next = prev === 0 ? 101 : prev - 1;
      playFrequencyTone(SPHEREX_102_BANDS[next].wavelength);
      return next;
    });
  }, [playFrequencyTone]);

  const handleNextBand = useCallback(() => {
    setBandIndex((prev) => {
      const next = prev === 101 ? 0 : prev + 1;
      playFrequencyTone(SPHEREX_102_BANDS[next].wavelength);
      return next;
    });
  }, [playFrequencyTone]);

  const jumpToBand = useCallback((idx: number) => {
    const clamped = Math.max(0, Math.min(101, idx));
    setBandIndex(clamped);
    playFrequencyTone(SPHEREX_102_BANDS[clamped].wavelength);
  }, [playFrequencyTone]);

  const handleInspectCandidate = useCallback((targetBand: number, ra: string, dec: string) => {
    jumpToBand(targetBand);
    setCurrentView('survey');
    // Ensure candidate is recorded in discoveries list
    setDiscoveries((prev) => {
      const exists = prev.some((d) => d.ra === ra && d.dec === dec);
      if (exists) return prev;
      const newD: Discovery = {
        id: Date.now().toString(),
        ra,
        dec,
        time: new Date().toLocaleTimeString(),
      };
      const updated = [newD, ...prev];
      try {
        localStorage.setItem('cosmo', JSON.stringify(updated));
      } catch (e) {
        console.warn("Storage save error", e);
      }
      return updated;
    });
  }, [jumpToBand]);

  // Keyboard navigation for 102 bands using Left / Right Arrow keys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handlePrevBand();
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleNextBand();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handlePrevBand, handleNextBand]);

  // Auto-scan cycling through all 102 bands like an infrared timelapse
  useEffect(() => {
    if (!autoScanBands) return;
    const interval = setInterval(() => {
      setBandIndex((prev) => {
        const next = prev === 101 ? 0 : prev + 1;
        playFrequencyTone(SPHEREX_102_BANDS[next].wavelength);
        return next;
      });
    }, 300);
    return () => clearInterval(interval);
  }, [autoScanBands, playFrequencyTone]);

  // Draw 200 fixed stars on canvas with false-color spectral filter matching currentBand
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Starfield rendering
    FIXED_STARS.forEach((s, idx) => {
      ctx.beginPath();
      const isCoolStar = idx % 4 === 0;
      let starColor = "rgba(255, 255, 255, 0.95)";
      if (currentBand.wavelength > 3.8) {
        starColor = isCoolStar ? "rgba(254, 215, 170, 0.95)" : "rgba(224, 242, 254, 0.75)";
      } else if (currentBand.wavelength < 1.2) {
        starColor = isCoolStar ? "rgba(255, 255, 255, 0.75)" : "rgba(240, 249, 255, 0.95)";
      }

      ctx.fillStyle = starColor;
      ctx.arc(s.x, s.y, s.r * currentBand.starShift, 0, Math.PI * 2);
      ctx.fill();

      // Atmospheric/space diffraction corona on bright stars
      if (s.r > 1.8) {
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r * 2.2, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(56, 189, 248, 0.12)";
        ctx.fill();
      }
    });
  }, [currentBand]);

  // Red dot coordinates:
  // Survey 1: (120, 150)
  // Survey 2: (200, 170) -> 80px shifted
  const targetX = survey === 1 ? 120 : 200;
  const targetY = survey === 1 ? 150 : 170;

  // Canvas click handles discovery
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;

    const x = ((e.clientX - rect.left) * scaleX).toFixed(1);
    const y = ((e.clientY - rect.top) * scaleY).toFixed(1);

    const newDisc: Discovery = {
      id: Date.now().toString(),
      ra: x,
      dec: y,
      time: new Date().toLocaleTimeString(),
    };

    const nextList = [newDisc, ...discoveries];
    setDiscoveries(nextList);
    try {
      localStorage.setItem('cosmo', JSON.stringify(nextList));
    } catch (err) {
      console.warn("Storage save error", err);
    }

    // Flash background effect
    setFlashScreen(true);
    setTimeout(() => setFlashScreen(false), 150);

    // Audio confirmation sound
    playFlagSound();
  };

  const deleteDiscovery = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = discoveries.filter(d => d.id !== id);
    setDiscoveries(filtered);
    localStorage.setItem('cosmo', JSON.stringify(filtered));
  };

  const clearDiscoveries = () => {
    setDiscoveries([]);
    localStorage.removeItem('cosmo');
  };

  const exportDiscoveries = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(discoveries, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `SPHEREx_Discoveries_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const playFlagSound = () => {
    try {
      initAudio();
      const ctx = audioCtxRef.current;
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1174.66, ctx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch (e) {
      console.warn("Sound error", e);
    }
  };

  // Sonar audio feedback for blind / accessibility mode
  const handleViewerMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!blind) return;
    initAudio();
    const ctx = audioCtxRef.current;
    if (!ctx) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;

    const mx = (e.clientX - rect.left) * scaleX;
    const my = (e.clientY - rect.top) * scaleY;

    const dist = Math.hypot(mx - targetX, my - targetY);

    const now = Date.now();
    if (now - lastBeepRef.current < 90) return;
    lastBeepRef.current = now;

    if (dist < 300) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = Math.max(120, 850 - dist * 2.8);
      gain.gain.value = Math.max(0.01, (1 - dist / 300) * 0.2);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    }
  };

  const toggleBlink = () => {
    initAudio();
    setBlinking(!blinking);
  };

  const toggleBlind = () => {
    initAudio();
    setBlind(!blind);
  };

  return (
    <div 
      className={`min-h-screen font-sans text-slate-800 flex flex-col justify-between transition-colors duration-150 ${
        flashScreen ? 'bg-red-100' : 'bg-gradient-to-b from-white via-[#f0f8ff] to-[#e0f0fe]'
      }`}
    >
      {/* UI + OBJECT TRANSLUCENT HEADER IN WHITE & LIGHT BLUE */}
      <header className="uiobj-panel rounded-none sm:rounded-b-2xl border-x-0 border-t-0 py-3.5 px-4 sm:px-6 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="relative">
                <img 
                  src="/cosmo-logo.jpg" 
                  alt="COSMO CLASS Space Logo" 
                  className="w-10 h-10 sm:w-11 sm:h-11 rounded-full border-2 border-orange-400 object-cover flex-shrink-0 shadow-md"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full object-sphere-orange animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-base sm:text-lg text-slate-900 tracking-wide">
                    {t.brandTitle}
                  </span>
                  <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-orange-100 text-orange-800 border border-orange-300 font-bold font-mono">
                    {t.brandTag}
                  </span>
                </div>
                <p className="text-xs text-slate-600 font-medium">
                  {t.creatorTag}
                </p>
              </div>
            </div>

            {/* MOBILE LANGUAGE SWITCHER */}
            <div className="flex md:hidden items-center uiobj-inset p-1 rounded-full border border-sky-300">
              <button
                onClick={() => toggleLang('si')}
                className={`px-2 py-0.5 text-[11px] font-bold rounded-full transition-all ${
                  lang === 'si'
                    ? 'bg-orange-500 text-white shadow-sm'
                    : 'text-sky-900'
                }`}
              >
                🇱🇰 සිං
              </button>
              <button
                onClick={() => toggleLang('en')}
                className={`px-2 py-0.5 text-[11px] font-bold rounded-full transition-all ${
                  lang === 'en'
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-sky-900'
                }`}
              >
                🇬🇧 EN
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between md:justify-end gap-2 flex-wrap">
            {/* TACTILE UI + OBJECT VIEW SELECTOR PILLS */}
            <div className="flex items-center uiobj-inset p-1.5 rounded-full overflow-x-auto max-w-full no-scrollbar gap-1.5">
              <button
                onClick={() => setCurrentView('survey')}
                title="102-Band Sky Survey"
                className={`px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  currentView === 'survey'
                    ? 'uiobj-btn-primary'
                    : 'uiobj-btn-secondary text-sky-900 hover:text-sky-950'
                }`}
              >
                <Radio className="w-3.5 h-3.5" />
                <span>{t.navSurvey}</span>
              </button>
              <button
                onClick={() => setCurrentView('experiment')}
                title="Experiment Mode (Parameters 12 → 4)"
                className={`px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  currentView === 'experiment'
                    ? 'uiobj-btn-emerald'
                    : 'uiobj-btn-secondary text-sky-900 hover:text-sky-950'
                }`}
              >
                <FlaskConical className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t.navExperiment}</span>
              </button>
              <button
                onClick={() => setCurrentView('ai')}
                title="AI Analysis Pipeline (Human-in-the-Loop)"
                className={`px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  currentView === 'ai'
                    ? 'uiobj-btn-primary'
                    : 'uiobj-btn-secondary text-sky-900 hover:text-sky-950'
                }`}
              >
                <Brain className="w-3.5 h-3.5 text-purple-600" />
                <span>{t.navAi}</span>
              </button>
              <button
                onClick={() => setCurrentView('evidence')}
                title="NASA Evidence & Sources"
                className={`px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  currentView === 'evidence'
                    ? 'uiobj-btn-primary'
                    : 'uiobj-btn-secondary text-sky-900 hover:text-sky-950'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                <span>{t.navEvidence}</span>
              </button>
            </div>

            {/* BILINGUAL LANGUAGE SWITCHER (DESKTOP) */}
            <div className="hidden md:flex items-center uiobj-inset p-1 rounded-full border border-sky-300 shadow-sm">
              <button
                onClick={() => toggleLang('si')}
                className={`px-3 py-1 text-xs font-black rounded-full transition-all flex items-center gap-1 cursor-pointer ${
                  lang === 'si'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-[0_0_12px_rgba(249,115,22,0.4)] scale-105'
                    : 'text-sky-800 hover:text-sky-950'
                }`}
                title="සිංහල භාෂාවෙන් නරඹන්න"
              >
                <span>🇱🇰</span>
                <span>සිංහල</span>
              </button>
              <button
                onClick={() => toggleLang('en')}
                className={`px-3 py-1 text-xs font-black rounded-full transition-all flex items-center gap-1 cursor-pointer ${
                  lang === 'en'
                    ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-[0_0_12px_rgba(14,165,233,0.4)] scale-105'
                    : 'text-sky-800 hover:text-sky-950'
                }`}
                title="Switch to English"
              >
                <span>🇬🇧</span>
                <span>English</span>
              </button>
            </div>

            <button
              onClick={() => setShowSriLankaGuide(!showSriLankaGuide)}
              className={`uiobj-btn-secondary px-3 py-1.5 text-xs font-black flex items-center gap-1.5 cursor-pointer ${
                showSriLankaGuide ? 'border-sky-500 text-sky-900 bg-sky-100' : 'text-sky-800'
              }`}
              title="Sri Lankan Astronomy & Student Discovery Guide"
            >
              <span>🇱🇰</span>
              <span className="hidden sm:inline">{lang === 'si' ? "ශ්‍රී ලංකා මඟපෙන්වීම" : "SL Guide"}</span>
            </button>

            <button
              onClick={() => setShowHelp(!showHelp)}
              className="uiobj-btn-secondary px-3 py-1.5 text-xs font-bold text-sky-800 hover:text-sky-950 flex items-center gap-1.5 cursor-pointer"
              title="How to use this tool"
            >
              <HelpCircle className="w-4 h-4 text-sky-600" />
              <span className="hidden sm:inline">{showHelp ? (lang === 'si' ? "මඟපෙන්වීම සඟවන්න" : "Hide Guide") : (lang === 'si' ? "භාවිතා කරන අයුරු" : "How To")}</span>
            </button>
          </div>
        </div>
      </header>

      {/* SRI LANKAN ASTRONOMY & STUDENT DISCOVERY GUIDE BANNER IN WHITE & LIGHT BLUE */}
      {showSriLankaGuide && (
        <section className="px-4 py-3 max-w-7xl mx-auto w-full">
          <div className="uiobj-panel p-5 sm:p-6 space-y-4 border-sky-300/80 bg-gradient-to-br from-white via-sky-50/90 to-blue-50/80 shadow-[0_16px_40px_rgba(14,165,233,0.12)]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-sky-200/80 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full object-sphere-orange flex items-center justify-center font-bold text-base text-white shadow-md flex-shrink-0">
                  🇱🇰
                </div>
                <div>
                  <h2 className="text-sm sm:text-base font-black text-sky-950 tracking-wide flex items-center gap-2">
                    <span>{t.sriLankaGuideTitle}</span>
                  </h2>
                  <p className="text-[11px] sm:text-xs text-slate-600">
                    {t.sriLankaGuideSubtitle}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 self-start sm:self-auto">
                <span className="text-[10px] font-mono font-bold px-3 py-1 rounded-full bg-sky-100 text-sky-800 border border-sky-300 shadow-sm">
                  {t.sriLankaGuideBadge}
                </span>
                <button
                  onClick={() => setShowSriLankaGuide(false)}
                  className="text-xs text-slate-500 hover:text-slate-900 p-1 rounded-full hover:bg-sky-100 transition-colors"
                  title="Close Guide"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="uiobj-card p-4 space-y-2 border-amber-300/80 bg-gradient-to-br from-amber-50/80 to-white shadow-sm">
                <div className="font-extrabold text-amber-950 text-xs sm:text-sm flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg object-sphere-orange flex items-center justify-center text-xs text-white">🪐</span>
                  <span>{t.guideWhatIsPlanetXTitle}</span>
                </div>
                <p className="text-slate-600 text-[11px] sm:text-xs leading-relaxed">
                  {t.guideWhatIsPlanetXDesc}
                </p>
              </div>

              <div className="uiobj-card p-4 space-y-2 border-sky-300/80 bg-gradient-to-br from-sky-50/80 to-white shadow-sm">
                <div className="font-extrabold text-sky-950 text-xs sm:text-sm flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg object-sphere-cyan flex items-center justify-center text-xs text-white">⚡</span>
                  <span>{t.guideBlinkTitle}</span>
                </div>
                <p className="text-slate-600 text-[11px] sm:text-xs leading-relaxed">
                  {t.guideBlinkDesc}
                </p>
              </div>

              <div className="uiobj-card p-4 space-y-2 border-purple-300/80 bg-gradient-to-br from-purple-50/80 to-white shadow-sm">
                <div className="font-extrabold text-purple-950 text-xs sm:text-sm flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg object-sphere-purple flex items-center justify-center text-xs text-white">🌈</span>
                  <span>{t.guideSpectraTitle}</span>
                </div>
                <p className="text-slate-600 text-[11px] sm:text-xs leading-relaxed">
                  {t.guideSpectraDesc}
                </p>
              </div>

              <div className="uiobj-card p-4 space-y-2 border-emerald-300/80 bg-gradient-to-br from-emerald-50/80 to-white shadow-sm">
                <div className="font-extrabold text-emerald-950 text-xs sm:text-sm flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg object-sphere-emerald flex items-center justify-center text-xs text-white">🇱🇰</span>
                  <span>{t.guideSriLankaRoleTitle}</span>
                </div>
                <p className="text-slate-600 text-[11px] sm:text-xs leading-relaxed">
                  {t.guideSriLankaRoleDesc}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* SIMPLE 3-STEP USER GUIDE IN WHITE & LIGHT BLUE */}
      {showHelp && (
        <section className="px-4 py-3 max-w-7xl mx-auto w-full">
          <div className="uiobj-panel p-5 sm:p-6 space-y-4 bg-gradient-to-br from-white via-sky-50/70 to-blue-50/60 border border-sky-200 shadow-[0_12px_32px_rgba(14,165,233,0.1)]">
            <div className="flex items-center justify-between border-b border-sky-200/80 pb-3">
              <h2 className="text-sm font-black text-orange-600 uppercase tracking-wider flex items-center gap-2">
                <Info className="w-4 h-4 text-orange-600" />
                <span>{t.quickGuideTitle}</span>
              </h2>
              <span className="text-xs text-slate-500 hidden sm:inline">
                {t.quickGuideSubtitle}
              </span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="uiobj-card p-4 space-y-2 bg-white/90 border border-sky-200/90 shadow-sm">
                <div className="font-bold text-slate-900 flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-full object-sphere-cyan text-white flex items-center justify-center font-black text-xs shadow-md">1</span>
                  <span>{t.step1Title}</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  {t.step1Desc}
                </p>
              </div>

              <div className="uiobj-card p-4 space-y-2 bg-white/90 border border-sky-200/90 shadow-sm">
                <div className="font-bold text-slate-900 flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-full object-sphere-orange text-white flex items-center justify-center font-black text-xs shadow-md">2</span>
                  <span>{t.step2Title}</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  {t.step2Desc}
                </p>
              </div>

              <div className="uiobj-card p-4 space-y-2 bg-white/90 border border-sky-200/90 shadow-sm">
                <div className="font-bold text-slate-900 flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-full object-sphere-emerald text-white flex items-center justify-center font-black text-xs shadow-md">3</span>
                  <span>{t.step3Title}</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  {t.step3Desc}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {currentView === 'experiment' && (
        <main className="flex-1 w-full max-w-7xl mx-auto p-3 sm:p-4">
          <ExperimentLab 
            onInspectCandidate={handleInspectCandidate} 
            onReturnToSurvey={() => setCurrentView('survey')} 
            lang={lang}
          />
        </main>
      )}

      {currentView === 'ai' && (
        <main className="flex-1 w-full max-w-7xl mx-auto p-3 sm:p-4">
          <AiAnalysis 
            onInspectSkyCandidate={handleInspectCandidate} 
            lang={lang}
          />
        </main>
      )}

      {currentView === 'evidence' && (
        <main className="flex-1 w-full max-w-7xl mx-auto p-3 sm:p-4">
          <EvidenceSources lang={lang} />
        </main>
      )}

      {currentView === 'survey' && (
        /* MAIN INTERACTIVE WORKSPACE WITH UI + OBJECT AESTHETICS */
        <div className="relative w-full max-w-7xl mx-auto px-3 sm:px-4 py-2 overflow-hidden">
          {/* VIBRANT 3D GLOWING CELESTIAL SPHERES (MATCHING REFERENCE MOCKUP) */}
          <div className="absolute -top-12 -left-12 w-72 h-72 rounded-full object-sphere-magenta pointer-events-none -z-10 opacity-70 animate-pulse duration-1000" />
          <div className="absolute top-1/4 -right-16 w-88 h-88 rounded-full object-sphere-orange pointer-events-none -z-10 opacity-60" />
          <div className="absolute -bottom-16 left-1/3 w-80 h-80 rounded-full object-sphere-purple pointer-events-none -z-10 opacity-60" />
          <div className="absolute top-1/2 left-8 w-28 h-28 rounded-full object-sphere-cyan pointer-events-none -z-10 opacity-50" />

          <main className="flex-1 flex flex-col lg:flex-row w-full gap-5 relative z-10">
          
          {/* LEFT COLUMN: THE IMAGE VIEWER (FLEX 3) - UI + OBJECT COCKPIT */}
          <section className="flex-[3] flex flex-col uiobj-panel overflow-hidden">
          
          {/* TOP MISSION CONTROL: FULLY RESPONSIVE 102-BAND TELEMETRY & NAVIGATION */}
          <div className="p-4 sm:p-5 uiobj-card rounded-t-3xl border-b border-sky-200/80 flex flex-col gap-3">
            
            {/* Top Info Bar */}
            <div className="flex flex-wrap items-center justify-between gap-1.5 text-xs text-slate-600">
              <span className="font-bold text-slate-900 flex items-center gap-2">
                <span className="w-3 h-3 rounded-full object-sphere-orange animate-pulse" />
                <span>{t.spectrometerTitle}</span>
              </span>
              <span className="text-slate-500 font-mono text-[11px] sm:text-xs">
                {t.keyboardShortcuts}
              </span>
            </div>

            {/* RESPONSIVE LAYOUT FOR ARROW BUTTONS & CENTER HUD */}
            <div className="flex flex-col md:flex-row items-stretch justify-between gap-3">
              
              {/* 1) PREVIOUS BAND BUTTON (Frosted Glass Pill) */}
              <button
                id="prevBandBtn"
                onClick={handlePrevBand}
                title={lang === 'si' ? "පෙර තරංග ආයාමය බලන්න (වම් ඊතලය)" : "View Previous Spectral Band (Left Arrow Key)"}
                className="hidden md:flex flex-1 max-w-[210px] lg:max-w-[240px] uiobj-btn-secondary px-4 py-3 font-bold items-center gap-2 text-xs sm:text-sm text-sky-900"
              >
                <ChevronLeft className="w-5 h-5 flex-shrink-0 text-sky-600" />
                <div className="text-left leading-tight min-w-0 flex-1">
                  <div className="font-black text-xs sm:text-sm truncate text-sky-900">{t.prevBandBtn}</div>
                  <div className="text-[11px] text-sky-700 font-mono opacity-90 truncate">
                    {lang === 'si' ? `තරංග #${prevBandItem.band}` : `Band #${prevBandItem.band}`} ({prevBandItem.wavelength} μm)
                  </div>
                </div>
              </button>

              {/* CENTER ACTIVE BAND HUD DISPLAY - RECESSED INSET */}
              <div className="flex-1 uiobj-inset px-4 py-3 rounded-2xl flex flex-col justify-center text-center">
                <div className="flex items-center justify-center gap-2 flex-wrap text-xs sm:text-sm">
                  <span 
                    className="w-4 h-4 rounded-full shadow-md inline-block flex-shrink-0"
                    style={{ backgroundColor: currentBand.color }}
                  />
                  <span className="font-black text-slate-900 tracking-wide">
                    {lang === 'si' ? `තරංග #${currentBand.band}` : `BAND #${currentBand.band}`} <span className="text-slate-500 font-normal">{t.bandOf102}</span>
                  </span>
                  <span className="text-orange-600 font-mono font-black">
                    λ = {currentBand.wavelength} μm
                  </span>
                  <span className="text-[11px] sm:text-xs px-2.5 py-0.5 rounded-full bg-sky-100 text-sky-900 border border-sky-300 font-semibold shadow-xs">
                    {lang === 'si' ? currentBand.arrayNameSi : currentBand.arrayName}
                  </span>
                </div>

                <div className="text-[11px] sm:text-xs text-slate-700 font-medium mt-1 leading-snug">
                  <span className="text-orange-600 font-bold">
                    {lang === 'si' ? currentBand.sinhalaScienceFeature : currentBand.scienceFeature}
                  </span>
                  <span className="text-slate-600 hidden sm:inline">
                    {" • "}
                    {lang === 'si' ? currentBand.sinhalaDesc : currentBand.englishDesc}
                  </span>
                </div>
                <p className="text-[10px] text-slate-600 sm:hidden mt-0.5">
                  {lang === 'si' ? currentBand.sinhalaDesc : currentBand.englishDesc}
                </p>

                {/* 0.75 - 5.00 μm Spectrum Progress Bar with wavelength scale */}
                <div className="w-full mt-2.5">
                  <div className="w-full bg-sky-100/90 h-3 rounded-full overflow-hidden p-0.5 border border-sky-300/80 relative shadow-inner">
                    <div 
                      className="h-full rounded-full bg-gradient-to-r from-sky-400 via-emerald-400 to-orange-500 transition-all duration-150"
                      style={{ width: `${(currentBand.band / 102) * 100}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[9px] sm:text-[10px] text-slate-500 font-mono mt-1 px-1">
                    <span>0.75 μm</span>
                    <span>1.64 μm</span>
                    <span>3.82 μm</span>
                    <span>5.00 μm</span>
                  </div>
                </div>
              </div>

              {/* 2) NEXT BAND BUTTON (Glowing Primary Action Button matching reference mockup) */}
              <button
                id="nextBandBtn"
                onClick={handleNextBand}
                title={lang === 'si' ? "මීළඟ තරංග ආයාමය බලන්න (දකුණු ඊතලය)" : "View Next Spectral Band (Right Arrow Key)"}
                className="hidden md:flex flex-1 max-w-[210px] lg:max-w-[240px] uiobj-btn-primary px-4 py-3 font-bold items-center justify-end gap-2 text-xs sm:text-sm text-white"
              >
                <div className="text-right leading-tight min-w-0 flex-1">
                  <div className="font-black text-xs sm:text-sm truncate">{t.nextBandBtn}</div>
                  <div className="text-[11px] text-amber-100 font-mono opacity-90 truncate">
                    {lang === 'si' ? `තරංග #${nextBandItem.band}` : `Band #${nextBandItem.band}`} ({nextBandItem.wavelength} μm)
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 flex-shrink-0" />
              </button>

              {/* MOBILE ONLY: 2 PROMINENT BUTTONS (< md) */}
              <div className="grid grid-cols-2 gap-2 md:hidden">
                <button
                  onClick={handlePrevBand}
                  className="uiobj-btn-secondary px-3 py-2.5 font-bold flex items-center justify-center gap-2 text-xs text-sky-900"
                >
                  <ChevronLeft className="w-4 h-4 flex-shrink-0 text-sky-600" />
                  <div className="text-left leading-tight truncate">
                    <div className="font-black text-xs">{t.prevBandBtn}</div>
                    <div className="text-[10px] text-sky-700 font-mono truncate">
                      #{prevBandItem.band} ({prevBandItem.wavelength} μm)
                    </div>
                  </div>
                </button>

                <button
                  onClick={handleNextBand}
                  className="uiobj-btn-primary px-3 py-2.5 font-bold flex items-center justify-center gap-2 text-xs text-white"
                >
                  <div className="text-right leading-tight truncate">
                    <div className="font-black text-xs">{t.nextBandBtn}</div>
                    <div className="text-[10px] text-amber-100 font-mono truncate">
                      #{nextBandItem.band} ({nextBandItem.wavelength} μm)
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 flex-shrink-0" />
                </button>
              </div>

            </div>

            {/* 6 RESPONSIVE DETECTOR ARRAY QUICK SELECTORS */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 pt-1 border-t border-sky-100">
              {[
                { name: lang === 'si' ? "ශ්‍රේණිය 1" : "Array 1", range: "0.75 - 1.11 μm", jump: 0, label: lang === 'si' ? "දෘශ්‍ය / සමීප අධෝරක්ත" : "Optical / NIR" },
                { name: lang === 'si' ? "ශ්‍රේණිය 2" : "Array 2", range: "1.11 - 1.64 μm", jump: 17, label: lang === 'si' ? "ජල අයිස් (Water Ice)" : "Water Ice" },
                { name: lang === 'si' ? "ශ්‍රේණිය 3" : "Array 3", range: "1.64 - 2.42 μm", jump: 34, label: lang === 'si' ? "කාබන් මොනොක්සයිඩ්" : "Carbon Monoxide" },
                { name: lang === 'si' ? "ශ්‍රේණිය 4" : "Array 4", range: "2.42 - 3.82 μm", jump: 51, label: lang === 'si' ? "කාබනික අංශු දූවිලි" : "Organic Dust" },
                { name: lang === 'si' ? "ශ්‍රේණිය 5" : "Array 5", range: "3.82 - 4.42 μm", jump: 68, label: lang === 'si' ? "CO2 වියළි අයිස්" : "CO2 Dry Ice" },
                { name: lang === 'si' ? "ශ්‍රේණිය 6" : "Array 6", range: "4.42 - 5.00 μm", jump: 85, label: lang === 'si' ? "ප්ලැනට් X උපරිමය 🪐" : "Planet X Peak 🪐" },
              ].map((arr, idx) => {
                const isCurrentArray = currentBand.array === (idx + 1);
                return (
                  <button
                    key={arr.range}
                    onClick={() => jumpToBand(arr.jump)}
                    className={`py-2 px-2.5 rounded-xl text-left sm:text-center transition-all cursor-pointer flex flex-col justify-center ${
                      isCurrentArray
                        ? 'uiobj-btn-sky'
                        : 'bg-white hover:bg-sky-50 text-slate-700 hover:text-sky-950 border border-sky-200/90 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center justify-between sm:justify-center gap-1">
                      <span className="font-bold text-xs">{arr.name}</span>
                      <span className="text-[10px] text-slate-600 font-medium sm:hidden">({arr.range})</span>
                    </div>
                    <div className={`text-[10px] truncate mt-0.5 ${isCurrentArray ? 'text-sky-100' : 'text-sky-700'}`}>
                      {arr.label}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* CANVAS STARFIELD & SKY VIEWER CONTAINER - RECESSED CLAY DISPLAY */}
          <div 
            id="viewer"
            onMouseMove={handleViewerMouseMove}
            className="uiobj-inset relative flex-1 overflow-hidden flex items-center justify-center min-h-[420px] sm:min-h-[500px] select-none p-3 m-3 rounded-2xl"
          >
            {/* Real NASA Background Image (faint opacity 0.25) */}
            <img 
              className="absolute inset-0 w-full h-full object-cover opacity-25 pointer-events-none transition-opacity duration-300"
              src={bgImage} 
              alt="NASA APOD Space Background"
              referrerPolicy="no-referrer"
              onError={(e) => {
                const target = e.currentTarget;
                if (target.src !== FALLBACK_IMAGE) {
                  target.src = FALLBACK_IMAGE;
                } else {
                  target.style.display = 'none';
                }
              }}
            />

            {/* REAL NASA IMAGE BADGE */}
            <div className="absolute top-4 left-4 z-10 px-3.5 py-1.5 rounded-full text-xs text-slate-800 bg-white/95 border border-sky-200 shadow-md backdrop-blur-md pointer-events-none flex items-center gap-1.5">
              <span className="text-sky-600 font-black">{t.nasaImageBadge}</span>
              <strong className="text-slate-900 ml-1">{imageTitle}</strong>
            </div>

            {/* FLOATING OVERLAY ARROW BUTTONS */}
            <button
              onClick={handlePrevBand}
              aria-label="Previous spectral band image"
              title={lang === 'si' ? "පෙර තරංග ආයාමය (වම් ඊතලය)" : "Previous Band (Left Arrow)"}
              className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-3.5 rounded-full text-sky-700 bg-white/95 hover:bg-sky-500 hover:text-white border border-sky-200 shadow-[0_6px_20px_rgba(14,165,233,0.25)] transition-all cursor-pointer hover:scale-110 active:scale-95"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <button
              onClick={handleNextBand}
              aria-label="Next spectral band image"
              title={lang === 'si' ? "මීළඟ තරංග ආයාමය (දකුණු ඊතලය)" : "Next Band (Right Arrow)"}
              className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-3.5 rounded-full text-sky-700 bg-white/95 hover:bg-sky-500 hover:text-white border border-sky-200 shadow-[0_6px_20px_rgba(14,165,233,0.25)] transition-all cursor-pointer hover:scale-110 active:scale-95"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* CANVAS CONTAINER */}
            <div className="relative w-full max-w-[800px] aspect-[4/3] flex items-center justify-center">
              {/* Canvas for 200 Fixed Stars */}
              <canvas 
                id="c"
                ref={canvasRef}
                width={CANVAS_WIDTH}
                height={CANVAS_HEIGHT}
                onClick={handleCanvasClick}
                className="absolute inset-0 w-full h-full z-[2] cursor-crosshair object-contain"
                title={lang === 'si' ? "අපේක්ෂිත ඛණ්ඩාංක (RA/DEC) සටහන් කරගැනීමට ක්ලික් කරන්න" : "Click to log candidate coordinates (RA/DEC)"}
              />

              {/* Glowing Planet X Target Dot - Radiance and size scale with wavelength */}
              {(() => {
                const targetSize = Math.round(14 + currentBand.planetXRadiance * 12);
                const glowSpread = Math.round(8 + currentBand.planetXRadiance * 18);
                return (
                  <div 
                    id="target"
                    className="absolute pointer-events-none z-[3] rounded-full transition-all duration-100 flex items-center justify-center shadow-[4px_6px_12px_rgba(0,0,0,0.6),inset_2px_2px_4px_rgba(255,255,255,0.7)]"
                    style={{
                      width: `${targetSize}px`,
                      height: `${targetSize}px`,
                      backgroundColor: '#ef4444',
                      boxShadow: `0 0 ${glowSpread}px ${Math.round(glowSpread / 2)}px #f87171, 0 0 ${glowSpread * 2}px rgba(239, 68, 68, ${currentBand.planetXRadiance}), inset 2px 2px 4px rgba(255, 255, 255, 0.7)`,
                      left: `${(targetX / CANVAS_WIDTH) * 100}%`,
                      top: `${(targetY / CANVAS_HEIGHT) * 100}%`,
                      transform: 'translate(-50%, -50%)',
                    }}
                  >
                    <div className="w-2.5 h-2.5 rounded-full bg-white shadow-sm" />
                    <div 
                      className="absolute -inset-2 rounded-full animate-ping bg-red-500 pointer-events-none" 
                      style={{ opacity: 0.4 + currentBand.planetXRadiance * 0.5 }}
                    />
                  </div>
                );
              })()}
            </div>

            {/* Bottom-left telemetry pill */}
            <div className="absolute bottom-4 left-4 z-10 px-3.5 py-1.5 rounded-full text-xs text-slate-800 bg-white/95 border border-sky-200 shadow-md backdrop-blur-md pointer-events-none flex items-center gap-2">
              <span>{t.candidatePosition}</span>
              <strong className="text-red-600 font-black font-mono">X:{targetX}, Y:{targetY}</strong>
              <span className="text-sky-700 font-bold">[{survey === 1 ? (lang === 'si' ? 'සර්වේ 1' : 'Survey 1') : (lang === 'si' ? 'සර්වේ 2' : 'Survey 2')}]</span>
              <span className="text-slate-600">• {t.thermalRadiance} {(currentBand.planetXRadiance * 100).toFixed(0)}%</span>
            </div>

            {/* Bottom-right hint */}
            <div className="absolute bottom-4 right-4 z-10 hidden sm:block px-3.5 py-1.5 rounded-full text-xs text-slate-600 bg-white/95 border border-sky-200 shadow-md backdrop-blur-md pointer-events-none">
              {t.clickSkyHint}
            </div>
          </div>
        </section>

        {/* RIGHT COLUMN: CONTROLS & DISCOVERIES SIDEBAR (FLEX 1) - DISTINCT VIBRANT UI + OBJECT PANEL */}
        <aside className="flex-[1] uiobj-panel p-5 flex flex-col justify-between space-y-4 bg-gradient-to-b from-white/95 via-[#f0f8ff]/95 to-[#e6f2fe]/95 border-2 border-sky-200/80 shadow-[0_20px_50px_rgba(14,165,233,0.12)]">
          
          <div className="space-y-4">
            <h2 className="text-sm font-black uppercase tracking-wider text-slate-900 border-b border-sky-200/80 pb-3 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500 shadow-[0_0_10px_#0ea5e9] animate-pulse" />
                <span>{t.missionControlsTitle}</span>
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-black text-sky-900 bg-sky-100 border border-sky-300 shadow-xs">
                {t.spherexHudBadge}
              </span>
            </h2>

            {/* 1) EXPERIMENT LAB QUICK ACCESS CALLOUT - VIBRANT EMERALD CARD */}
            <div className="p-4 rounded-2xl border-2 border-emerald-400/60 space-y-3 bg-gradient-to-br from-emerald-50 via-teal-50/70 to-white shadow-[0_8px_25px_rgba(16,185,129,0.12)] relative overflow-hidden">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                <span className="flex items-center gap-2 text-emerald-800">
                  <FlaskConical className="w-4 h-4 text-emerald-600 drop-shadow-sm" />
                  <span className="font-black tracking-wide">{t.expModeTitle}</span>
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-black bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-xs">
                  {t.expModeBadge}
                </span>
              </div>
              <p className="text-[11px] text-emerald-900/90 leading-snug">
                {t.expModeDesc}
              </p>
              <button
                onClick={() => setCurrentView('experiment')}
                className="w-full py-3 px-4 font-black text-xs text-white uppercase tracking-wider rounded-xl cursor-pointer flex items-center justify-center gap-2 transition-all duration-200 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 shadow-[0_8px_25px_rgba(16,185,129,0.4),inset_0_2px_2px_rgba(255,255,255,0.7)] border border-emerald-200/60 hover:scale-[1.02] active:scale-[0.98]"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>{t.launchExpLabBtn}</span>
              </button>
            </div>

            {/* 2) SURVEY COMPARATOR (BLINK COMPARISON) - VIBRANT CELESTIAL BLUE CARD */}
            <div className="p-4 rounded-2xl border-2 border-sky-400/60 space-y-3.5 bg-gradient-to-br from-sky-50 via-blue-50/70 to-white shadow-[0_8px_25px_rgba(14,165,233,0.12)] relative overflow-hidden">
              <div className="flex items-center justify-between text-xs font-bold text-sky-950">
                <span className="text-sky-900 font-bold">{t.surveyCompTitle}</span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-black text-sky-900 bg-sky-100 border border-sky-300 shadow-xs">
                  {survey === 1 
                    ? (lang === 'si' ? 'සර්වේ 1 (2025 මාර්තු)' : 'Survey 1 (March 2025)') 
                    : (lang === 'si' ? 'සර්වේ 2 (2025 සැප්තැම්බර්)' : 'Survey 2 (Sept 2025)')
                  }
                </span>
              </div>

              {/* Segmented survey selector buttons */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={() => { setBlinking(false); setSurvey(1); setSliderVal(0); }}
                  className={`py-2.5 px-3 text-xs font-black rounded-xl transition-all cursor-pointer ${
                    survey === 1 && !blinking
                      ? 'bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 text-white shadow-[0_6px_20px_rgba(14,165,233,0.4),inset_0_2px_2px_rgba(255,255,255,0.7)] border border-sky-200 hover:scale-[1.02]'
                      : 'bg-white hover:bg-sky-50 text-slate-700 hover:text-sky-950 shadow-xs border border-sky-200/90'
                  }`}
                >
                  {t.survey1Btn}
                </button>
                <button
                  onClick={() => { setBlinking(false); setSurvey(2); setSliderVal(100); }}
                  className={`py-2.5 px-3 text-xs font-black rounded-xl transition-all cursor-pointer ${
                    survey === 2 && !blinking
                      ? 'bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 text-white shadow-[0_6px_20px_rgba(14,165,233,0.4),inset_0_2px_2px_rgba(255,255,255,0.7)] border border-sky-200 hover:scale-[1.02]'
                      : 'bg-white hover:bg-sky-50 text-slate-700 hover:text-sky-950 shadow-xs border border-sky-200/90'
                  }`}
                >
                  {t.survey2Btn}
                </button>
              </div>

              {/* Slider between Survey 1 and Survey 2 */}
              <div className="bg-sky-100/90 p-2 rounded-full border border-sky-300 shadow-inner">
                <input 
                  type="range" 
                  id="slider" 
                  min="0" 
                  max="100" 
                  value={sliderVal} 
                  onChange={handleSliderChange}
                  className="w-full h-2 bg-transparent rounded-lg appearance-none cursor-pointer accent-sky-600"
                  aria-label="Survey comparator slider"
                />
              </div>

              {/* AUTO BLINK DISTINCT BUTTON */}
              <button 
                id="blinkBtn"
                onClick={toggleBlink}
                className={`w-full py-3 px-4 font-black text-xs uppercase tracking-wider rounded-xl cursor-pointer transition-all duration-200 flex items-center justify-center gap-2 ${
                  blinking 
                    ? 'bg-gradient-to-r from-rose-500 via-red-600 to-rose-700 hover:from-rose-400 hover:to-red-500 text-white shadow-[0_8px_25px_rgba(239,68,68,0.5),inset_0_2px_2px_rgba(255,255,255,0.7)] border border-rose-200 animate-pulse' 
                    : 'bg-gradient-to-r from-cyan-600 via-sky-600 to-blue-700 hover:from-cyan-500 hover:to-blue-600 text-white shadow-[0_8px_25px_rgba(14,165,233,0.4),inset_0_2px_2px_rgba(255,255,255,0.65)] border border-sky-300 hover:scale-[1.02] active:scale-[0.98]'
                }`}
              >
                {blinking ? (
                  <>
                    <Pause className="w-4 h-4 fill-current" />
                    <span>{t.stopBlinkBtn}</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>{t.startBlinkBtn}</span>
                  </>
                )}
              </button>
            </div>

            {/* 3) 102 SPECTRAL BANDS SCRUBBER - VIBRANT SOLAR AMBER/ORANGE CARD */}
            <div className="p-4 rounded-2xl border-2 border-amber-400/60 space-y-3.5 bg-gradient-to-br from-amber-50 via-orange-50/70 to-white shadow-[0_8px_25px_rgba(245,158,11,0.12)] relative overflow-hidden">
              <div className="flex items-center justify-between text-xs font-bold text-amber-950">
                <span className="text-amber-900 font-bold">{t.browseBandsTitle}</span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-black text-amber-900 bg-amber-100 border border-amber-300 shadow-xs">
                  {lang === 'si' ? `තරංගය ${currentBand.band} (102 න්)` : `Band ${currentBand.band} of 102`}
                </span>
              </div>

              <div className="bg-amber-100/80 p-2 rounded-full border border-amber-300 shadow-inner">
                <input 
                  type="range" 
                  id="bandSlider" 
                  min="0" 
                  max="101" 
                  value={bandIndex} 
                  onChange={(e) => jumpToBand(Number(e.target.value))}
                  className="w-full h-2 bg-transparent rounded-lg appearance-none cursor-pointer accent-amber-600"
                  aria-label="SPHEREx 102 spectral bands slider"
                />
              </div>

              <div className="flex justify-between text-[11px] text-amber-900/90 font-mono font-medium">
                <span>0.75 μm ({lang === 'si' ? 'තරංග 1' : 'Band 1'})</span>
                <span className="text-amber-700 font-bold">2.42 μm</span>
                <span>5.00 μm ({lang === 'si' ? 'තරංග 102' : 'Band 102'})</span>
              </div>

              {/* AUTO SCAN ALL 102 BANDS TIMELAPSE BUTTON */}
              <button
                onClick={() => setAutoScanBands(!autoScanBands)}
                className={`w-full py-3 px-4 font-black text-xs uppercase tracking-wider rounded-xl cursor-pointer transition-all duration-200 flex items-center justify-center gap-2 ${
                  autoScanBands
                    ? 'bg-gradient-to-r from-amber-500 via-orange-600 to-red-600 text-white shadow-[0_8px_25px_rgba(249,115,22,0.5),inset_0_2px_2px_rgba(255,255,255,0.7)] border border-amber-200 animate-pulse'
                    : 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-white shadow-[0_8px_25px_rgba(245,158,11,0.45),inset_0_2px_2px_rgba(255,255,255,0.7)] border border-amber-200 hover:scale-[1.02] active:scale-[0.98]'
                }`}
              >
                {autoScanBands ? (
                  <>
                    <Pause className="w-3.5 h-3.5 fill-current" />
                    <span>{t.pauseTimelapseBtn}</span>
                  </>
                ) : (
                  <>
                    <FastForward className="w-3.5 h-3.5 fill-current" />
                    <span>{t.playTimelapseBtn}</span>
                  </>
                )}
              </button>
            </div>

            {/* 4) ACCESSIBILITY / BLIND MODE (AUDIO SONAR) - VIBRANT NEON PURPLE/LIME CARD */}
            <div className="p-4 rounded-2xl border-2 border-purple-400/60 space-y-3.5 bg-gradient-to-br from-purple-50 via-fuchsia-50/70 to-white shadow-[0_8px_25px_rgba(168,85,247,0.12)] relative overflow-hidden">
              <div className="flex items-center justify-between text-xs font-bold text-purple-950">
                <span className="flex items-center gap-2 text-purple-900">
                  <Volume2 className="w-4 h-4 text-purple-600 drop-shadow-sm" />
                  <span className="font-bold">{t.audioSonarTitle}</span>
                </span>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono font-black ${
                  blind 
                    ? 'text-lime-900 bg-lime-100 border border-lime-400 shadow-xs' 
                    : 'text-slate-600 bg-slate-100 border border-slate-300'
                }`}>
                  {blind ? t.sonarEnabled : t.sonarDisabled}
                </span>
              </div>

              <button 
                id="blindBtn"
                onClick={toggleBlind}
                className={`w-full py-3 px-4 font-black text-xs uppercase tracking-wider rounded-xl cursor-pointer transition-all duration-200 flex items-center justify-center gap-2 ${
                  blind 
                    ? 'bg-gradient-to-r from-lime-500 via-emerald-500 to-teal-500 text-slate-950 shadow-[0_8px_25px_rgba(132,204,22,0.4),inset_0_2px_2px_rgba(255,255,255,0.7)] border border-lime-200 hover:scale-[1.02] active:scale-[0.98]' 
                    : 'bg-gradient-to-r from-purple-600 via-violet-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white shadow-[0_8px_25px_rgba(168,85,247,0.4),inset_0_2px_2px_rgba(255,255,255,0.7)] border border-purple-200 hover:scale-[1.02] active:scale-[0.98]'
                }`}
              >
                {blind ? t.activeSonarBtn : t.enableSonarBtn}
              </button>
              
              <p className="text-[11px] text-purple-900/80 leading-tight">
                {t.sonarHelpText}
              </p>
            </div>

            {/* 5) LOGGED DISCOVERIES CATALOG - HIGH CONTRAST CYAN/ROSE CARD */}
            <div className="p-4 rounded-2xl border-2 border-sky-300/80 space-y-3.5 bg-gradient-to-br from-white via-sky-50/70 to-blue-50/60 shadow-[0_8px_25px_rgba(14,165,233,0.1)] relative overflow-hidden">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black text-slate-900 flex items-center gap-2">
                  <Crosshair className="w-4 h-4 text-sky-600 drop-shadow-sm" />
                  <span>{t.myDiscoveriesTitle}</span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-black text-white bg-gradient-to-r from-cyan-500 to-blue-600 border border-cyan-300 shadow-xs">
                    {discoveries.length}
                  </span>
                </h3>
                {discoveries.length > 0 && (
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={exportDiscoveries}
                      title={lang === 'si' ? "නාමාවලිය JSON ලෙස බාගත කරන්න" : "Export Catalog as JSON"}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-black text-white flex items-center gap-1.5 cursor-pointer transition-all bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:to-sky-400 shadow-[0_6px_16px_rgba(6,182,212,0.4),inset_0_1.5px_1.5px_rgba(255,255,255,0.6)] border border-cyan-200 hover:scale-105 active:scale-95"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{t.exportBtn}</span>
                    </button>
                    <button 
                      onClick={clearDiscoveries}
                      title={lang === 'si' ? "සියලු සොයාගැනීම් මකන්න" : "Clear All Discoveries"}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-black text-white flex items-center gap-1.5 cursor-pointer transition-all bg-gradient-to-r from-rose-500 via-red-600 to-rose-700 hover:from-rose-400 hover:to-red-500 shadow-[0_6px_16px_rgba(239,68,68,0.4),inset_0_1.5px_1.5px_rgba(255,255,255,0.6)] border border-rose-200 hover:scale-105 active:scale-95"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{t.clearBtn}</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Discoveries list scroll container */}
              <div 
                id="list" 
                className="bg-sky-50/90 p-2.5 rounded-xl max-h-[145px] overflow-y-auto space-y-2 border border-sky-200 shadow-inner"
              >
                {discoveries.length === 0 ? (
                  <div className="py-4 text-center text-slate-500 text-[11px] leading-relaxed whitespace-pre-line">
                    {t.noDiscoveriesYet}
                  </div>
                ) : (
                  discoveries.map((d, i) => (
                    <div 
                      key={d.id || i}
                      className="bg-white hover:bg-sky-50 border border-sky-200 p-2.5 rounded-xl flex items-center justify-between text-xs transition-all shadow-xs"
                    >
                      <span className="font-mono text-slate-700 text-[11px]">
                        <strong className="text-sky-700 font-black">{i + 1}.</strong> RA: {d.ra} DEC: {d.dec} <span className="text-sky-600 text-[10px] ml-1 font-mono">[{d.time}]</span>
                      </span>
                      <button
                        onClick={(e) => deleteDiscovery(d.id, e)}
                        className="p-1.5 rounded-lg text-rose-500 hover:text-white hover:bg-rose-600 transition-all cursor-pointer"
                        title={lang === 'si' ? "සටහන ඉවත් කරන්න" : "Delete entry"}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* 6) NASA DATA & STATUS FOOTNOTE - DISTINCT STATUS BADGES */}
          <div className="pt-4 border-t border-sky-200/80 space-y-2">
            <div className="flex items-center justify-between p-2 rounded-xl bg-white border border-sky-200 text-[11px] font-mono shadow-xs">
              <span className="text-slate-600">{t.nasaImageBadge}</span>
              <span className="text-slate-900 font-bold truncate max-w-[170px]">{imageTitle}</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-50 border border-emerald-300 text-[11px] font-mono shadow-xs">
              <span className="text-emerald-800 font-semibold">{lang === 'si' ? 'SPHEREx තරංග 102:' : 'SPHEREx 102 Spectral Bands:'}</span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black text-emerald-800 bg-emerald-100 border border-emerald-300 shadow-xs">{t.bandsActiveBadge}</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-sky-50 border border-sky-300 text-[11px] font-mono shadow-xs">
              <span className="text-sky-800 font-semibold">{lang === 'si' ? 'NASA API යතුර:' : 'NASA API Key:'}</span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black text-sky-800 bg-sky-100 border border-sky-300 shadow-xs">{t.apiKeyBadge}</span>
            </div>
          </div>
        </aside>
      </main>
        </div>
      )}

      {/* EXPLORE 11 TOOLS IN COSMO CLASS ECOSYSTEM PRODUCT SUITE */}
      <CosmoClassSuite lang={lang} />

      {/* OFFICIAL COSMO CLASS FOOTER IN WHITE & LIGHT BLUE */}
      <footer className="uiobj-panel max-w-7xl mx-auto p-6 sm:p-10 my-8 space-y-8 relative overflow-hidden bg-gradient-to-b from-white/95 via-sky-50/70 to-blue-50/60 border border-sky-200 shadow-[0_20px_50px_rgba(14,165,233,0.1)]">
        {/* Subtle background glow */}
        <div className="absolute -top-10 -right-10 w-60 h-60 rounded-full object-sphere-orange pointer-events-none -z-10 opacity-30" />
        <div className="absolute -bottom-10 -left-10 w-60 h-60 rounded-full object-sphere-purple pointer-events-none -z-10 opacity-30" />

        <div className="space-y-8 relative z-10">

          {/* OFFICIAL COSMO CLASS EMBLEM & BANNER */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-center sm:text-left border-b border-sky-200/80 pb-8">
            <img 
              src="/cosmo-logo.jpg" 
              alt="COSMO CLASS Official Logo" 
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-full border-4 border-sky-400 shadow-[0_10px_25px_rgba(14,165,233,0.3)] object-cover flex-shrink-0"
              referrerPolicy="no-referrer"
            />
            <div>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
                <span className="text-2xl sm:text-3xl font-black text-slate-900 tracking-wide">
                  COSMO <span className="text-sky-600">CLASS</span>
                </span>
                <span className="bg-sky-100 text-sky-800 border border-sky-300 text-xs font-mono font-bold px-3 py-1 rounded-full shadow-xs">
                  .SPACE
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 mt-1.5 max-w-2xl font-normal leading-relaxed">
                {t.footerTagline}
              </p>
            </div>
          </div>
          
          {/* ACTION BUTTONS ROW */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <a
              href="https://adgeniechatbotsrilanka.lovable.app/"
              target="_blank"
              rel="noopener noreferrer"
              className="uiobj-btn-primary px-6 py-3 text-white font-black text-xs sm:text-sm flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 fill-white" />
              <span>{t.footerExploreAdGenie}</span>
            </a>

            <a
              href="https://github.com/wm208727-png/COSMO-CLASS"
              target="_blank"
              rel="noopener noreferrer"
              className="uiobj-btn-secondary px-6 py-3 text-sky-900 font-black text-xs sm:text-sm flex items-center gap-2"
            >
              <ExternalLink className="w-4 h-4 text-sky-600" />
              <span>{t.footerViewSource}</span>
            </a>
          </div>

          {/* DEVELOPER PROFILE & MANIFESTO */}
          <div className="border-t border-sky-200/80 pt-6 text-center space-y-3">
            <p className="text-base sm:text-lg font-black text-slate-900 tracking-wide">
              {t.footerManifesto1}
            </p>
            <p className="text-sm text-sky-700 font-bold">
              {lang === 'si' ? "නිර්මාණය: ඒ. දිසස් දින්සිත් (වයස 12), බණ්ඩාරගම, ශ්‍රී ලංකාව" : "Created by A. Disas Dinsitha (Age 12), Bandaragama, Sri Lanka"}
            </p>
            <p className="text-xs sm:text-sm text-slate-600 max-w-xl mx-auto italic">
              {t.footerManifestoQuote}
            </p>
            <p className="text-xs text-slate-500">
              {t.footerNasaNote}
            </p>

            <div className="inline-flex flex-col sm:flex-row items-center gap-4 mt-4 p-5 uiobj-card text-xs sm:text-sm text-left text-slate-800 bg-white/95 border border-sky-200 shadow-sm">
              <img 
                src="/cosmo-logo.jpg" 
                alt="COSMO CLASS Space Logo" 
                className="w-14 h-14 rounded-full border-2 border-sky-400 object-cover flex-shrink-0 shadow-sm"
                referrerPolicy="no-referrer"
              />
              <div className="space-y-1">
                <p><strong className="text-sky-700">{t.footerDevLabel}</strong> A. DISAS DINSITHA</p>
                <p><strong className="text-sky-700">{t.footerAgeLabel}</strong> {t.footerAgeVal}</p>
                <p><strong className="text-sky-700">EMAIL:</strong> <a href="mailto:wm208727@gmail.com" className="text-sky-900 underline hover:text-sky-600">wm208727@gmail.com</a></p>
                <p><strong className="text-sky-700">{t.footerLocationLabel}</strong> {t.footerLocationVal}</p>
              </div>
            </div>

            <div className="pt-3 text-[11px] text-slate-500 font-mono">
              {t.footerCopyright}
            </div>
          </div>

        </div>
      </footer>
    </div>
  );
}
