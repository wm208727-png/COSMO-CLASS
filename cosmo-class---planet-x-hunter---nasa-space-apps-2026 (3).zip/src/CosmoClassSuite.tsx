import React, { useState } from 'react';
import { 
  Globe, 
  Compass, 
  Headphones, 
  BookOpen, 
  Bot, 
  Code, 
  Brain, 
  Sparkles, 
  FileText, 
  Award, 
  ExternalLink,
  ArrowUpRight,
  Trophy,
  Rocket
} from 'lucide-react';
import { Language } from './translations';

export interface SuiteTool {
  id: number;
  name: string;
  nameSi?: string;
  category: '3D & Science' | 'AI & Audio' | 'Code & Tools' | 'Education & Quizzes' | 'Games';
  badge: string;
  badgeSi?: string;
  sphereClass: string;
  icon: React.ComponentType<{ className?: string }>;
  iconColor: string;
  url: string;
  description: string;
  descSi?: string;
  subLinks?: { name: string; url: string }[];
}

export const COSMO_TOOLS: SuiteTool[] = [
  {
    id: 1,
    name: "🪐 Hela Scope – Explore 3D Planets",
    nameSi: "🪐 හෙළ ස්කෝප් (Hela Scope) – 3D සෞරග්‍රහ මණ්ඩලය",
    category: "3D & Science",
    badge: "3D PLANETS",
    badgeSi: "3D ග්‍රහලෝක",
    sphereClass: "object-sphere-cyan",
    icon: Globe,
    iconColor: "text-cyan-100",
    url: "https://helascopesuper.netlify.app/",
    description: "Hela Scope allows users to explore planets in our Solar System in an immersive 3D environment while learning new facts about space. It combines education and technology to provide a more engaging and interactive way to discover the planets.",
    descSi: "අපගේ සෞරග්‍රහ මණ්ඩලයේ ග්‍රහලෝක ත්‍රිමාණ (3D) අත්දැකීමකින් යුතුව අධ්‍යයනය කිරීමට සහ අභ්‍යවකාශ කරුණු ඉගෙන ගැනීමට නිර්මාණය කර ඇත. සිසුන්ට අන්තර්ක්‍රියාකාරී ලෙස ගවේෂණය කළ හැකිය."
  },
  {
    id: 2,
    name: "☀️ Solar System Eyes – Explore the Solar System",
    nameSi: "☀️ සෝලා සිස්ටම් අයිස් (Solar System Eyes Sri Lanka)",
    category: "3D & Science",
    badge: "SOLAR 3D",
    badgeSi: "සූර්ය පද්ධතිය",
    sphereClass: "object-sphere-orange",
    icon: Compass,
    iconColor: "text-amber-100",
    url: "https://solar-system-eyes-srilanka-bydisas.netlify.app/",
    description: "Solar System Eyes Sri Lanka allows users to explore information about the Solar System and its planets. It provides an enjoyable way for students and space enthusiasts to learn about astronomy and discover more about our cosmic neighborhood.",
    descSi: "සෞරග්‍රහ මණ්ඩලය, ග්‍රහලෝක සහ අපගේ විශ්වීය වටපිටාව පිළිබඳ තොරතුරු සිසුන්ට සහ තාරකා විද්‍යා ලෝලීන්ට රසවත්ව ගවේෂණය කළ හැකිය."
  },
  {
    id: 3,
    name: "👓 EDU DINSI – Blind Mode",
    nameSi: "👓 EDU DINSI – ශ්‍රව්‍ය ප්‍රවේශ්‍යතා මාදිලිය (Blind Mode)",
    category: "AI & Audio",
    badge: "ACCESSIBILITY",
    badgeSi: "හඬ පහසුකම",
    sphereClass: "object-sphere-purple",
    icon: Headphones,
    iconColor: "text-purple-100",
    url: "https://edu-dinsi-893989629906.asia-southeast1.run.app/",
    description: "EDU DINSI Blind Mode allows users to listen to news and information from the website. It is designed for users who may find it difficult to view the screen or for anyone who prefers to listen to educational content and news.",
    descSi: "දෘශ්‍යාබාධිත පුද්ගලයින්ට හෝ තිරය නොබලා හඬ මඟින් අධ්‍යාපනික ලිපි සහ පුවත් වලට සවන්දීමට නිර්මාණය කර ඇති විශේෂ ශ්‍රව්‍ය පහසුකමකි."
  },
  {
    id: 4,
    name: "🌐 EDU DINSI – Educational & News Platform",
    nameSi: "🌐 EDU DINSI – අධ්‍යාපනික සහ විද්‍යා පුවත් වේදිකාව",
    category: "Education & Quizzes",
    badge: "NEWS & EDU",
    badgeSi: "අධ්‍යාපන සහ පුවත්",
    sphereClass: "object-sphere-cyan",
    icon: BookOpen,
    iconColor: "text-sky-100",
    url: "https://edu-dinsi-893989629906.asia-southeast1.run.app/",
    description: "EDU DINSI is an educational and information platform where users can read educational content, news, and informative articles. It makes it easy for students and knowledge seekers to discover and learn new information.",
    descSi: "නව විද්‍යාත්මක සොයාගැනීම්, අභ්‍යවකාශ පුවත් සහ අධ්‍යාපනික ලිපි පහසුවෙන් කියවිය හැකි ලාංකීය ඩිජිටල් වේදිකාවකි."
  },
  {
    id: 5,
    name: "🪐 EDU DSL – NASA Space Articles & Blogs",
    nameSi: "🪐 EDU DSL – NASA අභ්‍යවකාශ විද්‍යා ලිපි සහ බ්ලොග්",
    category: "Education & Quizzes",
    badge: "NASA BLOGS",
    badgeSi: "නාසා බ්ලොග්",
    sphereClass: "object-sphere-purple",
    icon: FileText,
    iconColor: "text-purple-100",
    url: "https://edu-dsl-by-disas.netlify.app/",
    description: "EDU DSL allows users to read educational articles and blogs about NASA and space science. It brings space education, astronomical discoveries, and cosmic research together in one accessible platform.",
    descSi: "NASA සහ විශ්ව ගවේෂණ පිළිබඳ තොරතුරු, විද්‍යාත්මක ලිපි සහ බ්ලොග් සටහන් කියවීම සඳහා සිසුන්ට නිර්මාණය කළ වේදිකාවකි."
  },
  {
    id: 6,
    name: "💻 CODE DIMEX – HTML, CSS & JavaScript Testing",
    nameSi: "💻 CODE DIMEX – HTML, CSS & JavaScript කේත සංස්කාරකය",
    category: "Code & Tools",
    badge: "WEB IDE",
    badgeSi: "වෙබ් IDE",
    sphereClass: "object-sphere-emerald",
    icon: Code,
    iconColor: "text-emerald-100",
    url: "https://codedimex.netlify.app/",
    description: "CODE DIMEX allows users to write, run, and test HTML, CSS, and JavaScript code and instantly view the results. It is a useful tool for students and beginners who are learning web development and want to experiment with their own code.",
    descSi: "වෙබ් නිර්මාණකරණය හදාරන සිසුන්ට HTML, CSS, JavaScript කේත ලියා එසැණින් ප්‍රතිඵල නැරඹිය හැකි අන්තර්ජාල කේත සංස්කාරකයකි."
  },
  {
    id: 7,
    name: "🧠 Questions & Quiz – Test Your Knowledge",
    nameSi: "🧠 Questions & Quiz – තාරකා විද්‍යා දැනුම මිනුම",
    category: "Education & Quizzes",
    badge: "DUAL QUIZ",
    badgeSi: "ද්විත්ව ප්‍රශ්නාවලි",
    sphereClass: "object-sphere-magenta",
    icon: Brain,
    iconColor: "text-pink-100",
    url: "https://quiz-master-srilanka-made-by-disas.netlify.app/",
    description: "This section allows users to answer a variety of questions and test their knowledge. It provides an interactive and enjoyable way to review what they have learned while improving their understanding through quizzes.",
    descSi: "අභ්‍යවකාශය සහ සාමාන්‍ය විද්‍යාව පිළිබඳ ප්‍රශ්නාවලි වලට පිළිතුරු සපයමින් දැනුම වැඩිදියුණු කරගත හැකි අන්තර්ක්‍රියාකාරී ප්‍රශ්නාවලියකි.",
    subLinks: [
      { name: "1) Quiz Master Sri Lanka", url: "https://quiz-master-srilanka-made-by-disas.netlify.app/" },
      { name: "2) Science Quiz Explorer", url: "https://zesty-crisp.netlify.app/" }
    ]
  },
  {
    id: 8,
    name: "🏆 Quiz Master Sri Lanka",
    nameSi: "🏆 Quiz Master Sri Lanka – ජාතික අභ්‍යවකාශ ප්‍රශ්නාවලිය",
    category: "Education & Quizzes",
    badge: "NATIONAL QUIZ",
    badgeSi: "ජාතික ප්‍රශ්නාවලිය",
    sphereClass: "object-sphere-orange",
    icon: Trophy,
    iconColor: "text-amber-100",
    url: "https://quiz-master-srilanka-made-by-disas.netlify.app/",
    description: "National-level astronomy and space science quiz application designed to challenge students and space enthusiasts with rich multiple-choice questions, timers, and scoring.",
    descSi: "ශ්‍රී ලාංකීය සිසුන් සඳහා විශේෂිත කාල ගණක සහ ලකුණු ලබාදීමේ ක්‍රමවේද සහිත ජාතික මට්ටමේ අභ්‍යවකාශ ප්‍රශ්නාවලි යෙදුමකි."
  },
  {
    id: 9,
    name: "📝 MoodREV – Text Document Maker",
    nameSi: "📝 MoodREV – ඩිජිටල් ලිපි ලේඛන සංස්කාරකය",
    category: "Code & Tools",
    badge: "DOC MAKER",
    badgeSi: "ලේඛන සැකසුම්",
    sphereClass: "object-sphere-magenta",
    icon: FileText,
    iconColor: "text-rose-100",
    url: "https://moodrevminiword.blogspot.com/2026/08/mood-rev-mini-word-editor.html",
    description: "MoodREV is a simple text document editor designed for creating and editing documents. Users can write, edit, and organize their text to create simple digital documents.",
    descSi: "ලිපි ලේඛන සැකසීම, සටහන් ලිවීම සහ පෙළ ගොනු සංස්කරණය සඳහා නිර්මාණය කරන ලද සැහැල්ලු වෙබ් මෙවලමකි."
  },
  {
    id: 10,
    name: "🚀 rockert game",
    nameSi: "🚀 රොකට් ගේම් – අභ්‍යවකාශ ගවේෂණ වීඩියෝ ක්‍රීඩාව",
    category: "Games",
    badge: "ROCKET GAME",
    badgeSi: "රොකට් ක්‍රීඩාව",
    sphereClass: "object-sphere-orange",
    icon: Rocket,
    iconColor: "text-orange-100",
    url: "https://rockertvsasteroidsgame.netlify.app/",
    description: "Action-packed asteroid avoidance rocket game testing quick reflexes and navigation in deep space.",
    descSi: "උල්කාපාත මඟහරිමින් අභ්‍යවකාශ යානය පාලනය කරමින් විනෝද විය හැකි අභ්‍යවකාශ වීඩියෝ ක්‍රීඩාවකි."
  },
  {
    id: 11,
    name: "👨‍💻 Developer Portfolio – Certificates & Projects",
    nameSi: "👨‍💻 නිර්මාණකරුගේ තොරතුරු සහ සහතිකපත් (Portfolio)",
    category: "Education & Quizzes",
    badge: "PORTFOLIO",
    badgeSi: "තොරතුරු හා සහතික",
    sphereClass: "object-sphere-purple",
    icon: Award,
    iconColor: "text-purple-100",
    url: "https://sites.google.com/view/a-disas-dinsithas-portfolio/home",
    description: "The Developer Portfolio showcases certificates, projects, websites, and other technology-related work created by the developer. It provides an opportunity to explore the developer’s technical journey, skills, achievements, and creative projects.",
    descSi: "වයස 12 ක් වන ඒ. දිසස් දින්සිත් සිසුවාගේ ව්‍යාපෘති, නිර්මාණ, සහතිකපත් සහ නව නිපැයුම් පිළිබඳ විස්තර."
  }
];

export function CosmoClassSuite({ lang = 'si' }: { lang?: Language }) {
  const [filter, setFilter] = useState<'all' | '3D & Science' | 'AI & Audio' | 'Code & Tools' | 'Education & Quizzes' | 'Games'>('all');

  const filteredTools = filter === 'all' 
    ? COSMO_TOOLS 
    : COSMO_TOOLS.filter(t => t.category === filter);

  return (
    <section className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10 my-8 uiobj-panel overflow-hidden space-y-6">
      
      {/* 3D BACKGROUND ACCENT SPHERES FOR SPATIAL DEPTH */}
      <div className="absolute -top-16 -right-16 w-56 h-56 rounded-full object-sphere-orange pointer-events-none -z-10 opacity-60" />
      <div className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full object-sphere-purple pointer-events-none -z-10 opacity-50" />
      <div className="absolute top-1/2 left-1/3 w-32 h-32 rounded-full object-sphere-cyan pointer-events-none -z-10 opacity-30" />

      {/* SECTION HEADER & SUITE BRANDING */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-sky-200/80 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-3 h-3 rounded-full object-sphere-orange animate-pulse" />
            <span className="text-xs font-black uppercase tracking-widest text-orange-600 font-mono">
              {lang === 'si' ? "COSMO CLASS අධ්‍යාපනික මෙවලම් පද්ධතිය" : "COSMO CLASS PRODUCT ECOSYSTEM"}
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-wide">
            {lang === 'si' 
              ? "COSMO CLASS නිල මෙවලම් 11 ගවේෂණය කරන්න" 
              : "Explore 11 Tools in COSMO CLASS Ecosystem"}
          </h2>

          <p className="text-xs sm:text-sm text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
            {lang === 'si'
              ? "ශ්‍රී ලංකාවේ බණ්ඩාරගම වයස 12 ක් වන ඒ. දිසස් දින්සිත් සිසුවා විසින් සිසුන්, ගුරුවරුන් සහ අභ්‍යවකාශ ලෝලීන් සඳහා නිර්මාණය කරන ලද ත්‍රිමාණ සෞරග්‍රහ මණ්ඩල, නාසා අභ්‍යවකාශ බ්ලොග්, හඬ ප්‍රවේශ්‍යතා, වෙබ් කේතකරණ සහ තර්කන ක්‍රීඩා ඇතුළත් ඩිජිටල් මෙවලම් 11 ක එකතුවකි."
              : "A comprehensive suite of 11 interactive digital platforms created by 12-year-old developer A. Disas Dinsitha (Bandaragama, Sri Lanka), spanning 3D planetary exploration, NASA AI learning, voice accessibility, code sandboxes, and logic games."}
          </p>
        </div>

        {/* CATEGORY FILTER PILLS */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {(['all', '3D & Science', 'AI & Audio', 'Code & Tools', 'Education & Quizzes', 'Games'] as const).map((cat) => {
            const catLabel = lang === 'si' ? {
              'all': `සියල්ල (${COSMO_TOOLS.length})`,
              '3D & Science': '3D සහ විද්‍යාව',
              'AI & Audio': 'AI සහ හඬ',
              'Code & Tools': 'කේත සහ මෙවලම්',
              'Education & Quizzes': 'අධ්‍යාපන සහ ප්‍රශ්නාවලි',
              'Games': 'ක්‍රීඩා'
            }[cat] : (cat === 'all' ? `All (${COSMO_TOOLS.length})` : cat);

            return (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-3.5 py-1.5 text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  filter === cat
                    ? 'uiobj-btn-primary'
                    : 'uiobj-btn-secondary text-sky-800 hover:text-sky-950'
                }`}
              >
                {catLabel}
              </button>
            );
          })}
        </div>
      </div>

      {/* 3-COLUMN RESPONSIVE GRID OF UI + OBJECT PRODUCT CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredTools.map((tool) => {
          const IconComp = tool.icon;
          const toolName = lang === 'si' && tool.nameSi ? tool.nameSi : tool.name;
          const toolDesc = lang === 'si' && tool.descSi ? tool.descSi : tool.description;
          const toolBadge = lang === 'si' && tool.badgeSi ? tool.badgeSi : tool.badge;

          return (
            <div
              key={tool.id}
              className="group relative uiobj-card p-5 flex flex-col justify-between"
            >
              {/* TOP ROW: 3D SPHERE OBJECT, BADGE, AND LAUNCH ARROW */}
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${tool.sphereClass} shadow-lg transition-transform duration-300 group-hover:scale-110`}>
                  <IconComp className={`w-6 h-6 ${tool.iconColor} drop-shadow-md`} />
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-extrabold px-2.5 py-1 rounded-full font-mono bg-sky-100/90 text-sky-800 border border-sky-300">
                    {toolBadge}
                  </span>
                  <a
                    href={tool.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    title={`Open ${toolName} in a new tab`}
                    className="p-1.5 text-slate-500 group-hover:text-sky-600 transition-colors"
                  >
                    <ArrowUpRight className="w-4 h-4" />
                  </a>
                </div>
              </div>

              {/* CARD BODY: TITLE & DESCRIPTION */}
              <div className="space-y-2 flex-1">
                <h3 className="text-base font-bold text-slate-900 group-hover:text-orange-600 transition-colors flex items-center gap-1.5">
                  <span>{toolName}</span>
                </h3>

                {toolDesc ? (
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {toolDesc}
                  </p>
                ) : null}

                {/* OPTIONAL SUB-LINKS (e.g. for Questions & Quiz) */}
                {tool.subLinks && (
                  <div className="pt-2 border-t border-sky-100 flex flex-col gap-1.5">
                    <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">
                      {lang === 'si' ? "ප්‍රශ්නාවලි සබැඳි:" : "Direct Quiz Launchers:"}
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {tool.subLinks.map((sub) => (
                        <a
                          key={sub.name}
                          href={sub.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1.5 rounded-xl uiobj-btn-secondary text-sky-900 hover:text-sky-950 text-[11px] font-semibold transition-all flex items-center justify-between"
                        >
                          <span className="truncate">{sub.name}</span>
                          <ExternalLink className="w-3 h-3 flex-shrink-0 ml-1" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* CARD FOOTER: PRIMARY LAUNCH ACTION */}
              <div className="pt-4 mt-4 border-t border-sky-100 flex items-center justify-between">
                <span className="text-[11px] text-sky-700 font-mono font-medium">
                  {tool.category}
                </span>

                <a
                  href={tool.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="uiobj-btn-primary px-3.5 py-1.5 text-xs font-bold inline-flex items-center gap-1.5"
                >
                  <span>{lang === 'si' ? "මෙවලම අරඹන්න" : "Launch Tool"}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          );
        })}
      </div>

      {/* QUICK HIGHLIGHT BANNER: AD GENIE AI & GITHUB */}
      <div className="uiobj-card p-5 flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
        <div className="flex items-center gap-3 text-center sm:text-left">
          <div className="w-11 h-11 rounded-2xl object-sphere-orange flex items-center justify-center font-bold text-lg text-white shadow-lg flex-shrink-0">
            ✨
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900">
              {lang === 'si' 
                ? "Ad Genie AI සහ GitHub විවෘත මූලාශ්‍ර කේත ගබඩාව" 
                : "Ad Genie AI Chatbot & Open Source Repository"}
            </h4>
            <p className="text-xs text-slate-600 mt-0.5">
              {lang === 'si'
                ? "COSMO CLASS පද්ධතිය පිටුපස ඇති උසස් කෘතිම බුද්ධි සේවාවන් සහ GitHub විවෘත කේත පරිශීලනය කරන්න."
                : "Explore the advanced commercial chatbot and open-source GitHub code backing the COSMO CLASS suite."}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-shrink-0">
          <a
            href="https://adgeniechatbotsrilanka.lovable.app/"
            target="_blank"
            rel="noopener noreferrer"
            className="uiobj-btn-primary px-4 py-2 text-xs font-bold flex items-center gap-1.5"
          >
            <span>{lang === 'si' ? "Ad Genie AI අරඹන්න" : "Launch Ad Genie AI"}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <a
            href="https://github.com/wm208727-png/COSMO-CLASS"
            target="_blank"
            rel="noopener noreferrer"
            className="uiobj-btn-secondary px-4 py-2 text-xs font-bold flex items-center gap-1.5"
          >
            <span>{lang === 'si' ? "GitHub කේතය" : "GitHub Code"}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

    </section>
  );
}
