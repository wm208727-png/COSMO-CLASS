import React, { useState } from 'react';
import { 
  Database, 
  ExternalLink, 
  CheckCircle2, 
  Clock, 
  BookOpen, 
  ShieldCheck, 
  Download,
  FileText,
  Radio,
  Layers,
  Sparkles
} from 'lucide-react';
import { Language } from './translations';

interface DatasetItem {
  id: string;
  name: string;
  organization: string;
  sourceUrl: string;
  observationsCount: string;
  lastUpdated: string;
  status: 'Open Dataset' | 'Live API' | 'Official Archive';
  coverage: string;
  spectralBands: string;
  description: string;
  telemetry: string;
}

const DATASETS: DatasetItem[] = [
  {
    id: 'spherex',
    name: "NASA SPHEREx All-Sky Near-Infrared Spectral Survey",
    organization: "NASA / Caltech / Jet Propulsion Laboratory (JPL) / IPAC",
    sourceUrl: "https://spherex.caltech.edu/",
    observationsCount: "1,248 Sky Tiles",
    lastUpdated: "March 2026",
    status: "Open Dataset",
    coverage: "Full All-Sky (4π steradians, 100% celestial sphere)",
    spectralBands: "102 Near-Infrared Bands (0.75 μm - 5.00 μm)",
    description: "NASA's Spectro-Photometer for the History of the Universe, Epoch of Reionization and Ices Explorer maps the entire sky every six months across 102 discrete infrared wavelengths, gathering spectral data on hundreds of millions of celestial objects.",
    telemetry: "6 Linear Variable Filter (LVF) detector arrays with R=40 to R=130 resolution."
  },
  {
    id: 'irsa',
    name: "NASA / IPAC Infrared Science Archive (IRSA)",
    organization: "NASA / Caltech Infrared Processing & Analysis Center",
    sourceUrl: "https://irsa.ipac.caltech.edu/Missions/spherex.html",
    observationsCount: "Multi-Terabyte Open Archive",
    lastUpdated: "Current Epoch 2026",
    status: "Official Archive",
    coverage: "All-Sky Co-added Photometric Calibrations",
    spectralBands: "Complete 0.75 - 5.0 μm Data Cubes",
    description: "The primary NASA public repository hosting SPHEREx calibrated FITS images, all-sky spectral catalogs, and multi-epoch astrometric cross-correlations.",
    telemetry: "Compliant with Virtual Observatory (VO) standards and IVOA protocols."
  },
  {
    id: 'apod',
    name: "NASA APOD Real-Time Planetary API",
    organization: "NASA Goddard Space Flight Center (GSFC)",
    sourceUrl: "https://api.nasa.gov/planetary/apod",
    observationsCount: "Daily Live Imagery Stream",
    lastUpdated: "Live Synchronized Daily",
    status: "Live API",
    coverage: "Space science observations and mission imagery",
    spectralBands: "Optical / Infrared Composite",
    description: "Live planetary and astronomical imaging feed provided via NASA's Open Data portal (api.nasa.gov) with direct authenticated integration.",
    telemetry: "Connected via NASA API Key: 5LjjC66pBkXh2LmFdpxIRRSqhFSXFXyYXM4fft2V"
  },
  {
    id: 'horizons',
    name: "NASA JPL Horizons On-Line Ephemeris System",
    organization: "NASA Jet Propulsion Laboratory / Solar System Dynamics Group",
    sourceUrl: "https://ssd.jpl.nasa.gov/horizons/",
    observationsCount: "1.2+ Million Solar System Objects",
    lastUpdated: "Ephemeris DE441 / 2026",
    status: "Open Dataset",
    coverage: "Planetary, TNO, Centaur & Kuiper Belt orbits",
    spectralBands: "Astrometric State Vectors & Keplerian Elements",
    description: "Provides high-precision orbital elements, proper motions, and parallax baselines for outer solar system bodies (Neptune, Pluto, Sedna, and Kuiper Belt Objects) to calibrate Planet X trajectories.",
    telemetry: "Barycentric Dynamical Time (TDB) frame with relativistic n-body integration."
  }
];

export function EvidenceSources({ lang = 'si' }: { lang?: Language }) {
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>('spherex');
  const [showMethodologyModal, setShowMethodologyModal] = useState<boolean>(false);

  const activeDataset = DATASETS.find(d => d.id === selectedDatasetId) || DATASETS[0];

  const exportBibtex = () => {
    const bibtex = `@misc{nasa_spherex_2026,
  author = {NASA and Caltech and Jet Propulsion Laboratory},
  title = {SPHEREx: Spectro-Photometer for the History of the Universe, Epoch of Reionization and Ices Explorer},
  year = {2026},
  publisher = {NASA / IPAC Infrared Science Archive},
  howpublished = {\\url{https://spherex.caltech.edu/}},
  note = {102 Near-Infrared Spectral Bands Survey (0.75 - 5.00 um)}
}`;
    const blob = new Blob([bibtex], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'SPHEREx_NASA_Citation.bib';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="relative w-full max-w-7xl mx-auto space-y-6 overflow-hidden py-3">
      
      {/* 3D GLOWING CELESTIAL SPHERES (UI + OBJECT) */}
      <div className="absolute -top-16 -right-16 w-88 h-88 rounded-full object-sphere-orange pointer-events-none -z-10 opacity-60 animate-pulse duration-1000" />
      <div className="absolute top-1/3 -left-20 w-80 h-80 rounded-full object-sphere-purple pointer-events-none -z-10 opacity-55" />
      <div className="absolute -bottom-24 right-1/4 w-88 h-88 rounded-full object-sphere-cyan pointer-events-none -z-10 opacity-50" />
      <div className="absolute bottom-12 left-10 w-36 h-36 rounded-full object-sphere-magenta pointer-events-none -z-10 opacity-45" />

      {/* HEADER SECTION - UI + OBJECT TRANSLUCENT GLASS PANEL */}
      <div className="uiobj-panel p-5 sm:p-7 flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl object-sphere-orange flex items-center justify-center font-bold text-white shadow-xl flex-shrink-0">
            <BookOpen className="w-7 h-7 text-white drop-shadow" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-wide">
                {lang === 'si'
                  ? "විද්‍යාත්මක මූලාශ්‍ර සහ නාසා විවෘත දත්ත ගබඩාව"
                  : "Data & Sources: Official NASA Mission Evidence"}
              </h1>
              <span className="text-[11px] font-mono px-3 py-1 rounded-full bg-orange-100 text-orange-900 border border-orange-300 font-bold shadow-sm">
                {lang === 'si' ? "සත්‍යාපිත දත්ත" : "Verified Datasets"}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed font-medium">
              {lang === 'si'
                ? "සත්‍ය නාසා මෙහෙයුම් දත්ත • විවෘත විද්‍යාත්මක ප්‍රමිතීන් • ප්‍රතිනිෂ්පාදනය කළ හැකි තාරකා විද්‍යාත්මක පර්යේෂණ ක්‍රමවේදය"
                : "Authentic NASA mission datasets • Open science standards • Reproducible astronomical methodology"}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 flex-shrink-0">
          <button
            onClick={() => setShowMethodologyModal(true)}
            className="uiobj-btn-primary px-4 py-2 text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md"
          >
            <BookOpen className="w-4 h-4" />
            <span>[ Read Methodology ]</span>
          </button>

          <button
            onClick={exportBibtex}
            className="uiobj-btn-secondary px-4 py-2 text-xs font-bold text-slate-700 hover:text-slate-950 flex items-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export Citation (.bib)</span>
          </button>
        </div>
      </div>

      {/* DASHBOARD CARDS: DATASET SUMMARY IN UI + OBJECT METRICS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 relative z-10">
        
        {/* Metric 1: Dataset */}
        <div className="p-4 sm:p-5 rounded-2xl uiobj-card flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-semibold">Primary Dataset</span>
            <span className="w-2.5 h-2.5 rounded-full object-sphere-orange" />
          </div>
          <div className="font-extrabold text-base text-slate-900 mt-2">
            NASA SPHEREx Survey
          </div>
          <span className="text-xs text-orange-600 mt-1.5 font-mono font-bold">
            102 Near-IR Spectral Bands
          </span>
        </div>

        {/* Metric 2: Source */}
        <div className="p-4 sm:p-5 rounded-2xl uiobj-card flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-semibold">Source Status</span>
            <span className="w-2.5 h-2.5 rounded-full object-sphere-emerald" />
          </div>
          <div className="font-extrabold text-base text-emerald-700 mt-2 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>[ Open Dataset ]</span>
          </div>
          <a
            href="https://spherex.caltech.edu/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-slate-600 hover:text-sky-700 flex items-center gap-1 mt-1.5 underline font-medium"
          >
            <span>Caltech / IPAC Portal</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Metric 3: Observations */}
        <div className="p-4 sm:p-5 rounded-2xl uiobj-card flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-semibold">Observations Ingested</span>
            <span className="w-2.5 h-2.5 rounded-full object-sphere-cyan" />
          </div>
          <div className="font-mono font-black text-2xl text-slate-900 mt-2">
            1,248
          </div>
          <span className="text-xs text-slate-600 mt-0.5 font-medium">
            Full-Sky Spectral Tiles
          </span>
        </div>

        {/* Metric 4: Last Updated */}
        <div className="p-4 sm:p-5 rounded-2xl uiobj-card flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-semibold">Last Mission Update</span>
            <span className="w-2.5 h-2.5 rounded-full object-sphere-purple" />
          </div>
          <div className="font-mono font-bold text-sm text-sky-800 mt-2 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-sky-600" />
            <span>March 2026 Epoch</span>
          </div>
          <span className="text-xs text-slate-600 mt-0.5 font-medium">
            Survey 1 & 2 Dual Baseline
          </span>
        </div>

      </div>

      {/* DETAILED DATASET CATALOG & TELEMETRY */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 relative z-10">
        
        {/* LEFT PANEL: DATASET SELECTOR LIST (FLEX 5 COLS) */}
        <div className="lg:col-span-5 uiobj-panel p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-sky-200/80 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full object-sphere-cyan flex items-center justify-center text-xs">
                <Database className="w-3 h-3 text-white" />
              </div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                NASA Data Catalogs ({DATASETS.length})
              </h2>
            </div>
            <span className="text-[10px] font-mono text-slate-500 font-semibold">Official Repositories</span>
          </div>

          <div className="space-y-3">
            {DATASETS.map((ds) => {
              const isSelected = selectedDatasetId === ds.id;

              return (
                <button
                  key={ds.id}
                  onClick={() => setSelectedDatasetId(ds.id)}
                  className={`w-full p-4 rounded-2xl text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'uiobj-card bg-orange-50 border-orange-400 shadow-[0_4px_16px_rgba(249,115,22,0.25)] scale-[1.02]'
                      : 'uiobj-card hover:border-sky-400'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-extrabold text-xs sm:text-sm text-slate-900">{ds.name}</span>
                    <span 
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full font-mono flex-shrink-0 ${
                        ds.status === 'Open Dataset'
                          ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                          : ds.status === 'Live API'
                            ? 'bg-sky-100 text-sky-900 border border-sky-300'
                            : 'bg-purple-100 text-purple-900 border border-purple-300'
                      }`}
                    >
                      {ds.status}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-600 mt-1 truncate font-medium">
                    {ds.organization}
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono mt-2.5 pt-2 border-t border-sky-200/80 font-semibold">
                    <span>Observations: {ds.observationsCount}</span>
                    <span className="text-orange-600 font-bold">Updated: {ds.lastUpdated}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT PANEL: SELECTED DATASET PROFILE (FLEX 7 COLS) */}
        <div className="lg:col-span-7 uiobj-panel p-5 sm:p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            
            <div className="border-b border-sky-200/80 pb-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-orange-600 font-bold">
                  {activeDataset.organization}
                </span>
                <h3 className="text-base sm:text-lg font-black text-slate-900 mt-1">
                  {activeDataset.name}
                </h3>
              </div>

              <a
                href={activeDataset.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="uiobj-btn-primary px-3.5 py-1.5 text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto"
              >
                <span>[ Open Dataset ]</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium">
              {activeDataset.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 rounded-xl uiobj-inset">
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Coverage:</span>
                <strong className="text-slate-900 text-xs">{activeDataset.coverage}</strong>
              </div>

              <div className="p-3.5 rounded-xl uiobj-inset">
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Spectral Resolution:</span>
                <strong className="text-sky-900 font-mono text-xs">{activeDataset.spectralBands}</strong>
              </div>

              <div className="p-3.5 rounded-xl uiobj-inset">
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Ingested Volume:</span>
                <strong className="text-emerald-800 font-mono text-xs">{activeDataset.observationsCount}</strong>
              </div>

              <div className="p-3.5 rounded-xl uiobj-inset">
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Archive Cadence:</span>
                <strong className="text-purple-900 font-mono text-xs">{activeDataset.lastUpdated}</strong>
              </div>
            </div>

            <div className="p-4 uiobj-inset rounded-xl text-xs space-y-1.5">
              <span className="font-bold text-slate-900 block">
                Instrument Telemetry & Hardware Specification:
              </span>
              <p className="text-slate-700 font-mono text-xs leading-relaxed font-medium">
                {activeDataset.telemetry}
              </p>
            </div>

          </div>

          <div className="pt-3.5 border-t border-sky-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-500">
            <span className="flex items-center gap-2 text-emerald-700 font-bold">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>NASA Open Science Verification: Approved</span>
            </span>
            <button
              onClick={() => setShowMethodologyModal(true)}
              className="text-orange-600 hover:text-orange-800 font-bold cursor-pointer underline text-left sm:text-right"
            >
              Read Full Methodology →
            </button>
          </div>
        </div>

      </div>

      {/* METHODOLOGY MODAL OVERLAY IN UI + OBJECT GLASS */}
      {showMethodologyModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="uiobj-panel max-w-3xl w-full max-h-[85vh] overflow-y-auto p-6 sm:p-7 shadow-2xl space-y-5 text-slate-800 relative bg-white/95 border-sky-300">
            
            <div className="flex items-center justify-between border-b border-sky-200/80 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl object-sphere-orange text-white flex items-center justify-center text-sm font-bold shadow-md">
                  🔬
                </div>
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  Scientific Methodology: Dual-Epoch Parallax & Spectroscopy
                </h2>
              </div>
              <button
                onClick={() => setShowMethodologyModal(false)}
                className="px-3 py-1 text-xs rounded-full uiobj-btn-secondary text-slate-700 cursor-pointer font-bold"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
              
              <div className="p-4 rounded-xl uiobj-inset space-y-2">
                <h4 className="font-bold text-orange-600 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full object-sphere-orange" />
                  <span>1. Dual-Epoch Blink Comparator Principle</span>
                </h4>
                <p>
                  As Earth orbits the Sun, the SPHEREx space observatory shifts its viewpoint by 2 Astronomical Units (AU) between Survey 1 (March) and Survey 2 (September). Distant background stars (hundreds of light-years away) show zero perceptible shift. However, a bound Solar System world at 50 - 100 AU displays an observable parallactic reflex motion:
                </p>
                <div className="font-mono text-center py-2.5 text-emerald-800 font-bold bg-sky-100/70 rounded-xl border border-sky-300 my-2 shadow-inner">
                  Parallax Angle (p) ≈ Baseline (2 AU) / Distance (d in AU)
                </div>
                <p>
                  By alternating between Survey 1 and Survey 2 frames, stationary objects stay locked while moving candidates jump visibly (~80px displacement on the detector array).
                </p>
              </div>

              <div className="p-4 rounded-xl uiobj-inset space-y-2">
                <h4 className="font-bold text-orange-600 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full object-sphere-cyan" />
                  <span>2. 102 Near-Infrared Spectral Channels (0.75 - 5.00 μm)</span>
                </h4>
                <p>
                  SPHEREx employs 6 Linear Variable Filter (LVF) detector arrays dividing the near-infrared spectrum into 102 channels. This enables chemical fingerprinting:
                </p>
                <ul className="list-disc pl-5 space-y-1 text-slate-700 mt-1 font-normal">
                  <li><strong className="text-slate-900">Array 1 (0.75 - 1.11 μm):</strong> Stellar photospheres (stars are bright, distant cold planets are faint).</li>
                  <li><strong className="text-slate-900">Array 2 (1.11 - 1.64 μm):</strong> Water ice absorption (1.5 μm) typical of cometary crusts.</li>
                  <li><strong className="text-slate-900">Array 3 & 4 (1.64 - 3.82 μm):</strong> Carbon monoxide (2.3 μm) and organic hydrocarbon dust (3.3 μm).</li>
                  <li><strong className="text-slate-900">Array 5 & 6 (3.82 - 5.00 μm):</strong> CO2 dry ice (4.26 μm) and the thermal emission blackbody peak (~4.8 μm) of cold planets (T ≈ 40 Kelvin).</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl uiobj-inset space-y-2">
                <h4 className="font-bold text-orange-600 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full object-sphere-magenta" />
                  <span>3. Signal-to-Noise Ratio (SNR) Thresholding & Noise Elimination</span>
                </h4>
                <p>
                  Raw ingestion flags 12 candidate photometric anomalies. By applying a <strong>75% SNR threshold</strong>, observation distance bounding (1 - 100 AU), and motion vector consistency, 8 spurious artifacts (cosmic ray proton hits, cryocooler jitter, diffraction spikes) are systematically eliminated, leaving <strong>4 confirmed physical candidates</strong>.
                </p>
              </div>

              <div className="p-4 rounded-xl uiobj-inset space-y-2">
                <h4 className="font-bold text-orange-600 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full object-sphere-emerald" />
                  <span>4. Human-in-the-Loop Scientific Validation</span>
                </h4>
                <p>
                  Artificial Intelligence is positioned solely as an automated feature extractor and triage assistant. Final discovery classification requires human astronomical review to prevent algorithmic false positives prior to Minor Planet Center (MPC) filing.
                </p>
              </div>

            </div>

            <div className="pt-3 border-t border-sky-200/80 flex justify-end">
              <button
                onClick={() => setShowMethodologyModal(false)}
                className="uiobj-btn-primary px-5 py-2 text-xs font-bold cursor-pointer"
              >
                Close Methodology Document
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
