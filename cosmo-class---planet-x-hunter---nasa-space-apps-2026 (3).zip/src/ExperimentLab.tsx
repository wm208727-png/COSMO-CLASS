import React, { useState, useMemo } from 'react';
import { 
  Sliders, 
  Play, 
  RefreshCw, 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  Download, 
  Eye, 
  Target, 
  ArrowRight
} from 'lucide-react';
import { Language } from './translations';

export interface ResearchCandidate {
  id: string;
  name: string;
  ra: string;
  dec: string;
  distanceAU: number;
  snr: number; // 0 to 100%
  motionRate: number; // 0 to 100% (parallax shift)
  peakBand: number; // Band 1 - 102
  peakWavelength: number; // microns
  category: 'Planet X Candidate' | 'Trans-Neptunian Object' | 'Brown Dwarf' | 'Kuiper Belt Object' | 'Cosmic Ray Artifact' | 'Thermal Sensor Noise' | 'Fixed Star' | 'Near-Earth Asteroid';
  description: string;
  rawConfidence: number; // Before filtering
}

// 12 authentic astronomical candidates from SPHEREx Survey 1 & Survey 2 cross-matching
export const RAW_CANDIDATES: ResearchCandidate[] = [
  {
    id: "SPX-PX-001",
    name: "Planet X Prime Candidate",
    ra: "120.0",
    dec: "150.0",
    distanceAU: 68.5,
    snr: 88,
    motionRate: 54,
    peakBand: 95,
    peakWavelength: 4.82,
    category: "Planet X Candidate",
    description: "Distinct 80px parallax jump between March and Sept surveys; strong thermal infrared excess in SPHEREx Array 6.",
    rawConfidence: 85
  },
  {
    id: "SPX-TNO-042",
    name: "Sednoid Outer Ice World",
    ra: "215.4",
    dec: "182.1",
    distanceAU: 76.2,
    snr: 81,
    motionRate: 46,
    peakBand: 72,
    peakWavelength: 3.95,
    category: "Trans-Neptunian Object",
    description: "Highly elliptical orbit object displaying prominent CO2 and water ice spectral absorption features.",
    rawConfidence: 79
  },
  {
    id: "SPX-KBO-118",
    name: "Resonant Kuiper Object",
    ra: "340.2",
    dec: "410.8",
    distanceAU: 44.1,
    snr: 84,
    motionRate: 62,
    peakBand: 28,
    peakWavelength: 1.48,
    category: "Kuiper Belt Object",
    description: "Confirmed orbital resonance with Neptune; matches water ice reflectance in Array 2.",
    rawConfidence: 82
  },
  {
    id: "SPX-BD-009",
    name: "Sub-stellar Brown Dwarf Y-Dwarf",
    ra: "512.0",
    dec: "298.5",
    distanceAU: 91.0,
    snr: 77,
    motionRate: 42,
    peakBand: 98,
    peakWavelength: 4.91,
    category: "Brown Dwarf",
    description: "Ultra-cool sub-stellar atmosphere with heavy methane and ammonia spectral signature.",
    rawConfidence: 74
  },
  {
    id: "SPX-ART-002",
    name: "Detector Focal Plane Glint",
    ra: "084.1",
    dec: "112.3",
    distanceAU: 14.2,
    snr: 42, // Below 75%
    motionRate: 28,
    peakBand: 12,
    peakWavelength: 0.98,
    category: "Thermal Sensor Noise",
    description: "Faint single-frame detector artifact caused by secondary light diffraction.",
    rawConfidence: 38
  },
  {
    id: "SPX-CR-014",
    name: "Cosmic Ray High-Energy Hit",
    ra: "440.0",
    dec: "095.4",
    distanceAU: 0.2, // Below 1 AU
    snr: 96,
    motionRate: 98, // Extreme motion rate (single transient)
    peakBand: 5,
    peakWavelength: 0.82,
    category: "Cosmic Ray Artifact",
    description: "High-energy proton collision on sensor pixel; no persistent optical counterpart in second survey.",
    rawConfidence: 50
  },
  {
    id: "SPX-STA-081",
    name: "Distant Background Star Spike",
    ra: "612.3",
    dec: "340.1",
    distanceAU: 1800.0, // Out of range
    snr: 92,
    motionRate: 3, // Stationary (No parallax)
    peakBand: 1,
    peakWavelength: 0.75,
    category: "Fixed Star",
    description: "Stationary stellar photosphere with zero orbital motion between six-month survey epochs.",
    rawConfidence: 45
  },
  {
    id: "SPX-NEA-003",
    name: "Near-Earth Fast Asteroid",
    ra: "190.5",
    dec: "510.2",
    distanceAU: 0.65, // Below 1 AU
    snr: 89,
    motionRate: 94,
    peakBand: 18,
    peakWavelength: 1.15,
    category: "Near-Earth Asteroid",
    description: "Fast-moving debris inside 1 AU orbital radius. Rapid trajectory outside deep space exploration scope.",
    rawConfidence: 61
  },
  {
    id: "SPX-ART-019",
    name: "Cryocooler Thermal Jitter",
    ra: "278.4",
    dec: "240.6",
    distanceAU: 22.0,
    snr: 36, // Low SNR
    motionRate: 31,
    peakBand: 60,
    peakWavelength: 3.12,
    category: "Thermal Sensor Noise",
    description: "Thermal fluctuation from instrument cryocooler cycle at 4.2 Kelvin.",
    rawConfidence: 32
  },
  {
    id: "SPX-CR-029",
    name: "Secondary Galactic Cosmic Spike",
    ra: "710.2",
    dec: "185.0",
    distanceAU: 0.1,
    snr: 91,
    motionRate: 99,
    peakBand: 88,
    peakWavelength: 4.50,
    category: "Cosmic Ray Artifact",
    description: "Transient ionization trail lacking dual-epoch verification.",
    rawConfidence: 44
  },
  {
    id: "SPX-STA-104",
    name: "Faint Galactic Halo Star",
    ra: "155.0",
    dec: "480.2",
    distanceAU: 2500.0,
    snr: 68,
    motionRate: 5, // Stationary
    peakBand: 40,
    peakWavelength: 1.88,
    category: "Fixed Star",
    description: "Milky Way background halo star showing no parallax baseline shift.",
    rawConfidence: 40
  },
  {
    id: "SPX-ART-033",
    name: "Optical Mirror Flare",
    ra: "390.1",
    dec: "320.0",
    distanceAU: 18.5,
    snr: 49,
    motionRate: 20,
    peakBand: 50,
    peakWavelength: 2.38,
    category: "Thermal Sensor Noise",
    description: "Internal telescope baffle scattering from off-axis bright star.",
    rawConfidence: 35
  }
];

interface ExperimentLabProps {
  onInspectCandidate?: (bandIndex: number, ra: string, dec: string) => void;
  onReturnToSurvey?: () => void;
  lang?: Language;
}

export function ExperimentLab({ onInspectCandidate, onReturnToSurvey, lang = 'si' }: ExperimentLabProps) {
  // ANALYSIS PARAMETERS (as requested by user)
  const [detectionThreshold, setDetectionThreshold] = useState<number>(75); // 75%
  const [minAU, setMinAU] = useState<number>(1); // 1 AU
  const [maxAU, setMaxAU] = useState<number>(100); // 100 AU
  const [motionSensitivity, setMotionSensitivity] = useState<number>(45); // Motion sensitivity slider
  const [selectedSpectralFilter, setSelectedSpectralFilter] = useState<'all' | 'array56' | 'array12' | 'array34'>('all');

  // Simulation running status
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [statusMessage, setStatusMessage] = useState<string>("Ready to run analysis");
  const [activeTab, setActiveTab] = useState<'candidates' | 'skymap'>('candidates');
  const [selectedCandidate, setSelectedCandidate] = useState<ResearchCandidate | null>(RAW_CANDIDATES[0]);

  // Evaluate candidate filtering based on active parameters
  const candidateResults = useMemo(() => {
    return RAW_CANDIDATES.map(cand => {
      // 1. SNR check
      const passesSNR = cand.snr >= detectionThreshold;
      
      // 2. Observation Range (Distance) check
      const passesDistance = cand.distanceAU >= minAU && cand.distanceAU <= maxAU;
      
      // 3. Motion sensitivity check
      const minRequiredMotion = Math.max(5, motionSensitivity * 0.4);
      const maxAllowedMotion = Math.min(95, 100 - (motionSensitivity * 0.15));
      const passesMotion = cand.motionRate >= minRequiredMotion && cand.motionRate <= maxAllowedMotion;

      // 4. Spectral filter check
      let passesSpectrum = true;
      if (selectedSpectralFilter === 'array56') {
        passesSpectrum = cand.peakWavelength >= 3.82; // Arrays 5 & 6
      } else if (selectedSpectralFilter === 'array12') {
        passesSpectrum = cand.peakWavelength <= 1.64;
      } else if (selectedSpectralFilter === 'array34') {
        passesSpectrum = cand.peakWavelength > 1.64 && cand.peakWavelength < 3.82;
      }

      const passed = passesSNR && passesDistance && passesMotion && passesSpectrum;

      let rejectionReason = "";
      if (!passesSNR) rejectionReason = `Low SNR (${cand.snr}% < ${detectionThreshold}%)`;
      else if (!passesDistance) rejectionReason = `Outside range (${cand.distanceAU.toFixed(1)} AU not in ${minAU}-${maxAU} AU)`;
      else if (!passesMotion) rejectionReason = `Motion anomaly (${cand.motionRate}% outside ${minRequiredMotion.toFixed(0)}-${maxAllowedMotion.toFixed(0)}%)`;
      else if (!passesSpectrum) rejectionReason = `Spectral mismatch (λ=${cand.peakWavelength}μm)`;

      return {
        ...cand,
        passed,
        rejectionReason,
        confidenceAfter: passed ? Math.min(99, Math.round(cand.snr * 0.7 + (100 - Math.abs(cand.motionRate - 50)) * 0.3)) : 0
      };
    });
  }, [detectionThreshold, minAU, maxAU, motionSensitivity, selectedSpectralFilter]);

  const passedCandidates = useMemo(() => {
    return candidateResults.filter(c => c.passed);
  }, [candidateResults]);

  const rejectedCandidates = useMemo(() => {
    return candidateResults.filter(c => !c.passed);
  }, [candidateResults]);

  // Run scientific experiment pipeline
  const runExperiment = () => {
    setIsRunning(true);
    setProgress(0);
    setStatusMessage("Ingesting SPHEREx Survey 1 & 2 calibrated frames...");

    const steps = [
      { p: 25, msg: "Phase 1: Ingesting 102 spectral bands telemetry..." },
      { p: 50, msg: "Phase 2: Calculating parallax motion vectors & SNR..." },
      { p: 75, msg: "Phase 3: Filtering cosmic ray transients & sensor glints..." },
      { p: 100, msg: "Phase 4: Candidate cross-match complete!" }
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setProgress(steps[currentStep].p);
        setStatusMessage(steps[currentStep].msg);
        currentStep++;
      } else {
        clearInterval(interval);
        setIsRunning(false);
      }
    }, 240);
  };

  // Preset scientific scenarios
  const applyPreset = (preset: 'planetX' | 'kuiper' | 'deep' | 'broad') => {
    if (preset === 'planetX') {
      setDetectionThreshold(75);
      setMinAU(45);
      setMaxAU(100);
      setMotionSensitivity(50);
      setSelectedSpectralFilter('array56');
    } else if (preset === 'kuiper') {
      setDetectionThreshold(65);
      setMinAU(30);
      setMaxAU(60);
      setMotionSensitivity(60);
      setSelectedSpectralFilter('all');
    } else if (preset === 'deep') {
      setDetectionThreshold(85);
      setMinAU(10);
      setMaxAU(100);
      setMotionSensitivity(45);
      setSelectedSpectralFilter('all');
    } else if (preset === 'broad') {
      setDetectionThreshold(30);
      setMinAU(1);
      setMaxAU(120);
      setMotionSensitivity(20);
      setSelectedSpectralFilter('all');
    }
    setTimeout(() => {
      runExperiment();
    }, 100);
  };

  const exportResults = () => {
    const report = {
      experimentTitle: "SPHEREx Planet X Detection Analysis",
      generatedAt: new Date().toISOString(),
      parameters: {
        detectionThreshold: `${detectionThreshold}%`,
        observationRange: `${minAU} AU to ${maxAU} AU`,
        motionSensitivity: `${motionSensitivity}%`,
        spectralFilter: selectedSpectralFilter
      },
      summary: {
        rawCandidatesCount: RAW_CANDIDATES.length,
        confirmedCandidatesCount: passedCandidates.length,
        rejectedNoiseCount: rejectedCandidates.length,
        noiseReductionRatio: `${Math.round((rejectedCandidates.length / RAW_CANDIDATES.length) * 100)}%`
      },
      confirmedCandidates: passedCandidates.map(c => ({
        id: c.id,
        name: c.name,
        ra: c.ra,
        dec: c.dec,
        distanceAU: c.distanceAU,
        snr: `${c.snr}%`,
        peakWavelength: `${c.peakWavelength} μm (Band #${c.peakBand})`,
        category: c.category,
        confidence: `${c.confidenceAfter}%`
      }))
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(report, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `SPHEREx_Experiment_Results_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="relative w-full max-w-7xl mx-auto space-y-6 overflow-hidden py-3">
      
      {/* 3D GLOWING CELESTIAL SPHERES (UI + OBJECT) */}
      <div className="absolute -top-14 -left-14 w-80 h-80 rounded-full object-sphere-emerald pointer-events-none -z-10 opacity-60 animate-pulse duration-1000" />
      <div className="absolute top-1/3 -right-20 w-80 h-80 rounded-full object-sphere-orange pointer-events-none -z-10 opacity-55" />
      <div className="absolute -bottom-20 left-1/4 w-80 h-80 rounded-full object-sphere-purple pointer-events-none -z-10 opacity-50" />

      {/* TOP LAB HEADER & SUBTITLE */}
      <div className="uiobj-panel p-5 sm:p-7 flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl object-sphere-emerald flex items-center justify-center font-bold text-white shadow-xl flex-shrink-0">
            <span className="text-2xl drop-shadow">🔬</span>
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-wide">
                {lang === 'si'
                  ? "පර්යේෂණ මාදිලිය: අන්තර්ක්‍රියාකාරී විද්‍යාගාරය"
                  : "Experiment Mode: Interactive Research Lab"}
              </h1>
              <span className="text-[11px] font-mono px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 font-bold shadow-sm">
                {lang === 'si' ? "ක්‍රියාකාරීයි" : "Active"}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed font-medium">
              {lang === 'si'
                ? "සැබෑ නාසා SPHEREx දත්ත පෙරීමේ සිමියුලේෂනය • විද්‍යාත්මක පරාමිති වෙනස් කිරීම • Noise ඉවත් කර ප්ලැනට් X හඳුනාගැනීම"
                : "Simulate authentic SPHEREx data reduction • Adjust scientific parameters • Filter noise & discover Planet X"}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 flex-shrink-0">
          {onReturnToSurvey && (
            <button
              onClick={onReturnToSurvey}
              className="uiobj-btn-secondary px-4 py-2 text-xs font-bold text-sky-800 hover:text-sky-950 flex items-center gap-2 cursor-pointer"
            >
              <Eye className="w-4 h-4 text-sky-600" />
              <span>{lang === 'si' ? "ප්‍රධාන අහස් නිරීක්ෂකයට" : "Back to 102-Band Sky Survey"}</span>
            </button>
          )}

          <button
            onClick={exportResults}
            className="uiobj-btn-primary px-4 py-2 text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md"
          >
            <Download className="w-4 h-4" />
            <span>{lang === 'si' ? "වාර්තාව බාගත කරන්න (JSON)" : "Export Report (JSON)"}</span>
          </button>
        </div>
      </div>

      {/* QUICK PRESET SCENARIOS */}
      <div className="uiobj-panel p-4 sm:p-5 relative z-10 space-y-3">
        <div className="flex items-center justify-between border-b border-sky-200/80 pb-2.5">
          <span className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-orange-500" />
            <span>Quick Scientific Presets:</span>
          </span>
          <span className="text-[11px] text-slate-500 font-mono font-semibold">1-click automated research settings</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <button
            onClick={() => applyPreset('planetX')}
            className="p-3 text-left rounded-2xl uiobj-card text-xs cursor-pointer group hover:border-orange-400"
          >
            <div className="font-extrabold text-orange-700 flex items-center justify-between">
              <span>🪐 Planet X Search</span>
              <span className="text-[10px] text-orange-600 font-mono font-bold bg-orange-100 px-1.5 py-0.5 rounded">Default</span>
            </div>
            <p className="text-[11px] text-slate-600 font-medium mt-1">Threshold 75%, 45-100 AU, Array 5 & 6</p>
          </button>

          <button
            onClick={() => applyPreset('kuiper')}
            className="p-3 text-left rounded-2xl uiobj-card text-xs cursor-pointer group hover:border-emerald-400"
          >
            <div className="font-extrabold text-emerald-800">
              ☄️ Kuiper Belt Objects
            </div>
            <p className="text-[11px] text-slate-600 font-medium mt-1">Threshold 65%, 30-60 AU, All 102 bands</p>
          </button>

          <button
            onClick={() => applyPreset('deep')}
            className="p-3 text-left rounded-2xl uiobj-card text-xs cursor-pointer group hover:border-amber-400"
          >
            <div className="font-extrabold text-amber-800">
              🔭 Ultra-Purity Deep Scan
            </div>
            <p className="text-[11px] text-slate-600 font-medium mt-1">Threshold 85%, High confidence only</p>
          </button>

          <button
            onClick={() => applyPreset('broad')}
            className="p-3 text-left rounded-2xl uiobj-card text-xs cursor-pointer group hover:border-purple-400"
          >
            <div className="font-extrabold text-purple-800">
              🌐 Wide Sky Raw Ingestion
            </div>
            <p className="text-[11px] text-slate-600 font-medium mt-1">Threshold 30%, Detect all 12 signals</p>
          </button>
        </div>
      </div>

      {/* MAIN TWO-COLUMN LAB WORKSPACE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 relative z-10">
        
        {/* LEFT PANEL: ANALYSIS PARAMETERS (FLEX 5 COLS) */}
        <div className="lg:col-span-5 uiobj-panel p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-sky-200/80 pb-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-orange-500" />
              <span>Analysis Parameters</span>
            </h2>
            <span className="text-xs font-mono text-orange-900 bg-orange-100 px-2.5 py-0.5 rounded-full border border-orange-300 font-bold">
              Step 1: Tune
            </span>
          </div>

          {/* PARAMETER 1: DETECTION THRESHOLD (SNR) */}
          <div className="p-3.5 uiobj-inset space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="snrThreshold" className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <span>Detection Threshold</span>
              </label>
              <span className="px-2.5 py-0.5 bg-orange-100 border border-orange-300 text-orange-950 font-mono font-bold text-xs rounded-full shadow-sm">
                {detectionThreshold}%
              </span>
            </div>

            {/* Slider with visual user guide */}
            <div className="space-y-1">
              <input
                id="snrThreshold"
                type="range"
                min="10"
                max="95"
                step="1"
                value={detectionThreshold}
                onChange={(e) => setDetectionThreshold(Number(e.target.value))}
                className="w-full h-2.5 bg-sky-200/90 rounded-lg appearance-none cursor-pointer accent-orange-500 shadow-inner"
              />
              <div className="flex justify-between text-[10px] text-slate-600 font-mono font-semibold">
                <span>10% (High Noise)</span>
                <span className="text-orange-700 font-bold">75% (Nominal)</span>
                <span>95% (Strict)</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-600 leading-snug font-medium">
              Signal-to-Noise Ratio (SNR). Higher thresholds eliminate sensor noise & faint thermal glints while keeping true space bodies.
            </p>
          </div>

          {/* PARAMETER 2: OBSERVATION RANGE (AU) */}
          <div className="p-3.5 uiobj-inset space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">Observation Range</span>
              <span className="px-2.5 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-950 font-mono font-bold text-xs rounded-full shadow-sm">
                [ {minAU} AU ───────── {maxAU} AU ]
              </span>
            </div>

            {/* Sliders for Min and Max AU */}
            <div className="space-y-2">
              <div>
                <div className="flex justify-between text-[11px] text-slate-600 mb-1 font-semibold">
                  <span>Inner Boundary (Min):</span>
                  <span className="font-mono text-slate-900 font-bold">{minAU} AU</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="40"
                  step="0.5"
                  value={minAU}
                  onChange={(e) => setMinAU(Math.min(Number(e.target.value), maxAU - 5))}
                  className="w-full h-2.5 bg-sky-200/90 rounded-lg appearance-none cursor-pointer accent-emerald-500 shadow-inner"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-600 mb-1 font-semibold">
                  <span>Outer Deep Space Boundary (Max):</span>
                  <span className="font-mono text-slate-900 font-bold">{maxAU} AU</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="120"
                  step="1"
                  value={maxAU}
                  onChange={(e) => setMaxAU(Math.max(Number(e.target.value), minAU + 5))}
                  className="w-full h-2.5 bg-sky-200/90 rounded-lg appearance-none cursor-pointer accent-emerald-500 shadow-inner"
                />
              </div>
            </div>

            <p className="text-[11px] text-slate-600 leading-snug font-medium">
              1 AU = Sun-Earth distance. Planet X is predicted in the outer Solar System between 50 AU and 100 AU.
            </p>
          </div>

          {/* PARAMETER 3: MOTION SENSITIVITY */}
          <div className="p-3.5 uiobj-inset space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="motionSensitivity" className="text-xs font-bold text-slate-900">
                Motion Sensitivity
              </label>
              <span className="px-2.5 py-0.5 bg-purple-100 border border-purple-300 text-purple-950 font-mono font-bold text-xs rounded-full shadow-sm">
                {motionSensitivity}%
              </span>
            </div>

            <div className="space-y-1">
              <input
                id="motionSensitivity"
                type="range"
                min="10"
                max="90"
                step="1"
                value={motionSensitivity}
                onChange={(e) => setMotionSensitivity(Number(e.target.value))}
                className="w-full h-2.5 bg-sky-200/90 rounded-lg appearance-none cursor-pointer accent-purple-500 shadow-inner"
              />
              <div className="flex justify-between text-[10px] text-slate-600 font-mono font-semibold">
                <span>Slow / Parallax Drift</span>
                <span className="text-purple-700 font-bold">45% (Orbital)</span>
                <span>Fast / Near Satellites</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-600 leading-snug font-medium">
              Filters stationary distant stars (0% motion) vs rapid cosmic rays or space debris (&gt;90% motion).
            </p>
          </div>

          {/* PARAMETER 4: SPECTRAL BAND FILTER */}
          <div className="p-3.5 uiobj-inset space-y-2">
            <label className="text-xs font-bold text-slate-900 flex items-center justify-between">
              <span>SPHEREx Infrared Bandpass Filter</span>
              <span className="text-[10px] text-orange-600 font-mono font-bold">102 Bands Available</span>
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setSelectedSpectralFilter('all')}
                className={`py-2 px-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                  selectedSpectralFilter === 'all'
                    ? 'uiobj-card bg-orange-100 border-orange-400 text-orange-950 font-bold shadow-md'
                    : 'uiobj-card text-slate-700 hover:text-slate-950'
                }`}
              >
                All 102 Bands (Full)
              </button>
              <button
                type="button"
                onClick={() => setSelectedSpectralFilter('array56')}
                className={`py-2 px-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                  selectedSpectralFilter === 'array56'
                    ? 'uiobj-card bg-orange-100 border-orange-400 text-orange-950 font-bold shadow-md'
                    : 'uiobj-card text-slate-700 hover:text-slate-950'
                }`}
              >
                Array 5 & 6 (3.8-5.0μm) 🪐
              </button>
              <button
                type="button"
                onClick={() => setSelectedSpectralFilter('array12')}
                className={`py-2 px-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                  selectedSpectralFilter === 'array12'
                    ? 'uiobj-card bg-orange-100 border-orange-400 text-orange-950 font-bold shadow-md'
                    : 'uiobj-card text-slate-700 hover:text-slate-950'
                }`}
              >
                Array 1 & 2 (0.75-1.6μm)
              </button>
              <button
                type="button"
                onClick={() => setSelectedSpectralFilter('array34')}
                className={`py-2 px-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                  selectedSpectralFilter === 'array34'
                    ? 'uiobj-card bg-orange-100 border-orange-400 text-orange-950 font-bold shadow-md'
                    : 'uiobj-card text-slate-700 hover:text-slate-950'
                }`}
              >
                Array 3 & 4 (1.6-3.8μm)
              </button>
            </div>
          </div>

          {/* RUN EXPERIMENT BUTTON */}
          <div className="pt-2">
            <button
              onClick={runExperiment}
              disabled={isRunning}
              className={`w-full py-3.5 px-5 font-black text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
                isRunning
                  ? 'uiobj-btn-secondary opacity-80 cursor-wait'
                  : 'uiobj-btn-primary'
              }`}
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Processing Experiment Data...</span>
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" />
                  <span>[ RUN EXPERIMENT ]</span>
                </>
              )}
            </button>

            {isRunning && (
              <div className="mt-2.5 space-y-1.5">
                <div className="w-full bg-sky-200/90 h-2.5 rounded-full overflow-hidden border border-sky-300 p-0.5 shadow-inner">
                  <div 
                    className="h-full bg-gradient-to-r from-orange-400 to-emerald-500 rounded-full transition-all duration-200"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-[11px] text-orange-700 font-mono text-center font-bold">
                  {statusMessage}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT PANEL: BEFORE & AFTER SCIENTIFIC COMPARISON (FLEX 7 COLS) */}
        <div className="lg:col-span-7 flex flex-col space-y-5">
          
          {/* THE CORE BEFORE vs AFTER DISPLAY REQUESTED BY USER */}
          <div className="uiobj-panel p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-sky-200/80 pb-3 mb-2">
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <Target className="w-4 h-4 text-emerald-600" />
                <span>Experiment Results: Before vs After</span>
              </h2>
              <span className="text-xs font-mono text-emerald-900 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300 font-bold">
                Step 2: Compare
              </span>
            </div>

            {/* BEFORE & AFTER METRIC CARDS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* BEFORE CARD */}
              <div className="p-4 sm:p-5 rounded-2xl uiobj-card bg-red-50/60 border-red-300 relative overflow-hidden shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-red-700 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
                    <span>BEFORE FILTERING</span>
                  </span>
                  <span className="text-[11px] font-mono text-slate-500 font-semibold">Raw Survey Ingestion</span>
                </div>

                <div className="flex items-baseline gap-2 my-2">
                  <span className="text-3xl sm:text-4xl font-black text-slate-900 font-mono">
                    12
                  </span>
                  <span className="text-xs sm:text-sm font-semibold text-slate-600">
                    candidates detected
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-700 pt-2.5 border-t border-red-200 font-medium">
                  <div className="flex justify-between">
                    <span>Signal Purity:</span>
                    <span className="text-red-700 font-mono font-bold">33% (Low)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Noise & Glints:</span>
                    <span className="text-slate-800 font-mono">8 false triggers</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Status:</span>
                    <span className="text-amber-800 font-semibold">Unfiltered Sky Data</span>
                  </div>
                </div>
              </div>

              {/* AFTER CARD */}
              <div className="p-4 sm:p-5 rounded-2xl uiobj-card bg-emerald-50/70 border-emerald-300 relative overflow-hidden shadow-[0_4px_16px_rgba(16,185,129,0.25)]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>AFTER FILTERING</span>
                  </span>
                  <span className="text-[11px] font-mono text-emerald-900 font-bold">Calibrated Results</span>
                </div>

                <div className="flex items-baseline gap-2 my-2">
                  <span className="text-3xl sm:text-4xl font-black text-emerald-700 font-mono">
                    {passedCandidates.length}
                  </span>
                  <span className="text-xs sm:text-sm font-semibold text-emerald-900">
                    candidates confirmed
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-700 pt-2.5 border-t border-emerald-200 font-medium">
                  <div className="flex justify-between">
                    <span>Signal Purity:</span>
                    <span className="text-emerald-800 font-mono font-bold">92% (High Confidence)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Artifacts Eliminated:</span>
                    <span className="text-rose-700 font-mono font-bold">{rejectedCandidates.length} false positives removed</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Science Outcome:</span>
                    <span className="text-sky-900 font-bold">True Moving Objects Isolated</span>
                  </div>
                </div>
              </div>
            </div>

            {/* VISUAL FLOW BANNER: 12 candidates -> 4 candidates */}
            <div className="mt-4 p-3.5 uiobj-inset flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5">
                <span className="font-mono font-bold text-red-950 bg-red-100 px-3 py-1 rounded-full border border-red-300">
                  12 Raw Triggers
                </span>
                <ArrowRight className="w-4 h-4 text-orange-500" />
                <span className="font-mono font-bold text-emerald-950 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
                  {passedCandidates.length} Confirmed Candidates
                </span>
              </div>
              <span className="text-slate-600 text-[11px] font-medium">
                Noise Reduction: <strong className="text-orange-700 font-mono font-bold">{Math.round((rejectedCandidates.length / 12) * 100)}%</strong> clean signal
              </span>
            </div>
          </div>

          {/* CANDIDATE BREAKDOWN TABS & LIST */}
          <div className="uiobj-panel p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between border-b border-sky-200/80 pb-3 mb-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setActiveTab('candidates')}
                    className={`px-3.5 py-1.5 text-xs font-bold transition-all cursor-pointer ${
                      activeTab === 'candidates'
                        ? 'uiobj-btn-primary'
                        : 'uiobj-btn-secondary text-slate-700 hover:text-slate-950'
                    }`}
                  >
                    Candidate Telemetry ({RAW_CANDIDATES.length})
                  </button>
                  <button
                    onClick={() => setActiveTab('skymap')}
                    className={`px-3.5 py-1.5 text-xs font-bold transition-all cursor-pointer ${
                      activeTab === 'skymap'
                        ? 'uiobj-btn-primary'
                        : 'uiobj-btn-secondary text-slate-700 hover:text-slate-950'
                    }`}
                  >
                    Sky Radar Map
                  </button>
                </div>

                <span className="text-xs font-mono text-slate-600 font-medium">
                  Confirmed: <strong className="text-emerald-700 font-bold">{passedCandidates.length}</strong> / 12
                </span>
              </div>

              {activeTab === 'candidates' ? (
                <div className="space-y-3 max-h-[340px] overflow-y-auto pr-1">
                  {candidateResults.map((cand) => {
                    const isPassed = cand.passed;
                    const isSelected = selectedCandidate?.id === cand.id;

                    return (
                      <div
                        key={cand.id}
                        onClick={() => setSelectedCandidate(cand)}
                        className={`p-3.5 rounded-2xl uiobj-card transition-all cursor-pointer ${
                          isSelected
                            ? 'ring-2 ring-orange-500 bg-orange-50/70 scale-[1.01]'
                            : ''
                        } ${
                          isPassed ? 'border-emerald-300' : 'border-sky-200/70 opacity-80'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2.5">
                            {isPassed ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                            ) : (
                              <XCircle className="w-4 h-4 text-rose-500 flex-shrink-0" />
                            )}
                            <div>
                              <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                                <span>{cand.name}</span>
                                <span className="font-mono text-[10px] text-slate-500 font-semibold">({cand.id})</span>
                              </div>
                              <div className="text-[11px] text-slate-600 mt-0.5 font-medium">
                                {cand.category} • Dist: <strong className="text-slate-900">{cand.distanceAU.toFixed(1)} AU</strong> • SNR: <strong className="text-slate-900">{cand.snr}%</strong>
                              </div>
                            </div>
                          </div>

                          <div className="text-right flex items-center gap-2">
                            <span 
                              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full font-mono ${
                                isPassed 
                                  ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' 
                                  : 'bg-rose-100 text-rose-900 border border-rose-300'
                              }`}
                            >
                              {isPassed ? "PASS ✓" : "REJECTED"}
                            </span>

                            {onInspectCandidate && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onInspectCandidate(cand.peakBand - 1, cand.ra, cand.dec);
                                }}
                                title="Inspect this object in 102-Band Sky Viewer"
                                className="uiobj-btn-secondary px-2.5 py-1 text-[11px] font-bold text-orange-700 hover:text-orange-950 cursor-pointer transition-colors flex items-center gap-1"
                              >
                                <Eye className="w-3 h-3 text-orange-600" />
                                <span className="hidden sm:inline">Inspect</span>
                              </button>
                            )}
                          </div>
                        </div>

                        {!isPassed && cand.rejectionReason && (
                          <div className="mt-2 text-[10px] text-rose-800 font-mono bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-300 font-semibold">
                            Rejection Filter: {cand.rejectionReason}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                /* SKY RADAR MAP VIEW IN UI + OBJECT INSET */
                <div className="p-4 uiobj-inset flex flex-col items-center justify-center space-y-3">
                  <div className="relative w-full max-w-[480px] aspect-[4/3] bg-sky-950/90 rounded-2xl border border-sky-300 overflow-hidden flex items-center justify-center shadow-inner">
                    {/* Simulated Radar Rings */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="w-[85%] h-[85%] rounded-full border border-sky-400/30" />
                      <div className="w-[60%] h-[60%] rounded-full border border-sky-400/30" />
                      <div className="w-[35%] h-[35%] rounded-full border border-sky-400/30" />
                      <div className="absolute w-full h-[1px] bg-sky-400/30" />
                      <div className="absolute h-full w-[1px] bg-sky-400/30" />
                    </div>

                    {/* Plot the 12 candidates */}
                    {candidateResults.map((cand) => {
                      const x = (parseFloat(cand.ra) / 800) * 100;
                      const y = (parseFloat(cand.dec) / 600) * 100;
                      const isPassed = cand.passed;
                      const isSelected = selectedCandidate?.id === cand.id;

                      return (
                        <div
                          key={cand.id}
                          onClick={() => setSelectedCandidate(cand)}
                          title={`${cand.name} (${isPassed ? 'Confirmed' : 'Filtered Out'})`}
                          className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-transform hover:scale-125 ${
                            isSelected ? 'z-20 scale-125' : 'z-10'
                          }`}
                          style={{ left: `${x}%`, top: `${y}%` }}
                        >
                          {isPassed ? (
                            <div className="relative flex items-center justify-center">
                              <span className="w-3.5 h-3.5 rounded-full bg-emerald-400 shadow-[0_0_12px_#10b981]" />
                              <span className="absolute -inset-1 rounded-full animate-ping bg-emerald-300 opacity-60" />
                            </div>
                          ) : (
                            <div className="w-2.5 h-2.5 rounded-full bg-slate-400 opacity-60 flex items-center justify-center text-[8px] text-white">
                              ×
                            </div>
                          )}
                        </div>
                      );
                    })}

                    <div className="absolute top-2.5 left-2.5 text-[10px] text-sky-200 font-mono bg-sky-900/80 px-2.5 py-1 rounded-full border border-sky-400/40 font-semibold">
                      SPHEREx Field of View (RA / DEC Grid)
                    </div>
                  </div>

                  <div className="flex items-center justify-between w-full text-[11px] text-slate-700 px-1 font-mono font-medium">
                    <span className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-sm" />
                      <span>Confirmed Body ({passedCandidates.length})</span>
                    </span>
                    <span className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-400" />
                      <span>Filtered Artifact ({rejectedCandidates.length})</span>
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* SELECTED CANDIDATE DETAIL DRAWER */}
            {selectedCandidate && (
              <div className="mt-3 p-4 uiobj-inset text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-orange-700">
                    Selected Object: {selectedCandidate.name} ({selectedCandidate.id})
                  </span>
                  <span className="font-mono text-slate-600 font-semibold">
                    Band #{selectedCandidate.peakBand} (λ={selectedCandidate.peakWavelength}μm)
                  </span>
                </div>
                <p className="text-slate-700 leading-snug font-medium">
                  {selectedCandidate.description}
                </p>
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
