// COSMO CLASS - Bilingual Localization System (Sinhala & English)
// Specially designed for Sri Lankan students, teachers, and global astronomy enthusiasts.

export type Language = 'si' | 'en';

export interface Translations {
  // Navigation & Branding
  brandTitle: string;
  brandTag: string;
  creatorTag: string;
  navSurvey: string;
  navExperiment: string;
  navAi: string;
  navEvidence: string;
  navGuideBtn: string;
  navReturnSurvey: string;
  langSwitchLabel: string;
  nasaConnected: string;

  // Sri Lankan Astronomy Guide
  sriLankaGuideTitle: string;
  sriLankaGuideBadge: string;
  sriLankaGuideSubtitle: string;
  guideWhatIsPlanetXTitle: string;
  guideWhatIsPlanetXDesc: string;
  guideBlinkTitle: string;
  guideBlinkDesc: string;
  guideSpectraTitle: string;
  guideSpectraDesc: string;
  guideSriLankaRoleTitle: string;
  guideSriLankaRoleDesc: string;

  // 3-Step Quick Guide
  quickGuideTitle: string;
  quickGuideSubtitle: string;
  step1Title: string;
  step1Desc: string;
  step2Title: string;
  step2Desc: string;
  step3Title: string;
  step3Desc: string;

  // Sky Spectrometer & Cockpit
  spectrometerTitle: string;
  keyboardShortcuts: string;
  prevBandBtn: string;
  nextBandBtn: string;
  bandOf102: string;
  nasaImageBadge: string;
  candidatePosition: string;
  thermalRadiance: string;
  clickSkyHint: string;

  // Mission Controls Sidebar
  missionControlsTitle: string;
  spherexHudBadge: string;
  expModeTitle: string;
  expModeBadge: string;
  expModeDesc: string;
  launchExpLabBtn: string;
  surveyCompTitle: string;
  survey1Btn: string;
  survey2Btn: string;
  startBlinkBtn: string;
  stopBlinkBtn: string;
  browseBandsTitle: string;
  playTimelapseBtn: string;
  pauseTimelapseBtn: string;
  audioSonarTitle: string;
  sonarEnabled: string;
  sonarDisabled: string;
  enableSonarBtn: string;
  activeSonarBtn: string;
  sonarHelpText: string;
  myDiscoveriesTitle: string;
  exportBtn: string;
  clearBtn: string;
  noDiscoveriesYet: string;
  nasaDataTitle: string;
  bandsActiveBadge: string;
  apiKeyBadge: string;

  // CosmoClass Suite
  suiteTitle: string;
  suiteSubtitle: string;
  suiteTag: string;
  filterAll: string;
  visitToolBtn: string;
  suiteFooterNote: string;

  // Views & Pages
  aiPageTitle: string;
  aiPageBadge: string;
  aiPageSubtitle: string;
  evidencePageTitle: string;
  evidencePageBadge: string;
  evidencePageSubtitle: string;
  expLabPageTitle: string;
  expLabPageBadge: string;
  expLabPageSubtitle: string;

  // Footer
  footerTagline: string;
  footerExploreAdGenie: string;
  footerViewSource: string;
  footerManifesto1: string;
  footerManifestoQuote: string;
  footerNasaNote: string;
  footerDevLabel: string;
  footerAgeLabel: string;
  footerAgeVal: string;
  footerLocationLabel: string;
  footerLocationVal: string;
  footerCopyright: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  si: {
    // Navigation & Branding
    brandTitle: "COSMO CLASS",
    brandTag: "ප්ලැනට් X ගවේෂකය",
    creatorTag: "නිර්මාණය: ඒ. දිසස් දින්සිත් (වයස 12) • NASA Space Apps Challenge 2026",
    navSurvey: "102-තරංග අහස් සිතියම",
    navExperiment: "පර්යේෂණ මාදිලිය (12 → 4)",
    navAi: "AI විශ්ලේෂණ පද්ධතිය",
    navEvidence: "නාසා දත්ත සහ මූලාශ්‍ර",
    navGuideBtn: "මඟපෙන්වීම",
    navReturnSurvey: "🔭 ප්‍රධාන අහස් නිරීක්ෂකයට පිවිසෙන්න",
    langSwitchLabel: "භාෂාව / Language",
    nasaConnected: "NASA සජීවීව සම්බන්ධයි",

    // Sri Lankan Astronomy Guide
    sriLankaGuideTitle: "🇱🇰 ශ්‍රී ලාංකීය සිසුන්ට සහ අභ්‍යවකාශ ගවේෂකයන්ට විශේෂ මඟපෙන්වීම",
    sriLankaGuideBadge: "ශ්‍රී ලංකා තාරකා විද්‍යා අධ්‍යාපනය",
    sriLankaGuideSubtitle: "නෙප්චූන්ට ඔබ්බෙන් පිහිටි අභිරහස් 9 වන ග්‍රහලෝකය (Planet X) සෙවීමේ සරල විද්‍යාත්මක ක්‍රමවේදය",
    guideWhatIsPlanetXTitle: "ප්ලැනට් X (Planet X) යනු කුමක්ද?",
    guideWhatIsPlanetXDesc: "අපගේ සෞරග්‍රහ මණ්ඩලයේ නෙප්චූන් සහ ප්ලූටෝ කක්ෂයන්ට එපිටින් (නක්ෂත්‍ර ඒකක 50-100ක් ඈතින්) පිහිටා ඇතැයි ගණිතමය ආකෘති මඟින් අනුමාන කෙරෙන 9 වන දැවැන්ත ග්‍රහලෝකයයි. එය සූර්යයාගෙන් ලැබෙන ආලෝකය ඉතා අඩු බැවින් අතිශය අඳුරු හා සීතල ය.",
    guideBlinkTitle: "බ්ලින්ක් කම්පැරේටරය (Blink Comparator) ක්‍රියා කරන්නේ කෙසේද?",
    guideBlinkDesc: "1930 දී ක්ලයිඩ් ටොම්බෝ විසින් ප්ලූටෝ සොයාගත් ඓතිහාසික ක්‍රමවේදය මෙයයි. මාස 6 ක පරතරයකින් (මාර්තු සහ සැප්තැම්බර්) ගත් අහසේ ඡායාරූප දෙක එකිනෙක මාරුවෙන් මාරුවට බැලීමේදී, පසුබිමේ ඇති ආලෝක වර්ෂ ගණනාවක් ඈතින් පිහිටි තරු එකම තැන නිශ්චලව තිබියදී, චලනය වන ප්ලැනට් X අපේක්ෂිතයා පමණක් තැනකින් තැනකට පනියි!",
    guideSpectraTitle: "102 අධෝරක්ත (Infrared) තරංග ආයාම වලින් බලන්නේ ඇයි?",
    guideSpectraDesc: "ප්ලැනට් X හි උෂ්ණත්වය කෙල්වින් 40-60 පමණ වන නිසා දෘශ්‍ය ආලෝකයෙන් නොපෙනේ. එහෙත් නාසා SPHEREx දුරේක්ෂයේ 4.5 μm සිට 5.0 μm දක්වා වන ගැඹුරු අධෝරක්ත (Thermal Infrared) තරංග ආයාමයන්හිදී එහි තාප විකිරණය දීප්තිමත්ව බබළයි.",
    guideSriLankaRoleTitle: "ශ්‍රී ලංකාවේ අභ්‍යවකාශ අධ්‍යාපනය සහ ඔබේ දායකත්වය",
    guideSriLankaRoleDesc: "ආතර් සී. ක්ලාක් ආයතනය (ACCMT), කොළඹ ග්‍රහලෝකාගාරය සහ පාසල් තාරකා විද්‍යා සංගම් හරහා මෙරට දූ දරුවන්ට ලෝක මට්ටමේ පර්යේෂණ කිරීමට මෙම COSMO CLASS පද්ධතිය සම්පූර්ණයෙන්ම නොමිලේ විවෘත කර ඇත.",

    // 3-Step Quick Guide
    quickGuideTitle: "සරල පියවර 3 කින් ප්ලැනට් X සොයාගන්නේ කෙසේද?",
    quickGuideSubtitle: "පාසල් සිසුන්ට, ගුරුවරුන්ට සහ තාරකා විද්‍යා ලෝලීන්ට පහසුවෙන් තේරුම් ගත හැකිය",
    step1Title: "1. සර්වේ ඡායාරූප දෙක සංසන්දනය කරන්න",
    step1Desc: "Auto Blink බටන් එක ක්ලික් කරන්න. මාර්තු (Survey 1) සහ සැප්තැම්බර් (Survey 2) අතර අහස මාරුවෙයි. පසුබිම් තරු නිශ්චලව පවතී.",
    step2Title: "2. චලනය වන රතු තිත හඳුනාගන්න",
    step2Desc: "සර්වේ දෙක අතර පිහිටීම වෙනස් වන රතු පැහැති තිතක් පෙනෙනවාද? ඒ ඔබේ ප්ලැනට් X අපේක්ෂිතයායි! එය මත ක්ලික් කර ඛණ්ඩාංක සටහන් කරගන්න.",
    step3Title: "3. තරංග ආයාම 102 පිරික්සන්න",
    step3Desc: "◀ සහ ▶ ඊතල බටන් ඔබමින් නාසා SPHEREx දුරේක්ෂයේ 0.75 μm සිට 5.00 μm දක්වා වන වර්ණාවලි තරංග 102 පුරාම නිරීක්ෂණය කරන්න.",

    // Sky Spectrometer & Cockpit
    spectrometerTitle: "SPHEREx අධෝරක්ත වර්ණාවලීමානය (Near-Infrared Spectrometer)",
    keyboardShortcuts: "යතුරුපුවරු කෙටිමං: ◀ වම් ඊතලය | ▶ දකුණු ඊතලය",
    prevBandBtn: "◀ පෙර තරංගය",
    nextBandBtn: "මීළඟ තරංගය ▶",
    bandOf102: "තරංගය (102 න්)",
    nasaImageBadge: "NASA ඡායාරූපය:",
    candidatePosition: "අපේක්ෂකයාගේ පිහිටීම:",
    thermalRadiance: "තාප දීප්තිය:",
    clickSkyHint: "ඛණ්ඩාංක (RA/DEC) සටහන් කරගැනීමට අහසේ ඕනෑම තැනක් ක්ලික් කරන්න",

    // Mission Controls Sidebar
    missionControlsTitle: "මිෂන් පාලන පුවරුව (Mission Controls)",
    spherexHudBadge: "SPHEREx HUD",
    expModeTitle: "පර්යේෂණාගාර මාදිලිය",
    expModeBadge: "අපේක්ෂිතයන් 12 → 4",
    expModeDesc: "විශ්වාසනීයත්ව සීමාව (75%), දුර (1-100 AU) සහ සංවේදීතාව වෙනස් කර සැබෑ විද්‍යාත්මක සිමියුලේෂන් ධාවනය කරන්න.",
    launchExpLabBtn: "පර්යේෂණාගාරය විවෘත කරන්න 🔬",
    surveyCompTitle: "සර්වේ සංසන්දනය (Survey Comparison):",
    survey1Btn: "සර්වේ 1 (මාර්තු)",
    survey2Btn: "සර්වේ 2 (සැප්තැම්බර්)",
    startBlinkBtn: "ස්වයංක්‍රීය Blink අරඹන්න",
    stopBlinkBtn: "ස්වයංක්‍රීය Blink නවතන්න",
    browseBandsTitle: "තරංග ආයාම 102 පිරික්සන්න:",
    playTimelapseBtn: "තරංග 102 සජීවීකරණය ධාවනය",
    pauseTimelapseBtn: "සජීවීකරණය විරාමය කරන්න",
    audioSonarTitle: "ශ්‍රව්‍ය සෝනාර් (Accessibility):",
    sonarEnabled: "සක්‍රියයි",
    sonarDisabled: "අක්‍රියයි",
    enableSonarBtn: "ශ්‍රව්‍ය සෝනාර් සක්‍රිය කරන්න 🔇",
    activeSonarBtn: "ශ්‍රව්‍ය සෝනාර් ක්‍රියාත්මකයි 🔊",
    sonarHelpText: "මූසික කර්සරය ප්ලැනට් X වෙත ළංවන විට නිකුත්වන ශබ්ද සංඥා වේගය වැඩිවේ.",
    myDiscoveriesTitle: "මගේ සොයාගැනීම්:",
    exportBtn: "බාගත කරන්න (Export)",
    clearBtn: "මකන්න (Clear)",
    noDiscoveriesYet: "තවමත් අපේක්ෂකයින් සටහන් කර නැත.\nඅහසේ රූපය මත ක්ලික් කර ඛණ්ඩාංක සටහන් කරන්න!",
    nasaDataTitle: "NASA විද්‍යාත්මක තොරතුරු:",
    bandsActiveBadge: "තරංග 102: සක්‍රියයි ✓",
    apiKeyBadge: "NASA API යතුර: සත්‍යාපිතයි ✓",

    // CosmoClass Suite
    suiteTitle: "COSMO CLASS අධ්‍යාපනික මෙවලම් පද්ධතිය",
    suiteSubtitle: "ශ්‍රී ලාංකීය සිසුන්ගේ සහ තාරකා විද්‍යා පර්යේෂකයන්ගේ දැනුම පුළුල් කිරීම සඳහා නිර්මාණය කරන ලද නිල මෙවලම් 11",
    suiteTag: "අභ්‍යවකාශ සහ තාක්ෂණ මෙවලම්",
    filterAll: "සියල්ල (All Tools)",
    visitToolBtn: "මෙවලම විවෘත කරන්න 🚀",
    suiteFooterNote: "COSMO CLASS යනු ශ්‍රී ලංකාවේ වයස 12 ක සිසුවෙකු විසින් ලොව පුරා තාරකා විද්‍යා අධ්‍යාපනය වෙනුවෙන් නිර්මාණය කරන ලද නව්‍ය තාක්ෂණික පද්ධතියකි.",

    // Views & Pages
    aiPageTitle: "AI සහ යන්ත්‍ර ඉගෙනුම් විශ්ලේෂණ පද්ධතිය",
    aiPageBadge: "Human-in-the-Loop AI",
    aiPageSubtitle: "නාසා SPHEREx දත්ත ගොනුවලින් අනවශ්‍ය සංඥා (Noise) ඉවත් කර ප්ලැනට් X තහවුරු කරන කෘතිම බුද්ධි ක්‍රමවේදය",
    evidencePageTitle: "විද්‍යාත්මක මූලාශ්‍ර සහ නාසා විවෘත දත්ත ගබඩාව",
    evidencePageBadge: "NASA Caltech / JPL IRSA",
    evidencePageSubtitle: "විවෘත තාරකා විද්‍යා පර්යේෂණ පත්‍රිකා, FITS ගොනු සහ සත්‍යාපිත මූලාශ්‍ර නාමාවලිය",
    expLabPageTitle: "විද්‍යාත්මක පර්යේෂණාගාරය (Simulation Lab)",
    expLabPageBadge: "පරාමිති පාලනය",
    expLabPageSubtitle: "පැරලැක්ස් චලනය, දුර සීමාව සහ සංවේදීතාව පාලනය කරමින් අපේක්ෂිතයන් පෙරීමේ පරීක්ෂණාගාරය",

    // Footer
    footerTagline: "ඒ. දිසස් දින්සිත් (වයස 12), බණ්ඩාරගම, ශ්‍රී ලංකාව විසින් නිර්මාණය කරන ලද ඒකාබද්ධ අභ්‍යවකාශ විද්‍යා සහ ඩිජිටල් නවෝත්පාදන පද්ධතිය",
    footerExploreAdGenie: "Ad Genie AI Chatbot ගවේෂණය කරන්න",
    footerViewSource: "මූල කේතය බලන්න (GitHub)",
    footerManifesto1: "මෙම සියලු නවෝත්පාදනයන් එක්ව COSMO CLASS බිහි කරයි.",
    footerManifestoQuote: "\"විද්‍යාව ඕනෑම කෙනෙකුට දැකීමට, කියවීමට, ඇසීමට, ක්‍රීඩා කිරීමට සහ ගොඩනැගීමට හැකි වන පරිදි මම මෙය නිර්මාණය කළෙමි.\"",
    footerNasaNote: "NASA Space Apps Challenge 2026 වෙනුවෙන් ආදරයෙන් නිර්මාණය කරන ලදී ❤️",
    footerDevLabel: "සංවර්ධක:",
    footerAgeLabel: "වයස:",
    footerAgeVal: "අවුරුදු 12",
    footerLocationLabel: "ස්ථානය:",
    footerLocationVal: "බණ්ඩාරගම, ශ්‍රී ලංකාව",
    footerCopyright: "© 2026 COSMO CLASS • SPHEREx මෙහෙයුම 2025 • NASA API සක්‍රියයි"
  },
  en: {
    // Navigation & Branding
    brandTitle: "COSMO CLASS",
    brandTag: "Planet X Hunter",
    creatorTag: "Created by A. Disas Dinsitha (Age 12) • NASA Space Apps Challenge 2026",
    navSurvey: "102-Band Sky Survey",
    navExperiment: "Experiment Mode (12 → 4)",
    navAi: "AI Pipeline",
    navEvidence: "Data & Sources",
    navGuideBtn: "Guide",
    navReturnSurvey: "🔭 Return to Sky Survey",
    langSwitchLabel: "Language / භාෂාව",
    nasaConnected: "NASA Connected",

    // Sri Lankan Astronomy Guide
    sriLankaGuideTitle: "🇱🇰 Sri Lankan Astronomy & Student Discovery Guide",
    sriLankaGuideBadge: "Sri Lanka Space Science Education",
    sriLankaGuideSubtitle: "A beginner-friendly astronomical guide to discovering Planet X beyond Neptune using NASA SPHEREx data",
    guideWhatIsPlanetXTitle: "What is Planet X?",
    guideWhatIsPlanetXDesc: "A hypothesized massive 9th planet residing in the far outer reaches of our solar system, 50 to 100 astronomical units (AU) past Neptune and Pluto. Because it receives minuscule sunlight, it is pitch-black in visible light and extremely cold.",
    guideBlinkTitle: "How does the Blink Comparator work?",
    guideBlinkDesc: "Invented by Clyde Tombaugh in 1930 to discover Pluto! By rapidly toggling between two sky photographs captured 6 months apart (March vs September), distant stars remain perfectly stationary while our nearby moving planet candidate visibly jumps back and forth.",
    guideSpectraTitle: "Why use 102 Infrared (IR) Spectral Bands?",
    guideSpectraDesc: "Planet X has an icy equilibrium temperature around 40-60 Kelvin, emitting zero visible light. However, in NASA SPHEREx's deep thermal infrared channels (4.5 μm to 5.0 μm), its thermal radiation peaks prominently.",
    guideSriLankaRoleTitle: "Empowering Sri Lankan Space Education",
    guideSriLankaRoleDesc: "Designed to inspire students across Sri Lanka—connecting with initiatives at Arthur C. Clarke Institute (ACCMT), Colombo Planetarium, school astronomy societies, and NASA Space Apps Sri Lanka.",

    // 3-Step Quick Guide
    quickGuideTitle: "Simple Quick Guide: How to Find Planet X",
    quickGuideSubtitle: "Easy to understand for students, teachers & space enthusiasts",
    step1Title: "1. Compare the 2 Surveys",
    step1Desc: "Click Auto Blink to alternate between Survey 1 (March) and Survey 2 (Sept). Stationary background stars remain fixed.",
    step2Title: "2. Spot the Moving Red Dot",
    step2Desc: "Notice the red dot jumping positions between surveys? That is your moving Planet X candidate! Click it anytime to log its coordinates.",
    step3Title: "3. Browse All 102 Bands",
    step3Desc: "Click the Previous (◀) and Next (▶) arrow buttons to explore all 102 SPHEREx infrared wavelengths (0.75 μm to 5.00 μm).",

    // Sky Spectrometer & Cockpit
    spectrometerTitle: "SPHEREx Near-Infrared Spectrometer",
    keyboardShortcuts: "Keyboard Shortcuts: ◀ Left Arrow | ▶ Right Arrow",
    prevBandBtn: "◀ PREV BAND",
    nextBandBtn: "NEXT BAND ▶",
    bandOf102: "of 102",
    nasaImageBadge: "NASA Image:",
    candidatePosition: "Candidate Position:",
    thermalRadiance: "Thermal Radiance:",
    clickSkyHint: "Click anywhere on the sky to log candidate coordinates",

    // Mission Controls Sidebar
    missionControlsTitle: "Mission Controls",
    spherexHudBadge: "SPHEREx HUD",
    expModeTitle: "Experiment Mode",
    expModeBadge: "12 → 4 Candidates",
    expModeDesc: "Tune Detection Threshold (75%), Range (1-100 AU) & Sensitivity to run simulations and compare BEFORE vs AFTER.",
    launchExpLabBtn: "Launch Experiment Lab 🔬",
    surveyCompTitle: "Survey Comparison:",
    survey1Btn: "Survey 1 (March)",
    survey2Btn: "Survey 2 (Sept)",
    startBlinkBtn: "Start Auto Blink",
    stopBlinkBtn: "Stop Auto Blink",
    browseBandsTitle: "Browse All 102 Bands:",
    playTimelapseBtn: "Play 102-Band Timelapse",
    pauseTimelapseBtn: "Pause Spectral Auto-Scan",
    audioSonarTitle: "Audio Sonar (Accessibility):",
    sonarEnabled: "ENABLED",
    sonarDisabled: "DISABLED",
    enableSonarBtn: "Enable Sound Sonar 🔇",
    activeSonarBtn: "Sound Sonar: Active 🔊",
    sonarHelpText: "Emits an audible sonar ping as your mouse cursor moves closer to the Planet X candidate.",
    myDiscoveriesTitle: "My Discoveries:",
    exportBtn: "Export",
    clearBtn: "Clear",
    noDiscoveriesYet: "No candidates logged yet.\nClick the sky image to record target coordinates!",
    nasaDataTitle: "NASA Scientific Telemetry:",
    bandsActiveBadge: "102 Bands: Active ✓",
    apiKeyBadge: "NASA API Key: Verified ✓",

    // CosmoClass Suite
    suiteTitle: "COSMO CLASS Ecosystem Product Suite",
    suiteSubtitle: "11 Specialized Web Tools & Educational Applications built by A. Disas Dinsitha for Students, Coders & Space Explorers",
    suiteTag: "EcoSystem Suite",
    filterAll: "All Tools",
    visitToolBtn: "Visit Tool 🚀",
    suiteFooterNote: "COSMO CLASS is an initiative created by a 12-year-old Sri Lankan student to make space science, coding, and educational exploration accessible worldwide.",

    // Views & Pages
    aiPageTitle: "AI & Machine Learning Spectral Analysis Pipeline",
    aiPageBadge: "Human-in-the-Loop AI",
    aiPageSubtitle: "How neural filters and computer vision eliminate cosmic ray false positives to isolate authentic Planet X candidates",
    evidencePageTitle: "Scientific Evidence & Open NASA Archives",
    evidencePageBadge: "NASA Caltech / JPL IRSA",
    evidencePageSubtitle: "Peer-reviewed literature, open all-sky data cubes, and cross-mission verification protocols",
    expLabPageTitle: "Interactive Parameter Experimentation Lab",
    expLabPageBadge: "Parameter Tuning",
    expLabPageSubtitle: "Filter 12 multi-mission raw candidates down to 4 high-probability Planet X targets through real-time slider tuning",

    // Footer
    footerTagline: "Unified Space Science & Digital Innovation Ecosystem created by A. Disas Dinsitha (Age 12), Bandaragama, Sri Lanka",
    footerExploreAdGenie: "Explore: Ad Genie AI Chatbot",
    footerViewSource: "View Source Code (GitHub)",
    footerManifesto1: "All of these innovations together form COSMO CLASS.",
    footerManifestoQuote: "\"I built this so science can be Seen, Read, Heard, Played, and Built — by everyone, the easy way.\"",
    footerNasaNote: "Made with ❤️ for NASA Space Apps Challenge 2026",
    footerDevLabel: "DEVELOPER:",
    footerAgeLabel: "AGE:",
    footerAgeVal: "12 Years Old",
    footerLocationLabel: "LOCATION:",
    footerLocationVal: "Bandaragama, Sri Lanka",
    footerCopyright: "© 2026 COSMO CLASS • SPHEREx Mission 2025 • NASA API Active"
  }
};
