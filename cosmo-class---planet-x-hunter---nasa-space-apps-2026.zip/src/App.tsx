import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Play, 
  Pause, 
  Trash2, 
  Download, 
  Volume2, 
  VolumeX, 
  Crosshair, 
  Sparkles 
} from 'lucide-react';

const NASA_API_KEY = "5LjjC66pBkXh2LmFdpxIRRSqhFSXFXyYXM4fft2V";
const FALLBACK_IMAGE = "https://apod.nasa.gov/apod/image/2503/SPHERExLaunch_SpaceX_1080.jpg";

const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;

interface Discovery {
  id: string;
  ra: string;
  dec: string;
  time: string;
}

// Generate 200 fixed stars so they remain 100% constant across surveys
function generateStars() {
  const list = [];
  // Seeded values so it doesn't shift randomly on re-renders
  let seed = 42;
  const rnd = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
  for (let i = 0; i < 200; i++) {
    list.push({
      x: rnd() * CANVAS_WIDTH,
      y: rnd() * CANVAS_HEIGHT,
      r: 0.8 + rnd() * 1.5,
    });
  }
  return list;
}

const FIXED_STARS = generateStars();

export default function App() {
  const [survey, setSurvey] = useState<1 | 2>(1);
  const [blinking, setBlinking] = useState<boolean>(true);
  const [blind, setBlind] = useState<boolean>(false);
  const [sliderVal, setSliderVal] = useState<number>(0);
  const [discoveries, setDiscoveries] = useState<Discovery[]>([]);
  const [bgImage, setBgImage] = useState<string>(FALLBACK_IMAGE);
  const [imageTitle, setImageTitle] = useState<string>("SPHEREx Launch");
  const [apiActive, setApiActive] = useState<boolean>(true);
  const [flashScreen, setFlashScreen] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const lastBeepRef = useRef<number>(0);

  // Initialize discoveries from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('cosmo');
      if (saved) {
        setDiscoveries(JSON.parse(saved));
      }
    } catch (e) {
      console.warn("Storage load error", e);
    }
  }, []);

  // Fetch real NASA APOD Image on mount
  useEffect(() => {
    let active = true;
    async function fetchImage() {
      try {
        const res = await fetch(`https://api.nasa.gov/planetary/apod?api_key=${NASA_API_KEY}`);
        if (!res.ok) throw new Error("APOD fetch failed");
        const data = await res.json();
        const url = data.hdurl || data.url;
        if (url && active) {
          setBgImage(url);
          if (data.title) setImageTitle(data.title);
          setApiActive(true);
        }
      } catch (err) {
        console.warn("Using SPHEREx default background image", err);
        if (active) {
          setBgImage(FALLBACK_IMAGE);
          setImageTitle("SPHEREx Launch");
          setApiActive(true);
        }
      }
    }
    fetchImage();
    return () => {
      active = false;
    };
  }, []);

  // Auto Blink interval toggling between Survey 1 and Survey 2 every 400ms
  useEffect(() => {
    if (!blinking) return;
    const timer = setInterval(() => {
      setSurvey((prev) => {
        const next = prev === 1 ? 2 : 1;
        setSliderVal(next === 1 ? 0 : 100);
        return next;
      });
    }, 400);

    return () => clearInterval(timer);
  }, [blinking]);

  // Sync survey state with slider
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBlinking(false);
    const val = Number(e.target.value);
    setSliderVal(val);
    setSurvey(val < 50 ? 1 : 2);
  };

  // Draw 200 fixed stars on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    ctx.fillStyle = "white";

    FIXED_STARS.forEach((s) => {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    });
  }, []);

  // Red dot coordinates:
  // Survey 1: (120, 150)
  // Survey 2: (200, 170) -> 80px shifted
  const targetX = survey === 1 ? 120 : 200;
  const targetY = survey === 1 ? 150 : 170;

  // Canvas click handles discovery
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;

    const x = ((e.clientX - rect.left) * scaleX).toFixed(1);
    const y = ((e.clientY - rect.top) * scaleY).toFixed(1);

    const newDisc: Discovery = {
      id: Date.now().toString(),
      ra: x,
      dec: y,
      time: new Date().toLocaleTimeString(),
    };

    const nextList = [newDisc, ...discoveries];
    setDiscoveries(nextList);
    try {
      localStorage.setItem('cosmo', JSON.stringify(nextList));
    } catch (err) {
      console.warn("Storage save error", err);
    }

    // Flash background effect
    setFlashScreen(true);
    setTimeout(() => setFlashScreen(false), 150);

    // Audio confirmation sound
    playFlagSound();
  };

  const deleteDiscovery = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = discoveries.filter(d => d.id !== id);
    setDiscoveries(filtered);
    localStorage.setItem('cosmo', JSON.stringify(filtered));
  };

  const clearDiscoveries = () => {
    setDiscoveries([]);
    localStorage.removeItem('cosmo');
  };

  const exportDiscoveries = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(discoveries, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `SPHEREx_Discoveries_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const initAudio = () => {
    if (!audioCtxRef.current) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        audioCtxRef.current = new AudioCtx();
      }
    }
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  const playFlagSound = () => {
    try {
      initAudio();
      const ctx = audioCtxRef.current;
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1174.66, ctx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch (e) {
      console.warn("Sound error", e);
    }
  };

  // Blind mode sonar feedback on mouse movement inside viewer
  const handleViewerMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!blind) return;
    initAudio();
    const ctx = audioCtxRef.current;
    if (!ctx) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;

    const mx = (e.clientX - rect.left) * scaleX;
    const my = (e.clientY - rect.top) * scaleY;

    const dist = Math.hypot(mx - targetX, my - targetY);

    const now = Date.now();
    if (now - lastBeepRef.current < 90) return;
    lastBeepRef.current = now;

    if (dist < 300) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = Math.max(100, 900 - dist * 3);
      gain.gain.value = Math.max(0.01, (1 - dist / 300) * 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    }
  };

  const toggleBlink = () => {
    initAudio();
    setBlinking(!blinking);
  };

  const toggleBlind = () => {
    initAudio();
    setBlind(!blind);
  };

  return (
    <div 
      className={`min-h-screen text-[#00ffff] font-mono flex flex-col justify-between selection:bg-[#00ffff]/20 selection:text-white transition-colors duration-150 ${
        flashScreen ? 'bg-[#ff0000]/20' : 'bg-[#02020a]'
      }`}
    >
      {/* HEADER */}
      <header className="text-center py-3.5 px-4 border-b-2 border-[#00ffff] shadow-[0_0_20px_#00ffff] bg-[#02020a] z-10">
        <h1 className="text-base sm:text-lg md:text-xl font-bold tracking-wider text-[#00ffff]">
          COSMO CLASS // SPHEREx Planet X Hunter // Solo by Disas (12) - Anuradhapura
        </h1>
      </header>

      {/* MAIN LAYOUT */}
      <main className="flex-1 flex flex-col lg:flex-row w-full max-w-[1600px] mx-auto overflow-hidden">
        
        {/* VIEWER AREA (FLEX 3) */}
        <section 
          id="viewer"
          onMouseMove={handleViewerMouseMove}
          className="flex-[3] relative bg-black overflow-hidden flex items-center justify-center min-h-[460px] lg:min-h-[620px] select-none border-b lg:border-b-0 border-[#00ffff]/30"
        >
          {/* Real NASA Background Image (faint opacity 0.3) */}
          <img 
            className="absolute inset-0 w-full h-full object-cover opacity-30 pointer-events-none transition-opacity duration-300"
            src={bgImage} 
            alt="SPHEREx / NASA APOD Space Background"
            referrerPolicy="no-referrer"
            onError={(e) => {
              const target = e.currentTarget;
              if (target.src !== FALLBACK_IMAGE) {
                target.src = FALLBACK_IMAGE;
              } else {
                // If even fallback fails, hide image completely to keep only pure black starfield
                target.style.display = 'none';
              }
            }}
          />

          {/* REAL NASA IMAGE BADGE */}
          <div className="absolute top-3 left-3 z-10 bg-black/80 border border-[#00ffff]/60 px-3 py-1 text-xs text-[#00ffff] backdrop-blur-sm pointer-events-none shadow-[0_0_10px_rgba(0,255,255,0.3)]">
            <span>REAL NASA IMAGE: </span>
            <strong className="text-white">{imageTitle}</strong>
          </div>

          {/* Screen-proportional canvas container ensuring 100% accurate coordinate alignment between canvas and target dot */}
          <div className="relative w-full max-w-[800px] aspect-[4/3] flex items-center justify-center">
            {/* Canvas for 200 Identical Stars */}
            <canvas 
              id="c"
              ref={canvasRef}
              width={CANVAS_WIDTH}
              height={CANVAS_HEIGHT}
              onClick={handleCanvasClick}
              className="absolute inset-0 w-full h-full z-[2] cursor-crosshair object-contain"
              title="Click to log candidate coordinates (RA/DEC)"
            />

            {/* Glowing Red Target Dot (Planet X Candidate) - Ultra Bright with Multi-layered Glow */}
            <div 
              id="target"
              className="absolute pointer-events-none z-[3] rounded-full transition-all duration-75 flex items-center justify-center"
              style={{
                width: '16px',
                height: '16px',
                backgroundColor: '#ff0000',
                boxShadow: '0 0 20px 8px #ff0000, 0 0 40px 14px rgba(255, 30, 30, 0.85), 0 0 70px 24px rgba(255, 0, 0, 0.6), inset 0 0 6px #ffffff',
                left: `${(targetX / CANVAS_WIDTH) * 100}%`,
                top: `${(targetY / CANVAS_HEIGHT) * 100}%`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              {/* Ultra bright white-hot center core */}
              <div className="w-2 h-2 rounded-full bg-white shadow-[0_0_8px_2px_#ffffff]" />
              {/* Intense pulsating radar aura */}
              <div className="absolute -inset-1.5 rounded-full animate-ping bg-red-500 opacity-90 pointer-events-none" />
            </div>
          </div>

          {/* Telemetry coordinate pill in bottom-left */}
          <div className="absolute bottom-3 left-3 z-10 bg-black/85 border border-[#00ffff]/40 px-2.5 py-1 text-[11px] text-[#00ffff] pointer-events-none">
            <span>Target Pos: </span>
            <strong className="text-red-400 font-bold">X:{targetX}, Y:{targetY}</strong>
            <span className="ml-2 text-cyan-600">[{survey === 1 ? 'Survey 1' : 'Survey 2'}]</span>
          </div>
        </section>

        {/* SIDE CONTROLS & DISCOVERIES PANEL (FLEX 1) */}
        <aside className="flex-[1] bg-[#0a0a1a] border-t lg:border-t-0 lg:border-l-2 border-[#00ffff] p-4 sm:p-5 flex flex-col justify-between shadow-[inset_0_0_20px_rgba(0,255,255,0.1)]">
          <div className="space-y-4">
            <h2 className="text-base font-bold uppercase tracking-wider text-white border-b border-[#00ffff]/40 pb-1">
              Controls
            </h2>

            {/* Slider 0 - 100 */}
            <div>
              <input 
                type="range" 
                id="slider" 
                min="0" 
                max="100" 
                value={sliderVal} 
                onChange={handleSliderChange}
                className="w-full h-2.5 bg-black rounded-none appearance-none cursor-pointer accent-[#00ffff] border border-[#00ffff]/50"
                aria-label="Survey comparator slider"
              />
              <p id="label" className="text-sm font-bold mt-1 text-center text-white tracking-wide">
                {survey === 1 ? "Survey 1 - March 2025" : "Survey 2 - Sept 2025"}
              </p>
            </div>

            {/* AUTO BLINK BUTTON */}
            <button 
              id="blinkBtn"
              onClick={toggleBlink}
              className="w-full bg-[#00ffff] text-black border-none py-2.5 px-4 font-bold cursor-pointer transition-colors duration-150 tracking-wider uppercase text-sm hover:bg-white shadow-[0_0_12px_rgba(0,255,255,0.4)]"
            >
              {blinking ? "STOP BLINKING" : "START AUTO BLINK"}
            </button>

            {/* BLIND MODE BUTTON */}
            <button 
              id="blindBtn"
              onClick={toggleBlind}
              className={`w-full border-none py-2.5 px-4 font-bold cursor-pointer transition-colors duration-150 tracking-wider uppercase text-sm ${
                blind 
                  ? 'bg-amber-400 text-black shadow-[0_0_12px_rgba(251,191,36,0.6)]' 
                  : 'bg-[#00ffff] text-black hover:bg-white'
              }`}
            >
              BLIND MODE: {blind ? "ON 🔊" : "OFF"}
            </button>

            <hr className="border-[#00ffff]/30 my-3" />

            {/* MY DISCOVERIES LIST */}
            <div>
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white tracking-wide">
                  My Discoveries: <span id="count" className="text-[#00ffff] font-mono text-base font-extrabold">{discoveries.length}</span>
                </h3>
                {discoveries.length > 0 && (
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={exportDiscoveries}
                      title="Export Catalog"
                      className="p-1 text-xs text-[#00ffff] hover:text-white bg-transparent w-auto m-0 border border-[#00ffff]/40 hover:border-[#00ffff]"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button 
                      onClick={clearDiscoveries}
                      title="Clear All"
                      className="p-1 text-xs text-red-400 hover:text-white bg-transparent w-auto m-0 border border-red-500/40 hover:border-red-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Discoveries list scroll container */}
              <div 
                id="list" 
                className="mt-2.5 max-h-[220px] overflow-y-auto space-y-1.5 pr-1 text-xs"
              >
                {discoveries.length === 0 ? (
                  <div className="py-6 text-center text-cyan-600 border border-dashed border-[#00ffff]/20 text-[11px]">
                    No discoveries yet.<br />Click canvas to flag moving objects!
                  </div>
                ) : (
                  discoveries.map((d, i) => (
                    <div 
                      key={d.id || i}
                      className="p-1.5 bg-[#02020a] border border-[#00ffff]/30 flex items-center justify-between text-xs hover:border-[#00ffff]"
                    >
                      <span className="font-mono">
                        <strong className="text-white">{i + 1}.</strong> RA:{d.ra} DEC:{d.dec} <small className="text-cyan-500 ml-1">[{d.time}]</small>
                      </span>
                      <button
                        onClick={(e) => deleteDiscovery(d.id, e)}
                        className="w-auto p-0.5 m-0 text-cyan-600 hover:text-red-400 bg-transparent"
                        title="Delete entry"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* NASA DATA FOOTNOTE */}
          <div className="mt-4 pt-3 border-t border-[#00ffff]/30 text-[11px] text-cyan-400/90 leading-relaxed font-mono">
            <p>REAL NASA IMAGE: {imageTitle}</p>
            <p>Data: SPHEREx + NASA APOD</p>
            <p className="text-emerald-400 font-bold">API: 5Ljj...ft2V Active ✓</p>
          </div>
        </aside>
      </main>

      {/* EXTENDED COSMOCLASS FOOTER & ECOSYSTEM SHOWCASE */}
      <footer className="border-t-2 border-[#00ffff] bg-[#02020a] text-cyan-400 py-8 px-4 sm:px-6 shadow-[0_0_30px_rgba(0,255,255,0.2)]">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* SPECIAL AD GENIE AI & SOURCE CODE ACTION ROW */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <a
              href="https://adgeniechatbotsrilanka.lovable.app/"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 bg-gradient-to-r from-amber-400 via-pink-500 to-cyan-400 text-black font-extrabold text-sm sm:text-base tracking-wider uppercase rounded-none border-2 border-white hover:brightness-125 transition-all shadow-[0_0_20px_rgba(251,191,36,0.6)] flex items-center gap-2"
            >
              <Sparkles className="w-5 h-5 fill-black" />
              <span>⚡ SPECIAL: AD GENIE AI</span>
            </a>

            <a
              href="https://github.com/wm208727-png/COSMO-CLASS"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 bg-[#00ffff] text-black font-extrabold text-sm sm:text-base tracking-wider uppercase rounded-none border-2 border-[#00ffff] hover:bg-white hover:text-black transition-all shadow-[0_0_20px_rgba(0,255,255,0.5)] flex items-center gap-2"
            >
              <span>WATCH SOURCE CODES (GITHUB)</span>
            </a>
          </div>

          {/* BOLD LINK BUTTONS GRID (1-11) */}
          <div>
            <h3 className="text-center text-sm font-bold text-white tracking-widest uppercase mb-4 text-[#00ffff] flex items-center justify-center gap-2">
              <span>EXPLORE THE COMPLETE COSMOCLASS SUITE (CLICK TO LAUNCH)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <a
                href="https://helascopesuper.netlify.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  1) Hela Scope
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  Watch all planets and satellites in 3D and live
                </div>
              </a>

              <a
                href="https://solar-system-eyes-srilanka-bydisas.netlify.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  2) NASA Solar System Eyes
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  Watch Solar System in 3D
                </div>
              </a>

              <a
                href="https://dimex-live-with-nasa.netlify.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  3) Watch NASA Videos
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  Stream live NASA TV and deep space explorations
                </div>
              </a>

              <a
                href="https://edu-dinsi-893989629906.asia-southeast1.run.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  4) Read & Hear Blogs by Disas
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  Interactive articles with Blind Mode audio narration
                </div>
              </a>

              <a
                href="https://edudslpro.netlify.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  5) Edu DSL
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  Read NASA & Wikipedia blogs shortly + AI Chatbot
                </div>
              </a>

              <a
                href="https://codedimex.netlify.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  6) Code Dimex
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  TEST YOUR CODE (Web Dev Codes: HTML, CSS, JS)
                </div>
              </a>

              <a
                href="https://zesty-crisp.netlify.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  7) Science Quiz Explorer 1
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  Answer the quizzes and get scores
                </div>
              </a>

              <a
                href="https://quiz-master-srilanka-made-by-disas.netlify.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  8) Science Quiz Explorer 2 (Quiz Master)
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  Answer the quizzes and get scores
                </div>
              </a>

              <a
                href="https://moodrevminiword.blogspot.com/2026/08/mood-rev-mini-word-editor.html"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  9) Beginner Friendly "Mini Word" App
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  MoodREV text document editor for quick document writing
                </div>
              </a>

              <a
                href="https://rockertvsasteroidsgame.netlify.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  10) Play a Game (Rockets vs Asteroids)
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  Space arcade simulation game
                </div>
              </a>

              <a
                href="https://sites.google.com/view/a-disas-dinsithas-portfolio/home"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#0a0a1a] border border-[#00ffff]/60 hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all group flex flex-col justify-between sm:col-span-2 lg:col-span-2"
              >
                <div className="font-extrabold text-white group-hover:text-[#00ffff] text-sm">
                  11) Watch Developer's Certificates (A. Disas Dinsitha's Portfolio)
                </div>
                <div className="text-xs text-cyan-300/80 font-bold mt-1">
                  Official certificates, technical awards, and portfolio showcase
                </div>
              </a>
            </div>
          </div>

          {/* DEDICATED PROJECT DESCRIPTIONS ACCORDING TO USER SPECIFICATION */}
          <div className="border border-[#00ffff]/40 bg-[#060614] p-5 sm:p-6 space-y-6 text-xs sm:text-sm">
            <h3 className="text-base font-extrabold text-white uppercase tracking-wider border-b border-[#00ffff]/30 pb-2">
              COSMOCLASS Integrated Projects Overview
            </h3>

            <div className="space-y-4 text-cyan-300/90 leading-relaxed font-mono">
              <div>
                <h4 className="font-extrabold text-white text-sm">🪐 Hela Scope – Explore 3D Planets</h4>
                <p className="mt-1">
                  <strong>Description:</strong> Hela Scope allows users to explore planets in our Solar System in an immersive 3D environment while learning new facts about space. It combines education and technology to provide a more engaging and interactive way to discover the planets.
                </p>
              </div>

              <div>
                <h4 className="font-extrabold text-white text-sm">☀️ Solar System Eyes – Explore the Solar System</h4>
                <p className="mt-1">
                  <strong>Description:</strong> Solar System Eyes Sri Lanka allows users to explore information about the Solar System and its planets. It provides an enjoyable way for students and space enthusiasts to learn about astronomy and discover more about our cosmic neighborhood.
                </p>
              </div>

              <div>
                <h4 className="font-extrabold text-white text-sm">👓 EDU DINSI – Blind Mode</h4>
                <p className="mt-1">
                  <strong>Description:</strong> EDU DINSI Blind Mode allows users to listen to news and information from the website. It is designed for users who may find it difficult to view the screen or for anyone who prefers to listen to educational content and news.
                </p>
              </div>

              <div>
                <h4 className="font-extrabold text-white text-sm">🌐 EDU DINSI – Educational & News Platform</h4>
                <p className="mt-1">
                  <strong>Description:</strong> EDU DINSI is an educational and information platform where users can read educational content, news, and informative articles. It makes it easy for students and knowledge seekers to discover and learn new information.
                </p>
              </div>

              <div>
                <h4 className="font-extrabold text-white text-sm">🤖 EDU DSL – NASA Blogs & AI Chatbot</h4>
                <p className="mt-1">
                  <strong>Description:</strong> EDU DSL allows users to read educational articles about NASA and space while also interacting with an AI chatbot to ask questions and explore information. It brings space education and AI technology together in one platform.
                </p>
              </div>

              <div>
                <h4 className="font-extrabold text-white text-sm">💻 CODE DIMEX – HTML, CSS & JavaScript Code Testing</h4>
                <p className="mt-1">
                  <strong>Description:</strong> CODE DIMEX allows users to write, run, and test HTML, CSS, and JavaScript code and instantly view the results. It is a useful tool for students and beginners who are learning web development and want to experiment with their own code.
                </p>
              </div>

              <div>
                <h4 className="font-extrabold text-white text-sm">🧠 Questions & Quiz – Test Your Knowledge</h4>
                <div className="pl-3 border-l-2 border-[#00ffff]/40 my-1 space-y-0.5 text-white font-bold">
                  <p>1) Quiz Master Sri Lanka</p>
                  <p>2) Science Quiz Explorer</p>
                </div>
                <p className="mt-1">
                  <strong>Description:</strong> This section allows users to answer a variety of questions and test their knowledge. It provides an interactive and enjoyable way to review what they have learned while improving their understanding through quizzes.
                </p>
              </div>

              <div>
                <h4 className="font-extrabold text-white text-sm">📝 MoodREV – Text Document Maker</h4>
                <p className="mt-1">
                  <strong>Description:</strong> MoodREV is a simple text document editor designed for creating and editing documents. Users can write, edit, and organize their text to create simple digital documents.
                </p>
              </div>

              <div>
                <h4 className="font-extrabold text-white text-sm">👨‍💻 Developer Portfolio – Certificates & Projects</h4>
                <p className="mt-1">
                  <strong>Description:</strong> The Developer Portfolio showcases certificates, projects, websites, and other technology-related work created by the developer. It provides an opportunity to explore the developer’s technical journey, skills, achievements, and creative projects.
                </p>
              </div>
            </div>
          </div>

          {/* DEVELOPER MANIFESTO & CREDITS STATEMENT */}
          <div className="border-t border-[#00ffff]/40 pt-6 text-center space-y-3 font-mono">
            <p className="text-base sm:text-lg font-bold text-white tracking-wide">
              All 6 of these together are COSMOCLASS.
            </p>
            <p className="text-sm text-cyan-300">
              I am a 12-year-old student from Sri Lanka.
            </p>
            <p className="text-xs sm:text-sm text-white/90 max-w-2xl mx-auto italic">
              "I built this so science can be Seen, Read, Heard, Played, and Built - by everyone, the easy way."
            </p>
            <p className="text-xs text-cyan-400">
              Made with ❤️ for NASA Space Apps Challenge 2026
            </p>
            <p className="text-xs text-cyan-500 font-bold">
              © 2026 COSMOCLASS
            </p>

            <div className="inline-block mt-3 p-4 bg-[#0a0a1a] border border-[#00ffff]/50 text-xs sm:text-sm text-left font-mono space-y-1">
              <p><strong className="text-white">DEVELOPER :</strong> A. DISAS DINSITHA</p>
              <p><strong className="text-white">AGE :</strong> 12</p>
              <p><strong className="text-white">E MAIL :</strong> <a href="mailto:wm208727@gmail.com" className="text-[#00ffff] underline hover:text-white">wm208727@gmail.com</a></p>
              <p><strong className="text-white">Country :</strong> Sri Lanka</p>
            </div>

            <div className="pt-3 text-[11px] text-cyan-500">
              Built Solo by Disas | NASA API Active | SPHEREx Mission 2025 | COSMO CLASS
            </div>
          </div>

        </div>
      </footer>
    </div>
  );
}
